import React, { useState, useRef, useEffect } from 'react';
import {
  Volume2,
  Copy,
  Check,
  Download,
  Trash2,
  Search,
  Sparkles,
  ArrowDownCircle,
  FileText,
  Clock,
  Subtitles,
  Languages
} from 'lucide-react';
import { SubtitleItem, speakArabicText, exportSubtitlesAsSrt, exportSubtitlesAsTxt } from '../utils/liveTranslatorEngine';
import { downloadBlobAsFile } from '../utils/zipPackager';

interface LiveSubtitleFeedProps {
  subtitles: SubtitleItem[];
  onClear: () => void;
  isStreaming: boolean;
}

export const LiveSubtitleFeed: React.FC<LiveSubtitleFeedProps> = ({
  subtitles,
  onClear,
  isStreaming
}) => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [autoScroll, setAutoScroll] = useState<boolean>(true);
  const feedEndRef = useRef<HTMLDivElement | null>(null);

  // التمرير التلقائي لأسفل عند وصول ترجمة جديدة
  useEffect(() => {
    if (autoScroll && feedEndRef.current) {
      feedEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [subtitles, autoScroll]);

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleExportSrt = () => {
    if (subtitles.length === 0) return;
    const srtContent = exportSubtitlesAsSrt(subtitles);
    const blob = new Blob([srtContent], { type: 'text/plain;charset=utf-8' });
    downloadBlobAsFile(blob, `live-subtitles-${Date.now()}.srt`);
  };

  const handleExportTxt = () => {
    if (subtitles.length === 0) return;
    const txtContent = exportSubtitlesAsTxt(subtitles);
    const blob = new Blob([txtContent], { type: 'text/plain;charset=utf-8' });
    downloadBlobAsFile(blob, `live-transcripts-${Date.now()}.txt`);
  };

  const filteredSubtitles = subtitles.filter(
    (item) =>
      item.translatedText.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.originalText.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-5 sm:p-7 shadow-2xl backdrop-blur-xl flex flex-col h-[650px] relative">
      
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 pb-4 border-b border-slate-800">
        
        {/* Title & Counter */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/15 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
            <Subtitles className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-lg font-bold text-white">شريط الترجمة الحية المباشرة</h2>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-xs font-mono text-emerald-400 border border-slate-700">
                {subtitles.length} أسطر
              </span>
            </div>
            <p className="text-xs text-slate-400">النصوص المترجمة لحظياً تظهر سطر بسطر</p>
          </div>
        </div>

        {/* Action Buttons (Export, Clear, Auto-scroll) */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute right-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="بحث في النصوص..."
              className="w-32 sm:w-40 bg-slate-950 border border-slate-800 rounded-xl pr-8 pl-3 py-1.5 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-emerald-500"
            />
          </div>

          {/* Auto-scroll toggle */}
          <button
            onClick={() => setAutoScroll(!autoScroll)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-all ${
              autoScroll
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                : 'bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200'
            }`}
            title="التمرير التلقائي لأسفل"
          >
            <ArrowDownCircle className="w-3.5 h-3.5" />
            <span>تمرير تلقائي</span>
          </button>

          {/* Export SRT */}
          <button
            onClick={handleExportSrt}
            disabled={subtitles.length === 0}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-950 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition-all flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
            title="تصدير كملف SRT للترجمة"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>SRT</span>
          </button>

          {/* Export TXT */}
          <button
            onClick={handleExportTxt}
            disabled={subtitles.length === 0}
            className="px-3 py-1.5 rounded-xl text-xs font-semibold bg-slate-950 text-slate-300 hover:text-white border border-slate-800 hover:border-slate-700 transition-all flex items-center gap-1.5 disabled:opacity-40 disabled:cursor-not-allowed"
            title="تصدير كملف نصي TXT"
          >
            <FileText className="w-3.5 h-3.5 text-teal-400" />
            <span>TXT</span>
          </button>

          {/* Clear Button */}
          <button
            onClick={onClear}
            disabled={subtitles.length === 0}
            className="p-1.5 rounded-xl bg-slate-950 text-slate-400 hover:text-red-400 border border-slate-800 hover:border-red-500/30 transition-all disabled:opacity-40 disabled:cursor-not-allowed"
            title="مسح السجل"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Subtitles Scroll Container */}
      <div className="flex-1 overflow-y-auto space-y-3.5 p-2 sm:p-3 scrollbar-thin scrollbar-thumb-slate-800 scrollbar-track-transparent">
        {filteredSubtitles.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center p-8">
            <div className="w-16 h-16 rounded-3xl bg-slate-950 border border-slate-800 flex items-center justify-center text-slate-600 mb-4 shadow-inner">
              <Languages className="w-8 h-8 text-emerald-500/50" />
            </div>
            <h3 className="text-base font-bold text-slate-300 mb-1">في انتظار بدء البث</h3>
            <p className="text-xs text-slate-500 max-w-md leading-relaxed">
              اضغط على زر <strong className="text-emerald-400">"بدء الترجمة الحية الآن"</strong> أعلاه
              لتسجيل مقاطع البث من 5-10 ثوانٍ وتحويلها لنصوص وترجمتها للعربية سطر بسطر.
            </p>
          </div>
        ) : (
          filteredSubtitles.map((item, index) => {
            const isLatest = index === filteredSubtitles.length - 1;
            return (
              <div
                key={item.id}
                className={`p-4 rounded-2xl border transition-all duration-300 relative group ${
                  isLatest && isStreaming
                    ? 'bg-emerald-950/20 border-emerald-500/40 shadow-lg shadow-emerald-950/30'
                    : 'bg-slate-950/70 border-slate-800/80 hover:border-slate-700'
                }`}
              >
                {/* Meta details bar */}
                <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-emerald-400 font-bold">#{item.chunkNumber.toString().padStart(3, '0')}</span>
                    <span className="text-slate-600">•</span>
                    <span className="flex items-center gap-1 text-[11px] font-mono text-slate-400">
                      <Clock className="w-3 h-3 text-slate-500" />
                      {item.timestamp}
                    </span>
                    <span className="text-slate-600">•</span>
                    <span className="text-[11px] px-2 py-0.2 rounded bg-slate-900 border border-slate-800 text-slate-300 font-mono">
                      {item.durationSeconds}s
                    </span>
                  </div>

                  {/* Actions: Speak & Copy */}
                  <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => speakArabicText(item.translatedText)}
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-emerald-400 transition-all"
                      title="نطق الترجمة بالصوت العربي"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => handleCopy(item.id, item.translatedText)}
                      className="p-1.5 rounded-lg bg-slate-900 hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-all"
                      title="نسخ النص المترجم"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                  </div>
                </div>

                {/* Original Foreign Transcript */}
                <div className="mb-2.5 pb-2 border-b border-slate-800/60 flex items-start gap-2">
                  <span className="px-1.5 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-slate-800 text-slate-300 shrink-0 mt-0.5">
                    {item.sourceLang}
                  </span>
                  <p className="text-xs sm:text-sm text-slate-400 italic font-mono leading-relaxed select-text" dir="ltr">
                    "{item.originalText}"
                  </p>
                </div>

                {/* Translated Arabic Text */}
                <div className="flex items-start gap-2.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 mt-2 shadow-sm shadow-emerald-400"></div>
                  <p className="text-sm sm:text-base font-bold text-slate-100 leading-relaxed font-sans select-text">
                    {item.translatedText}
                  </p>
                </div>
              </div>
            );
          })
        )}
        <div ref={feedEndRef} />
      </div>

      {/* Footer Info */}
      <div className="pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-500">
        <div className="flex items-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-emerald-500" />
          <span>الترجمة تعمل بنظام سطر بسطر متوافق مع شاشة تيرموكس وتطبيق أندرويد</span>
        </div>
        <span>UTF-8 / العربية الفصحى</span>
      </div>
    </div>
  );
};
