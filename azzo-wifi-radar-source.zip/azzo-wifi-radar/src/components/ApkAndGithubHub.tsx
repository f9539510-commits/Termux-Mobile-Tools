import React, { useState, useEffect } from 'react';
import { generateQrCode, downloadApkWithFeedback, getApkDirectUrls } from '../utils/apkDownloader';
import { generateNativeAndroidProjectZip, downloadBlobAsFile } from '../utils/nativeZipPackager';
import confetti from 'canvas-confetti';
import { Smartphone, Download, QrCode, GitFork, GitBranch, Check, Copy, ExternalLink, Shield, Code, Sparkles, Terminal, Rocket, PlayCircle } from 'lucide-react';

interface ApkAndGithubHubProps {
  onOpenGitHubActionsModal?: () => void;
}

export const ApkAndGithubHub: React.FC<ApkAndGithubHubProps> = ({ onOpenGitHubActionsModal }) => {
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');
  const [isDownloadingApk, setIsDownloadingApk] = useState<boolean>(false);
  const [isDownloadingSource, setIsDownloadingSource] = useState<boolean>(false);
  const [apkDownloadSuccess, setApkDownloadSuccess] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const apkDirectUrls = getApkDirectUrls('KALBASO-Termux-Studio.apk');

  useEffect(() => {
    // Generate QR Code for scanning with phone camera
    const targetUrl = apkDirectUrls.previewUrl || apkDirectUrls.currentOriginUrl;
    generateQrCode(targetUrl).then(url => {
      setQrCodeDataUrl(url);
    });
  }, []);

  const handleDownloadApk = async () => {
    setIsDownloadingApk(true);
    setApkDownloadSuccess(null);
    try {
      await downloadApkWithFeedback('KALBASO-Termux-Studio.apk', (status, msg) => {
        if (status === 'success') {
          setApkDownloadSuccess(msg);
          try {
            confetti({ particleCount: 50, spread: 60, origin: { y: 0.6 } });
          } catch {}
        }
      });
    } finally {
      setIsDownloadingApk(false);
    }
  };

  const handleDownloadSourceZip = async () => {
    setIsDownloadingSource(true);
    try {
      const blob = await generateNativeAndroidProjectZip();
      downloadBlobAsFile(blob, 'kalbaso-termux-studio-android-source.zip');
      try {
        confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
      } catch {}
    } finally {
      setIsDownloadingSource(false);
    }
  };

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(id);
    setTimeout(() => setCopiedText(null), 2500);
  };

  const gitPushCommands = `# 1. أنشئ مستودعاً جديداً على GitHub باسم kalbaso-termux-studio
# 2. فك ضغط ملف الكود المصدري وادخل المجلد ثم نفّذ الأوامر التالية:
git init
git add .
git commit -m "Initial commit: KALBASO Termux Studio Native Android IDE"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/kalbaso-termux-studio.git
git push -u origin main

# 3. يقوم GitHub Actions تلقائياً ببناء ملف الـ APK وحفظه في تبويب Actions!`;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-950 to-[#030712] border border-teal-500/30 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

        <div className="flex flex-col md:flex-row items-center gap-6 justify-between">
          <div className="space-y-2 text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/10 border border-teal-500/30 text-teal-300 text-xs font-bold font-mono">
              <Smartphone className="w-3.5 h-3.5" />
              <span>جاهز للتثبيت الفوري + مفتوح المصدر (MIT License)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
              تنزيل تطبيق KALBASO Termux Studio (APK + Source Code)
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
              احصل على ملف <strong className="text-teal-300">APK جاهز للتثبيت المباشر</strong> على أي هاتف أندرويد، أو نزّل <strong className="text-cyan-300">الكود المصدري الأصلي الكامل (Native Kotlin)</strong> لرفعه على مستودع GitHub الخاص بك مع البناء التلقائي عبر GitHub Actions.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <img
              src="/app_icon.jpg"
              alt="KALBASO App Icon"
              className="w-20 h-20 sm:w-24 sm:h-24 rounded-2xl object-cover border-2 border-teal-400/50 shadow-2xl shadow-teal-500/20"
            />
          </div>
        </div>
      </div>

      {/* GitHub Actions 1-Click Builder Highlight Box */}
      <div className="p-5 sm:p-6 rounded-2xl bg-gradient-to-r from-amber-950/40 via-slate-950 to-orange-950/30 border border-amber-500/40 flex flex-col md:flex-row items-center justify-between gap-5 shadow-xl">
        <div className="space-y-1.5 text-right flex-1">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/40 text-xs font-bold font-mono">
            <Rocket className="w-3.5 h-3.5" />
            <span>حل مشكلة بناء الـ APK على GitHub (GitHub Actions CI/CD)</span>
          </div>
          <h2 className="text-base sm:text-lg font-bold text-white">
            بناء وتجميع APK تلقائياً على خوادم GitHub Actions بنقرة واحدة
          </h2>
          <p className="text-xs text-slate-300 leading-relaxed">
            تم تزويد الكود المصدري بملف <code className="text-amber-400 font-mono">.github/workflows/android_build.yml</code> و <code className="text-amber-400 font-mono">gradlew</code> جاهز تماماً. يمكنك الآن رفع المشروع كاملاً لمستودعك بنقرة زر ليقوم GitHub ببناء الـ APK تلقائياً بدون أي أخطاء وبدون الحاجة لـ Android Studio!
          </p>
        </div>

        <button
          onClick={onOpenGitHubActionsModal}
          className="shrink-0 flex items-center gap-2 py-3 px-5 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/30 active:scale-95 transition-all"
        >
          <Rocket className="w-4 h-4 text-slate-950" />
          <span>رفع وبناء APK في GitHub Actions 🚀</span>
        </button>
      </div>

      {/* Main Download Columns (APK on Left, Source Code on Right) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Left Column: Direct APK Download & QR Code */}
        <div className="rounded-2xl bg-slate-950 border border-emerald-500/30 p-6 sm:p-8 space-y-6 flex flex-col justify-between shadow-2xl">
          <div className="space-y-4">
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
                  <Smartphone className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-100">حزمة أندرويد (APK)</h3>
                  <span className="text-xs font-mono text-emerald-400">KALBASO-Termux-Studio.apk</span>
                </div>
              </div>

              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 font-mono">
                6.6 MB (حزمة كاملة أوفلاين موقّعة)
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              تطبيق أندرويد حقيقي أصلي 100% يحتوي على ملفات الواجهة والبرمجة داخلياً (مضمّنة بالكامل أوفلاين داخل الـ APK بدون حاجة لأي خادم خارجي). يفتح مباشرة في أجزاء من الثانية دون "Page not found"، وموقّع بشهادات v1/v2/v3 ومعتمد من AAPT.
            </p>

            {/* QR Code Card */}
            <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col sm:flex-row items-center gap-4 text-center sm:text-right">
              {qrCodeDataUrl ? (
                <div className="p-2 bg-white rounded-xl shadow-lg shrink-0">
                  <img src={qrCodeDataUrl} alt="APK QR Code" className="w-28 h-28" />
                </div>
              ) : (
                <div className="w-28 h-28 bg-slate-800 rounded-xl animate-pulse"></div>
              )}
              <div className="space-y-1">
                <span className="text-xs font-bold text-slate-200 flex items-center justify-center sm:justify-start gap-1.5">
                  <QrCode className="w-4 h-4 text-emerald-400" />
                  <span>تثبيت مباشر عبر كاميرا الجوال</span>
                </span>
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  وجّه كاميرا هاتفك نحو الرمز لتحميل ملف الـ APK والتثبيت خلال ثوانٍ معدودة دون الحاجة لتوصيل كابل USB.
                </p>
              </div>
            </div>

            {/* Direct Link Info */}
            <div className="space-y-1 text-xs font-mono">
              <span className="text-slate-400 text-[11px]">الرابط المباشر للملف:</span>
              <div className="flex items-center gap-2 bg-slate-900 rounded-lg p-2 border border-slate-800 text-slate-300 truncate">
                <span className="truncate flex-1 text-[11px] dir-ltr text-left">{apkDirectUrls.currentOriginUrl}</span>
                <button
                  onClick={() => copyToClipboard(apkDirectUrls.currentOriginUrl, 'apk-url')}
                  className="text-slate-400 hover:text-emerald-400"
                  title="نسخ الرابط"
                >
                  {copiedText === 'apk-url' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {apkDownloadSuccess && (
              <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
                <Check className="w-4 h-4 text-emerald-400" />
                <span>{apkDownloadSuccess}</span>
              </div>
            )}
          </div>

          <div className="space-y-2 pt-4">
            <button
              onClick={handleDownloadApk}
              disabled={isDownloadingApk}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloadingApk ? 'جارٍ التحميل...' : 'تنزيل ملف الـ APK الأصلي الآن (6.6 MB أوفلاين كامل)'}</span>
            </button>
            <p className="text-[10px] text-slate-500 text-center">
              ملاحظة: إذا ظهر تنبيه "تطبيق من مصدر غير معروف"، اضغط على "متابعة التثبيت" (Install Anyway).
            </p>
          </div>
        </div>

        {/* Right Column: Complete Native Android Kotlin Source Code for GitHub */}
        <div className="rounded-2xl bg-slate-950 border border-cyan-500/30 p-6 sm:p-8 space-y-6 flex flex-col justify-between shadow-2xl">
          <div className="space-y-4">
            
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
                  <GitBranch className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-100">كود المصدر لـ GitHub (Kotlin Native)</h3>
                  <span className="text-xs font-mono text-cyan-400">kalbaso-termux-studio-android-source.zip</span>
                </div>
              </div>

              <span className="text-xs font-bold px-2.5 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-300 font-mono">
                MIT License
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              حزمة مشروع أندرويد ستوديو كاملة بلغة Kotlin، مجهزة بملفات <code className="text-cyan-300 font-mono">AndroidManifest.xml</code> و <code className="text-cyan-300 font-mono">MainActivity.kt</code> وجسر الربط <code className="text-cyan-300 font-mono">TermuxBridge.kt</code> وملف README لـ GitHub.
            </p>

            {/* Included Files Checklist */}
            <div className="p-3.5 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1.5 text-xs font-mono">
              <span className="text-slate-400 font-sans block text-[11px] font-bold">الملفات المضمنة في الحزمة:</span>
              <div className="text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>app/src/main/AndroidManifest.xml (com.termux.permission.RUN_COMMAND)</span>
              </div>
              <div className="text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>app/src/main/java/.../MainActivity.kt & TermuxBridge.kt</span>
              </div>
              <div className="text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>CodeGenerator.kt (Classic, Cyberpunk, Dashboard)</span>
              </div>
              <div className="text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>build.gradle.kts & settings.gradle.kts</span>
              </div>
              <div className="text-cyan-300 flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span>README.md (GitHub Ready) & LICENSE (MIT)</span>
              </div>
            </div>

            {/* Quick Git Commands */}
            <div className="space-y-1 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-400 text-[11px] font-bold">أوامر الرفع المباشر إلى GitHub:</span>
                <button
                  onClick={() => copyToClipboard(gitPushCommands, 'git-cmds')}
                  className="text-cyan-400 hover:underline flex items-center gap-1 font-mono text-[11px]"
                >
                  {copiedText === 'git-cmds' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                  <span>نسخ الأوامر</span>
                </button>
              </div>
              <pre className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[10px] text-slate-300 overflow-x-auto whitespace-pre-wrap dir-ltr text-left">
                {gitPushCommands}
              </pre>
            </div>
          </div>

          <div className="space-y-2 pt-4">
            <button
              onClick={handleDownloadSourceZip}
              disabled={isDownloadingSource}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              <Download className="w-4 h-4" />
              <span>{isDownloadingSource ? 'جارٍ تجهيز الكود...' : 'تنزيل سورس كود Kotlin لـ GitHub (ZIP)'}</span>
            </button>
            <p className="text-[10px] text-slate-500 text-center">
              جاهز للفتح مباشرة في Android Studio وبناء الإصدار عبر <code className="text-slate-400 font-mono">./gradlew assembleRelease</code>
            </p>
          </div>
        </div>

      </div>

      {/* GitHub Releases Step-by-Step Guide */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-4">
        <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <GitFork className="w-5 h-5 text-teal-400" />
          <span>خطوات رفع ملف الـ APK وإنشاء Release على مستودع GitHub الخاص بك:</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-teal-400 font-bold block">1. إنشاء المستودع</span>
            <p className="text-slate-400 leading-relaxed">
              ادخل على GitHub واضغط New Repository باسم <code className="text-slate-300 font-mono">kalbaso-termux-studio</code> واختر Public.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-cyan-400 font-bold block">2. رفع الكود المصدري</span>
            <p className="text-slate-400 leading-relaxed">
              فك ضغط ملف الـ ZIP المحمل، واضغط "Upload files" على GitHub أو استعمل أوامر الـ Git الموضحة أعلاه.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-emerald-400 font-bold block">3. إنشاء Release</span>
            <p className="text-slate-400 leading-relaxed">
              من القائمة الجانبية في مستودعك اضغط على <strong>Releases</strong> ثم اضغط <strong>Draft a new release</strong>.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800 space-y-1.5">
            <span className="text-yellow-400 font-bold block">4. إرفاق ملف الـ APK</span>
            <p className="text-slate-400 leading-relaxed">
              اسحب ملف <code className="text-slate-300 font-mono">KALBASO-Termux-Studio.apk</code> وأفلته في المربع المخصص، واضغط <strong>Publish release</strong>.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
