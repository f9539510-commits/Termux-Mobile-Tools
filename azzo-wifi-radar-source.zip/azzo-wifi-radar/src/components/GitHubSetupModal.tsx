import React, { useState, useEffect } from 'react';
import { GitHubConfig, ToolConfig } from '../types/termuxStudio';
import { 
  loadGitHubConfig, 
  saveGitHubConfig, 
  testGitHubConnection, 
  pushFileToGitHubRepo,
  generateTermuxGitSetupScript,
  pushFullAndroidProjectToGitHub
} from '../utils/githubService';
import { generatePythonCode } from '../data/codeTemplates';
import { NATIVE_ANDROID_FILES } from '../data/nativeAndroidSource';
import { 
  GitBranch, 
  GitPullRequest, 
  Check, 
  AlertCircle, 
  Loader2, 
  X, 
  ShieldCheck, 
  ExternalLink, 
  Copy, 
  UploadCloud, 
  Terminal, 
  KeyRound, 
  User, 
  FolderGit2,
  Rocket,
  Cpu,
  Sparkles
} from 'lucide-react';

interface GitHubSetupModalProps {
  isOpen: boolean;
  onClose: () => void;
  toolConfig?: ToolConfig;
  onConfigUpdated?: (config: GitHubConfig) => void;
  initialTab?: 'setup' | 'push' | 'termuxScript' | 'pushProject';
}

export const GitHubSetupModal: React.FC<GitHubSetupModalProps> = ({
  isOpen,
  onClose,
  toolConfig,
  onConfigUpdated,
  initialTab = 'setup'
}) => {
  const [gitConfig, setGitConfig] = useState<GitHubConfig>(loadGitHubConfig());
  const [activeTab, setActiveTab] = useState<'setup' | 'push' | 'termuxScript' | 'pushProject'>(initialTab);
  const [isTesting, setIsTesting] = useState(false);
  const [isPushing, setIsPushing] = useState(false);
  const [isPushingProject, setIsPushingProject] = useState(false);
  const [projectProgress, setProjectProgress] = useState<{ current: number; total: number; currentFile: string } | null>(null);
  const [projectPushResult, setProjectPushResult] = useState<{ success: boolean; actionsUrl?: string; repoUrl?: string; msg?: string; error?: string } | null>(null);
  const [testResult, setTestResult] = useState<{ success: boolean; msg: string; user?: any } | null>(null);
  const [pushResult, setPushResult] = useState<{ success: boolean; url?: string; msg?: string } | null>(null);
  const [copiedScript, setCopiedScript] = useState(false);
  const [showToken, setShowToken] = useState(false);

  useEffect(() => {
    if (isOpen) {
      const cfg = loadGitHubConfig();
      setGitConfig(cfg);
      setTestResult(null);
      setPushResult(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTestConnection = async () => {
    if (!gitConfig.token.trim()) {
      setTestResult({ success: false, msg: 'يرجى إدخال التوكن (Personal Access Token) أولاً' });
      return;
    }

    setIsTesting(true);
    setTestResult(null);
    try {
      const res = await testGitHubConnection(gitConfig.token, gitConfig.username);
      if (res.success && res.user) {
        const updated: GitHubConfig = {
          ...gitConfig,
          username: res.user.login,
          email: res.user.email || gitConfig.email,
          avatarUrl: res.user.avatar_url,
          name: res.user.name || res.user.login,
          isConnected: true,
          lastTested: Date.now()
        };
        setGitConfig(updated);
        saveGitHubConfig(updated);
        onConfigUpdated?.(updated);
        setTestResult({
          success: true,
          msg: `تم التحقق بنجاح! مرحباً ${res.user.name || res.user.login} (${res.user.public_repos} مستودع عام)`,
          user: res.user
        });
      } else {
        setTestResult({ success: false, msg: res.error || 'فشل الاتصال بـ GitHub' });
      }
    } finally {
      setIsTesting(false);
    }
  };

  const handleSaveConfig = () => {
    saveGitHubConfig(gitConfig);
    onConfigUpdated?.(gitConfig);
    setTestResult({ success: true, msg: 'تم حفظ إعدادات GitHub بنجاح!' });
  };

  const handlePushCurrentFile = async () => {
    if (!gitConfig.isConnected || !gitConfig.token) {
      setActiveTab('setup');
      setTestResult({ success: false, msg: 'يرجى إعداد واختبار حساب GitHub أولاً' });
      return;
    }

    if (!toolConfig) return;

    setIsPushing(true);
    setPushResult(null);
    try {
      const pyCode = generatePythonCode(toolConfig);
      const repoName = gitConfig.defaultRepo || 'kalbaso-termux-tools';
      const filePath = `${toolConfig.toolSlug}.py`;

      const res = await pushFileToGitHubRepo({
        token: gitConfig.token,
        owner: gitConfig.username,
        repo: repoName,
        path: filePath,
        content: pyCode,
        commitMessage: `Add ${toolConfig.toolName} CLI (Built with KALBASO Termux Studio by ${toolConfig.author})`
      });

      if (res.success) {
        setPushResult({
          success: true,
          url: res.commitUrl,
          msg: `تم رفع ملف ${filePath} بنجاح إلى المستودع ${repoName}!`
        });
      } else {
        setPushResult({
          success: false,
          msg: res.error || 'فشل الرفع إلى GitHub'
        });
      }
    } finally {
      setIsPushing(false);
    }
  };

  const handlePushFullProject = async () => {
    if (!gitConfig.isConnected || !gitConfig.token) {
      setActiveTab('setup');
      setTestResult({ success: false, msg: 'يرجى إدخال التوكن والتحقق من حساب GitHub أولاً' });
      return;
    }

    setIsPushingProject(true);
    setProjectPushResult(null);
    setProjectProgress({ current: 0, total: NATIVE_ANDROID_FILES.length, currentFile: 'بدء رفع ملفات المشروع لـ GitHub...' });

    try {
      const repoName = gitConfig.defaultRepo || 'kalbaso-termux-studio';
      const res = await pushFullAndroidProjectToGitHub({
        token: gitConfig.token,
        owner: gitConfig.username,
        repo: repoName,
        projectFiles: NATIVE_ANDROID_FILES.map(f => ({ path: f.path, content: f.content })),
        onProgress: (current, total, path) => {
          setProjectProgress({ current, total, currentFile: path });
        }
      });

      if (res.success) {
        setProjectPushResult({
          success: true,
          actionsUrl: res.actionsUrl,
          repoUrl: res.repoUrl,
          msg: `تم رفع كامل ملفات المشروع (${res.pushedCount} ملف) بما في ذلك سكربت البناء التلقائي لـ GitHub Actions!`
        });
      } else {
        setProjectPushResult({
          success: false,
          error: res.error || 'تعذر استكمال الرفع. تحقق من صلاحيات الـ Token.'
        });
      }
    } catch (err: any) {
      setProjectPushResult({
        success: false,
        error: err?.message || 'حدث خطأ أثناء الاتصال بـ GitHub'
      });
    } finally {
      setIsPushingProject(false);
    }
  };

  const termuxScript = toolConfig
    ? generateTermuxGitSetupScript(gitConfig, toolConfig.toolSlug)
    : generateTermuxGitSetupScript(gitConfig, 'kalbaso_tool');

  const handleCopyScript = () => {
    navigator.clipboard.writeText(termuxScript);
    setCopiedScript(true);
    setTimeout(() => setCopiedScript(false), 2500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-[#030712] border border-cyan-500/40 rounded-3xl shadow-2xl p-6 sm:p-7 overflow-hidden text-right space-y-5">
        
        {/* Glow */}
        <div className="absolute -top-16 -left-16 w-48 h-48 bg-cyan-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 flex items-center justify-center">
            <GitBranch className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>إعداد حساب GitHub والرفع المباشر (GitHub Setup & Push)</span>
              {gitConfig.isConnected && (
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-mono">
                  متصل ✓
                </span>
              )}
            </h3>
            <p className="text-xs text-slate-400">
              ربط آمن عبر Personal Access Token مع حماية صلاحيات 600 في Termux
            </p>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 border-b border-slate-800 pb-2 text-xs font-semibold overflow-x-auto">
          <button
            onClick={() => setActiveTab('setup')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'setup'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            إعداد الحساب (Credentials)
          </button>

          <button
            onClick={() => setActiveTab('pushProject')}
            className={`px-3 py-1.5 rounded-xl transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'pushProject'
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Rocket className="w-3.5 h-3.5 text-amber-400" />
            <span>بناء APK تلقائياً في Actions</span>
          </button>

          <button
            onClick={() => setActiveTab('push')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'push'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            رفع الأداة (Push File)
          </button>

          <button
            onClick={() => setActiveTab('termuxScript')}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap ${
              activeTab === 'termuxScript'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            سكربت Termux الآمن (chmod 600)
          </button>
        </div>

        {/* Tab 1: Setup Account */}
        {activeTab === 'setup' && (
          <div className="space-y-4 pt-1">
            
            {/* User Profile Card if Connected */}
            {gitConfig.isConnected && gitConfig.avatarUrl && (
              <div className="p-3 rounded-2xl bg-slate-900/80 border border-emerald-500/30 flex items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <img src={gitConfig.avatarUrl} alt="Avatar" className="w-10 h-10 rounded-xl border border-slate-700" />
                  <div>
                    <span className="font-bold text-sm text-slate-200 block">{gitConfig.name || gitConfig.username}</span>
                    <span className="text-xs text-emerald-400 font-mono">@{gitConfig.username}</span>
                  </div>
                </div>
                <span className="text-xs text-emerald-400 font-bold flex items-center gap-1 font-mono">
                  <Check className="w-4 h-4" />
                  <span>تم التوثيق</span>
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              
              {/* Username */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5 text-cyan-400" />
                  <span>اسم المستخدم (GitHub Username)</span>
                </label>
                <input
                  type="text"
                  value={gitConfig.username}
                  onChange={(e) => setGitConfig({ ...gitConfig, username: e.target.value })}
                  placeholder="مثال: calypso-developer"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              {/* Default Repo */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <FolderGit2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>اسم المستودع الافتراضي (Repository)</span>
                </label>
                <input
                  type="text"
                  value={gitConfig.defaultRepo || ''}
                  onChange={(e) => setGitConfig({ ...gitConfig, defaultRepo: e.target.value })}
                  placeholder="مثال: my-termux-tools"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>
            </div>

            {/* Personal Access Token */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="text-xs font-semibold text-slate-300 flex items-center gap-1.5">
                  <KeyRound className="w-3.5 h-3.5 text-cyan-400" />
                  <span>رمز الوصول الشخصي (Personal Access Token - PAT)</span>
                </label>
                <a
                  href="https://github.com/settings/tokens/new?scopes=repo"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-[11px] text-cyan-400 hover:underline flex items-center gap-1"
                >
                  <span>إنشاء توكن جديد</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
              <div className="relative">
                <input
                  type={showToken ? 'text' : 'password'}
                  value={gitConfig.token}
                  onChange={(e) => setGitConfig({ ...gitConfig, token: e.target.value })}
                  placeholder="ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"
                  className="w-full pr-3.5 pl-16 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                />
                <button
                  type="button"
                  onClick={() => setShowToken(!showToken)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-slate-500 hover:text-slate-300"
                >
                  {showToken ? 'إخفاء' : 'إظهار'}
                </button>
              </div>
              <p className="text-[10px] text-slate-500">
                ملاحظة أمان: التوكن يُحفظ محلياً فقط ولا يُرسل لأي خادم وسيط، مع تأمين بصلاحيات 600 في Termux.
              </p>
            </div>

            {/* Test Connection Result */}
            {testResult && (
              <div className={`p-3 rounded-xl border text-xs flex items-center gap-2 ${
                testResult.success
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-red-500/20 border-red-500/40 text-red-300'
              }`}>
                {testResult.success ? <Check className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
                <span>{testResult.msg}</span>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex items-center gap-3 pt-2">
              <button
                onClick={handleTestConnection}
                disabled={isTesting || !gitConfig.token}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 px-4 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-cyan-500/20 active:scale-95 transition-all disabled:opacity-50"
              >
                {isTesting ? <Loader2 className="w-4 h-4 animate-spin" /> : <ShieldCheck className="w-4 h-4" />}
                <span>{isTesting ? 'جارٍ التحقق من التوكن...' : 'اختبار الاتصال بـ GitHub'}</span>
              </button>

              <button
                onClick={handleSaveConfig}
                className="px-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white text-xs font-semibold transition-colors"
              >
                حفظ الإعدادات
              </button>
            </div>

          </div>
        )}

        {/* Tab: Push Full Project & Auto-Build APK with GitHub Actions */}
        {activeTab === 'pushProject' && (
          <div className="space-y-4 pt-1">
            <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-500/30 space-y-3">
              <div className="flex items-center gap-2 text-amber-300 font-bold text-sm">
                <Rocket className="w-4 h-4 text-amber-400" />
                <span>البناء الآلي لـ APK عبر سيرفرات GitHub Actions</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                يقوم التطبيق برفع كامل ملفات مشروع الأندرويد الأصلي (Kotlin + Gradle 8.2 + workflow جاهز) مباشرة إلى مستودعك. بمجرد الرفع، سيبدأ GitHub Actions فوراً بتجميع وبناء ملف الـ APK وتوفيره للتحميل كـ Artifact رسمي بدون أي أخطاء وبدون الحاجة لـ Android Studio على حاسوبك!
              </p>
              
              <div className="p-2.5 rounded-xl bg-slate-950/80 border border-slate-800 text-[11px] font-mono text-slate-300 space-y-1">
                <div className="flex items-center justify-between">
                  <span className="text-emerald-400 font-bold">✓ workflow: .github/workflows/android_build.yml</span>
                  <span className="text-slate-500">Java 17 + Gradle 8.2</span>
                </div>
                <div className="text-slate-400">
                  المستودع المستهدف: <span className="text-cyan-300">{gitConfig.username || 'username'}/{gitConfig.defaultRepo || 'kalbaso-termux-studio'}</span>
                </div>
              </div>
            </div>

            {/* Target Repo Name Configuration */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
                <span>اسم المستودع على GitHub:</span>
                <span className="text-[10px] text-slate-500 font-mono">يتم إنشاؤه تلقائياً إن لم يكن موجوداً</span>
              </label>
              <input
                type="text"
                value={gitConfig.defaultRepo || 'kalbaso-termux-studio'}
                onChange={(e) => {
                  const updated = { ...gitConfig, defaultRepo: e.target.value };
                  setGitConfig(updated);
                  saveGitHubConfig(updated);
                }}
                className="w-full bg-slate-900 border border-slate-800 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-amber-400 font-mono"
                placeholder="kalbaso-termux-studio"
              />
            </div>

            {/* Upload Progress Bar */}
            {isPushingProject && projectProgress && (
              <div className="p-3.5 rounded-xl bg-slate-900/90 border border-amber-500/40 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-amber-300 font-bold flex items-center gap-1.5">
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    <span>جارٍ رفع ملفات المشروع...</span>
                  </span>
                  <span className="font-mono text-slate-400">
                    {projectProgress.current} / {projectProgress.total} ({Math.round((projectProgress.current / projectProgress.total) * 100)}%)
                  </span>
                </div>
                
                <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
                  <div 
                    className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-150"
                    style={{ width: `${Math.round((projectProgress.current / projectProgress.total) * 100)}%` }}
                  />
                </div>
                
                <p className="text-[10px] text-slate-400 font-mono truncate dir-ltr text-left">
                  {projectProgress.currentFile}
                </p>
              </div>
            )}

            {/* Result Message */}
            {projectPushResult && (
              <div className={`p-3.5 rounded-xl border text-xs space-y-2.5 ${
                projectPushResult.success
                  ? 'bg-emerald-500/15 border-emerald-500/40 text-emerald-300'
                  : 'bg-red-500/20 border-red-500/40 text-red-300'
              }`}>
                <div className="flex items-center gap-2">
                  {projectPushResult.success ? (
                    <Check className="w-4 h-4 text-emerald-400 shrink-0" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                  )}
                  <span className="font-bold">
                    {projectPushResult.msg || projectPushResult.error}
                  </span>
                </div>

                {projectPushResult.success && projectPushResult.actionsUrl && (
                  <div className="pt-1 flex flex-col sm:flex-row items-center gap-2">
                    <a
                      href={projectPushResult.actionsUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-full sm:w-auto flex-1 flex items-center justify-center gap-2 py-2 px-3 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-all shadow-md shadow-emerald-500/20"
                    >
                      <Rocket className="w-3.5 h-3.5" />
                      <span>فتح صفحة Actions لمتابعة البناء وتنزيل الـ APK 🚀</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>

                    {projectPushResult.repoUrl && (
                      <a
                        href={projectPushResult.repoUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="py-2 px-3 rounded-lg bg-slate-900 border border-slate-700 text-slate-300 hover:text-white text-xs font-mono flex items-center gap-1"
                      >
                        <span>المستودع</span>
                        <ExternalLink className="w-3 h-3" />
                      </a>
                    )}
                  </div>
                )}
              </div>
            )}

            <button
              onClick={handlePushFullProject}
              disabled={isPushingProject}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-amber-500 via-orange-500 to-amber-600 hover:from-amber-400 hover:to-orange-400 text-slate-950 font-black text-xs shadow-lg shadow-amber-500/25 active:scale-95 transition-all disabled:opacity-50"
            >
              {isPushingProject ? (
                <Loader2 className="w-4 h-4 animate-spin text-slate-950" />
              ) : (
                <Rocket className="w-4 h-4 text-slate-950" />
              )}
              <span>
                {isPushingProject
                  ? 'جارٍ رفع المشروع وتشغيل GitHub Actions...'
                  : 'رفع كامل المشروع وبدء البناء التلقائي لـ APK على GitHub 🚀'}
              </span>
            </button>
          </div>
        )}

        {/* Tab 2: Push File */}
        {activeTab === 'push' && (
          <div className="space-y-4 pt-1">
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
              <span className="text-xs font-bold text-slate-200 block">
                الملف الجاهز للرفع إلى المستودع:
              </span>
              <div className="flex items-center justify-between text-xs font-mono bg-slate-950 p-2.5 rounded-xl border border-slate-800 text-cyan-300">
                <span>{toolConfig ? `${toolConfig.toolSlug}.py` : 'my_tool.py'}</span>
                <span className="text-slate-500">المستودع: {gitConfig.defaultRepo || 'kalbaso-termux-tools'}</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                سيتم رفع الكود المولد للأداة الحالية مباشرة إلى فرع <code className="text-slate-300">main</code> في مستودعك الخاص دون الحاجة لأي أوامر يدوية.
              </p>
            </div>

            {pushResult && (
              <div className={`p-3 rounded-xl border text-xs space-y-1.5 ${
                pushResult.success
                  ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
                  : 'bg-red-500/20 border-red-500/40 text-red-300'
              }`}>
                <div className="flex items-center gap-2">
                  {pushResult.success ? <Check className="w-4 h-4 text-emerald-400 shrink-0" /> : <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />}
                  <span className="font-bold">{pushResult.msg}</span>
                </div>
                {pushResult.url && (
                  <a
                    href={pushResult.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-[11px] text-cyan-300 hover:underline font-mono"
                  >
                    <span>عرض الملف على GitHub</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                )}
              </div>
            )}

            <button
              onClick={handlePushCurrentFile}
              disabled={isPushing}
              className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/25 active:scale-95 transition-all disabled:opacity-50"
            >
              {isPushing ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
              <span>{isPushing ? 'جارٍ الرفع إلى مستودع GitHub...' : 'رفع الملف الآن إلى GitHub (Push File)'}</span>
            </button>
          </div>
        )}

        {/* Tab 3: Termux Script */}
        {activeTab === 'termuxScript' && (
          <div className="space-y-3 pt-1">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                <span>سكربت تهيئة وحماية التوكن (chmod 600) في Termux:</span>
              </span>
              <button
                onClick={handleCopyScript}
                className="text-xs text-cyan-400 hover:underline flex items-center gap-1 font-mono"
              >
                {copiedScript ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedScript ? 'تم النسخ!' : 'نسخ السكربت'}</span>
              </button>
            </div>

            <pre className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 font-mono text-[11px] text-emerald-400 max-h-48 overflow-y-auto whitespace-pre-wrap dir-ltr text-left">
              {termuxScript}
            </pre>
            <p className="text-[11px] text-slate-400">
              يقوم هذا السكربت بحفظ بيانات الاعتماد في <code className="text-yellow-400">~/.netrc</code> مع تطبيق تصريح الأمان الصارم <code className="text-emerald-400">chmod 600</code> بحيث لا يمكن لأي تطبيق آخر قراءته.
            </p>
          </div>
        )}

      </div>
    </div>
  );
};
