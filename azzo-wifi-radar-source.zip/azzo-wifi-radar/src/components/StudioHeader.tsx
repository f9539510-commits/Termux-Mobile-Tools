import React from 'react';
import { 
  Smartphone, 
  Layers, 
  Package, 
  Terminal, 
  Cpu, 
  GitFork, 
  LayoutDashboard, 
  Settings, 
  GitBranch, 
  Check 
} from 'lucide-react';
import { StorageTelemetryPill } from './StorageTelemetryWidget';

export type StudioTab = 'home' | 'templates' | 'packages' | 'generator' | 'bridge' | 'apk-github';


interface StudioHeaderProps {
  activeTab: StudioTab;
  onTabChange: (tab: StudioTab) => void;
  onOpenApkModal: () => void;
  onOpenStorageModal: () => void;
  onOpenGitHubModal: () => void;
  onOpenSettingsModal: () => void;
  isDownloadingApk?: boolean;
  isGitHubConnected?: boolean;
}

export const StudioHeader: React.FC<StudioHeaderProps> = ({
  activeTab,
  onTabChange,
  onOpenApkModal,
  onOpenStorageModal,
  onOpenGitHubModal,
  onOpenSettingsModal,
  isDownloadingApk = false,
  isGitHubConnected = false
}) => {
  return (
    <header className="sticky top-0 z-50 bg-[#030712]/95 backdrop-blur-md border-b border-emerald-500/20 shadow-2xl shadow-emerald-950/40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20 gap-3">
          
          {/* Logo & Identity */}
          <div className="flex items-center gap-3 cursor-pointer shrink-0" onClick={() => onTabChange('home')}>
            <div className="relative group">
              <div className="absolute -inset-1 bg-gradient-to-r from-emerald-500 to-cyan-500 rounded-2xl blur opacity-70 group-hover:opacity-100 transition duration-300"></div>
              <img
                src="/app_icon.jpg"
                alt="KALBASO Icon"
                className="relative w-11 h-11 sm:w-12 sm:h-12 rounded-xl object-cover border border-emerald-400/40 shadow-inner"
              />
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2">
                <span className="text-lg sm:text-2xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-cyan-300 to-purple-400 font-mono">
                  KALBASO
                </span>
                <span className="hidden xs:inline-block px-2 py-0.5 text-[10px] font-bold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 tracking-wider">
                  TERMUX STUDIO
                </span>
              </div>
              <p className="text-[11px] sm:text-xs text-slate-300 font-semibold flex items-center gap-1.5">
                <span>المطور:</span>
                <span className="text-emerald-400 font-bold">كالبسو مطروح (Calypsu)</span>
                <span className="text-sm sm:text-base">🇪🇬</span>
              </p>
            </div>
          </div>

          {/* Quick Header Actions (Telemetry Pill, GitHub, Settings, APK) */}
          <div className="flex items-center gap-2 sm:gap-2.5">
            
            {/* Storage Telemetry Compact Pill */}
            <StorageTelemetryPill onOpenModal={onOpenStorageModal} />

            {/* GitHub Setup Button */}
            <button
              onClick={onOpenGitHubModal}
              className={`inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl border text-xs font-semibold transition-all active:scale-95 ${
                isGitHubConnected
                  ? 'bg-cyan-500/15 border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/25'
                  : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-cyan-500/40 hover:text-cyan-300'
              }`}
              title="إعداد حساب GitHub ورفع الملفات"
            >
              <GitBranch className="w-3.5 h-3.5 text-cyan-400" />
              <span className="hidden sm:inline">GitHub</span>
              {isGitHubConnected && <Check className="w-3 h-3 text-emerald-400" />}
            </button>

            {/* Settings Modal Button */}
            <button
              onClick={onOpenSettingsModal}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-white hover:border-slate-700 transition-all active:scale-95"
              title="لوحة الإعدادات والتفضيلات"
            >
              <Settings className="w-4 h-4" />
            </button>

            {/* Quick Action: Download APK */}
            <button
              onClick={onOpenApkModal}
              disabled={isDownloadingApk}
              className="relative inline-flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 rounded-xl bg-gradient-to-r from-emerald-500 hover:from-emerald-400 to-teal-600 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all active:scale-95 disabled:opacity-50 shrink-0"
            >
              <Smartphone className="w-4 h-4" />
              <span>تثبيت APK</span>
              <span className="hidden md:inline-block px-1.5 py-0.5 text-[9px] bg-slate-950/20 rounded font-mono">
                أوفلاين
              </span>
            </button>
          </div>
        </div>

        {/* Navigation Tabs Bar */}
        <div className="flex items-center gap-1 sm:gap-2 overflow-x-auto py-2.5 scrollbar-none border-t border-slate-900/80 text-xs sm:text-sm font-semibold">
          
          {/* Tab 0: Home / Dashboard */}
          <button
            onClick={() => onTabChange('home')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'home'
                ? 'bg-slate-800 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <LayoutDashboard className="w-4 h-4 text-emerald-400" />
            <span>الرئيسية (اختصارات سريعة)</span>
          </button>

          <button
            onClick={() => onTabChange('templates')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'templates'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Layers className="w-4 h-4 text-emerald-400" />
            <span>قوالب الواجهات (3 Templates)</span>
          </button>

          <button
            onClick={() => onTabChange('packages')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'packages'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Package className="w-4 h-4 text-cyan-400" />
            <span>مدير مكتبات بايثون (pip)</span>
          </button>

          <button
            onClick={() => onTabChange('generator')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'generator'
                ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Terminal className="w-4 h-4 text-purple-400" />
            <span>مولد الكود ومحرر الطرفية</span>
          </button>

          <button
            onClick={() => onTabChange('bridge')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'bridge'
                ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Cpu className="w-4 h-4 text-yellow-400" />
            <span>ربط Termux:API و Intents</span>
          </button>

          <button
            onClick={() => onTabChange('apk-github')}
            className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg whitespace-nowrap transition-all ${
              activeTab === 'apk-github'
                ? 'bg-teal-500/20 text-teal-300 border border-teal-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <GitFork className="w-4 h-4 text-teal-400" />
            <span>حزمة APK وكود GitHub الأصلي</span>
          </button>
        </div>

      </div>
    </header>
  );
};
