import React, { useState, useEffect } from 'react';
import { 
  Download, 
  Smartphone, 
  Check, 
  Copy, 
  X, 
  QrCode, 
  Loader2, 
  CheckCircle2, 
  ShieldCheck, 
  Sparkles
} from 'lucide-react';
import { downloadApkWithFeedback, generateQrCode, getApkDirectUrls } from '../utils/apkDownloader';
import confetti from 'canvas-confetti';

interface InstallAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstallAppModal: React.FC<InstallAppModalProps> = ({ isOpen, onClose }) => {
  const [copiedLink, setCopiedLink] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [statusType, setStatusType] = useState<'loading' | 'success' | 'error' | null>(null);
  const [qrCodeDataUrl, setQrCodeDataUrl] = useState<string>('');

  const directUrls = getApkDirectUrls('KALBASO-Termux-Studio.apk');

  useEffect(() => {
    generateQrCode(window.location.href).then(dataUrl => {
      if (dataUrl) setQrCodeDataUrl(dataUrl);
    });
  }, []);

  if (!isOpen) return null;

  const handleDownloadApkClick = async () => {
    setDownloading(true);
    setStatusType('loading');
    setStatusMessage('جارٍ قراءة حزمة APK وبدء التحميل إلى جهازك...');

    await downloadApkWithFeedback('KALBASO-Termux-Studio.apk', (status, msg) => {
      setStatusType(status);
      setStatusMessage(msg);
      if (status === 'success') {
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.6 }
          });
        } catch {}
      }
    });

    setDownloading(false);
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(directUrls.currentOriginUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-[#030712] border border-emerald-500/30 rounded-3xl shadow-2xl p-6 sm:p-8 overflow-hidden text-right">
        
        {/* Glow */}
        <div className="absolute -top-16 -left-16 w-48 h-48 bg-emerald-500/15 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900/60 hover:bg-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3.5 mb-5">
          <img
            src="/app_icon.jpg"
            alt="KALBASO Icon"
            className="w-12 h-12 rounded-xl object-cover border border-emerald-400/40 shadow-md shrink-0"
          />
          <div>
            <h3 className="text-xl font-bold text-white">تثبيت KALBASO Termux Studio</h3>
            <p className="text-xs text-slate-400">حزمة أندرويد أصلية (APK) جاهزة للتثبيت الفوري</p>
          </div>
        </div>

        {/* Download Status Toast */}
        {statusMessage && (
          <div className={`mb-4 p-3 rounded-2xl border text-xs flex items-center gap-2.5 ${
            statusType === 'success'
              ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
              : statusType === 'error'
              ? 'bg-amber-500/20 border-amber-500/40 text-amber-300'
              : 'bg-cyan-500/20 border-cyan-500/40 text-cyan-300'
          }`}>
            {statusType === 'loading' ? (
              <Loader2 className="w-4 h-4 animate-spin text-cyan-400 shrink-0" />
            ) : statusType === 'success' ? (
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            ) : (
              <ShieldCheck className="w-4 h-4 text-amber-400 shrink-0" />
            )}
            <span>{statusMessage}</span>
          </div>
        )}

        {/* Master APK Card */}
        <div className="bg-slate-900/80 p-5 rounded-2xl border border-slate-800 mb-5 space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <span className="font-bold text-sm text-white block">KALBASO-Termux-Studio.apk</span>
              <span className="text-[11px] text-emerald-400 font-mono">v1.0.0 • 6.6 MB • حزمة كاملة أوفلاين • مطروح (Calypsu)</span>
            </div>
            <span className="px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
              تثبيت مباشر
            </span>
          </div>

          <button
            onClick={handleDownloadApkClick}
            disabled={downloading}
            className="w-full flex items-center justify-center gap-2.5 py-3.5 rounded-xl font-bold text-sm bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 transition-all shadow-lg shadow-emerald-500/20 active:scale-95 disabled:opacity-50"
          >
            {downloading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>جارٍ التحميل إلى جهازك...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>بدء تنزيل ملف APK الآن (6.6 MB أوفلاين كامل)</span>
              </>
            )}
          </button>
        </div>

        {/* QR Code Option */}
        <div className="flex items-center gap-4 p-3 bg-slate-900/60 rounded-2xl border border-slate-800/80 mb-5">
          {qrCodeDataUrl ? (
            <img src={qrCodeDataUrl} alt="QR Code" className="w-16 h-16 rounded-lg bg-white p-1 shrink-0" />
          ) : (
            <div className="w-16 h-16 rounded-lg bg-slate-800 flex items-center justify-center shrink-0">
              <QrCode className="w-6 h-6 text-slate-400" />
            </div>
          )}
          <div className="flex-1 text-xs">
            <span className="font-bold text-slate-200 block mb-0.5">امسح الرمز بكاميرا الموبايل</span>
            <span className="text-slate-400 text-[11px] block">
              لتنزيل الـ APK وتثبيته فوراً على هاتفك دون حاجة لتوصيل أسلاك أو كمبيوتر
            </span>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-800 text-xs">
          <button
            onClick={handleCopyLink}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedLink ? 'تم نسخ الرابط' : 'نسخ رابط التحميل المباشر'}</span>
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
};
