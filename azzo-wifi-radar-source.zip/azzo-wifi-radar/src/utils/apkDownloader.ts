import QRCode from 'qrcode';

export interface ApkDownloadResult {
  success: boolean;
  message: string;
  blobUrl?: string;
  dataUrl?: string;
  directUrl: string;
}

const DEV_URL = 'https://ais-dev-ggq4cumglar2uomvpgrrsa-937758980381.europe-west2.run.app';
const PREVIEW_URL = 'https://ais-pre-ggq4cumglar2uomvpgrrsa-937758980381.europe-west2.run.app';

export function getApkDirectUrls(fileName: string = 'Ezzo-Networks.apk') {
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  return {
    relative: `/${fileName}`,
    currentOriginUrl: `${currentOrigin}/${fileName}`,
    previewUrl: `${PREVIEW_URL}/${fileName}`,
    devUrl: `${DEV_URL}/${fileName}`,
  };
}

export function getSourceZipDirectUrls() {
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  const fileName = 'azzo-wifi-radar-source.zip';
  return {
    relative: `/${fileName}`,
    currentOriginUrl: `${currentOrigin}/${fileName}`,
    previewUrl: `${PREVIEW_URL}/${fileName}`,
    devUrl: `${DEV_URL}/${fileName}`,
  };
}

export function getReadmeDirectUrls() {
  const currentOrigin = typeof window !== 'undefined' ? window.location.origin : '';
  return {
    relative: `/README.md`,
    currentOriginUrl: `${currentOrigin}/README.md`,
    previewUrl: `${PREVIEW_URL}/README.md`,
    devUrl: `${DEV_URL}/README.md`,
  };
}

/**
 * Robust multi-layer APK downloader that survives sandboxed iframes.
 */
export async function downloadApkWithFeedback(
  fileName: string = 'Ezzo-Networks.apk',
  onStatusChange?: (status: 'loading' | 'success' | 'error', message: string) => void
): Promise<ApkDownloadResult> {
  try {
    onStatusChange?.('loading', 'جارٍ قراءة حزمة تطبيق عزو شبكات وتجهيز التثبيت لهاتفك...');

    const directUrls = getApkDirectUrls(fileName);
    
    // Fetch binary APK
    const response = await fetch(directUrls.relative);
    if (!response.ok) {
      // try fallback to Ezzo-Security-Research.apk
      const fallbackRes = await fetch('/Ezzo-Security-Research.apk');
      if (!fallbackRes.ok) {
        throw new Error(`تعذر جلب ملف تطبيق عزو شبكات (${response.status})`);
      }
      const fallbackBlob = await fallbackRes.blob();
      const typedBlob = new Blob([fallbackBlob], { type: 'application/vnd.android.package-archive' });
      const blobUrl = window.URL.createObjectURL(typedBlob);

      const link = document.createElement('a');
      link.href = blobUrl;
      link.setAttribute('download', fileName);
      link.style.display = 'none';
      document.body.appendChild(link);
      link.click();
      setTimeout(() => {
        try {
          document.body.removeChild(link);
          window.URL.revokeObjectURL(blobUrl);
        } catch {}
      }, 5000);

      onStatusChange?.('success', 'تم بدء تحميل حزمة APK بنجاح إلى هاتفك!');
      return { success: true, message: 'تم التحميل بنجاح', directUrl: directUrls.previewUrl };
    }

    const blob = await response.blob();
    const typedBlob = new Blob([blob], { type: 'application/vnd.android.package-archive' });
    const blobUrl = window.URL.createObjectURL(typedBlob);

    // Method: Programmatic anchor download
    const link = document.createElement('a');
    link.href = blobUrl;
    link.setAttribute('download', fileName);
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();

    setTimeout(() => {
      try {
        document.body.removeChild(link);
        window.URL.revokeObjectURL(blobUrl);
      } catch {
        // ignore cleanup error
      }
    }, 5000);

    onStatusChange?.('success', 'تم بدء تحميل حزمة APK بنجاح إلى هاتفك!');

    return {
      success: true,
      message: 'تم إرسال أمر التنزيل بنجاح',
      blobUrl,
      directUrl: directUrls.previewUrl
    };
  } catch (err: any) {
    console.error('Download error:', err);

    onStatusChange?.('error', 'تم تفعيل الرابط المباشر للتحميل.');
    return {
      success: false,
      message: err?.message || 'فشل التنزيل التلقائي',
      directUrl: getApkDirectUrls(fileName).previewUrl
    };
  }
}

/**
 * Generates high-res QR code image for scanning with phone camera
 */
export async function generateQrCode(text: string): Promise<string> {
  try {
    return await QRCode.toDataURL(text, {
      width: 280,
      margin: 2,
      color: {
        dark: '#059669',
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    });
  } catch (err) {
    console.error('Failed to generate QR code', err);
    return '';
  }
}
