import React, { useState } from 'react';
import { Cpu, Terminal, ShieldCheck, Copy, Check, ExternalLink, AlertTriangle, ArrowRight, Smartphone, Zap } from 'lucide-react';
import { runCommandInTermux, openTermuxApp } from '../utils/termuxBridge';

export const TermuxBridgeView: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [testNotification, setTestNotification] = useState<string | null>(null);

  const copyText = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2500);
  };

  const setupPropertiesCommand = `mkdir -p ~/.termux && echo "allow-external-apps = true" >> ~/.termux/termux.properties && termux-reload-settings`;

  const installPipCommand = `pkg update -y && pkg install -y python python-pip git`;

  const testIntentCommand = `am start -a com.termux.RUN_COMMAND --es com.termux.RUN_COMMAND_PATH "/data/data/com.termux/files/usr/bin/echo" --esa com.termux.RUN_COMMAND_ARGUMENTS "KALBASO_TERMUX_ONLINE" --es com.termux.RUN_COMMAND_WORKDIR "/data/data/com.termux/files/home" --ez com.termux.RUN_COMMAND_BACKGROUND "false"`;

  const handleTriggerTestIntent = async () => {
    const res = await runCommandInTermux('echo "[+] KALBASO Termux Studio Connected Successfully!"');
    setTestNotification(res.message);
    setTimeout(() => setTestNotification(null), 4000);
  };

  const handleOpenTermuxDirectly = () => {
    openTermuxApp();
    setTestNotification('تم طلب فتح تطبيق Termux');
    setTimeout(() => setTestNotification(null), 3500);
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-950 to-[#030712] border border-yellow-500/30 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-yellow-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

        <div className="space-y-2 text-right">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 text-xs font-bold font-mono">
            <Cpu className="w-3.5 h-3.5" />
            <span>ربط تيرمكس الحقيقي (Native Android Intent & Termux:API)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
            بروتوكول الربط المباشر مع تطبيق Termux على أندرويد
          </h1>
          <p className="text-sm text-slate-400 max-w-3xl leading-relaxed">
            يستخدم تطبيق <strong className="text-yellow-300">KALBASO Termux Studio</strong> تصريح أندرويد الرسمي <code className="text-yellow-400 font-mono">com.termux.permission.RUN_COMMAND</code> للتحكم في تيرمكس وإرسال أوامر تشغيل السكربتات وتثبيت حزم <code className="text-cyan-400 font-mono">pip</code> تلقائياً في الخلفية أو الواجهة الأمامية دون وسيط.
          </p>
        </div>
      </div>

      {/* 3 Steps Setup Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* Step 1 */}
        <div className="rounded-2xl bg-slate-950/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 flex items-center justify-center font-bold text-sm">
              1
            </span>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              خطوة واحدة
            </span>
          </div>
          <h3 className="font-bold text-slate-100 text-base">
            تفعيل استقبال الأوامر الخارجية في تيرمكس
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            افتراضيًا، يحمي تيرمكس نفسه من التطبيقات الخارجية. لتفعيل الربط التلقائي، شغّل هذا الأمر مرة واحدة فقط داخل تيرمكس:
          </p>
          <div className="space-y-2">
            <pre className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-yellow-300 overflow-x-auto whitespace-pre-wrap break-all dir-ltr text-left">
              {setupPropertiesCommand}
            </pre>
            <button
              onClick={() => copyText(setupPropertiesCommand, 'step1')}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 hover:bg-yellow-500/30 text-xs font-bold transition-all"
            >
              {copiedId === 'step1' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId === 'step1' ? 'تم النسخ!' : 'نسخ أمر التفعيل'}</span>
            </button>
          </div>
        </div>

        {/* Step 2 */}
        <div className="rounded-2xl bg-slate-950/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center font-bold text-sm">
              2
            </span>
            <span className="text-[11px] font-mono text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded-full border border-cyan-500/20">
              بيئة بايثون
            </span>
          </div>
          <h3 className="font-bold text-slate-100 text-base">
            التأكد من تثبيت Python و pip
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            تأكد أن بيئة بايثون 3 ومدير الحزم pip مثبتان في تيرمكس لتشغيل الأدوات والمكتبات المولدة بسلاسة:
          </p>
          <div className="space-y-2">
            <pre className="p-3 rounded-xl bg-slate-900 border border-slate-800 font-mono text-[11px] text-cyan-300 overflow-x-auto whitespace-pre-wrap break-all dir-ltr text-left">
              {installPipCommand}
            </pre>
            <button
              onClick={() => copyText(installPipCommand, 'step2')}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-lg bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30 text-xs font-bold transition-all"
            >
              {copiedId === 'step2' ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{copiedId === 'step2' ? 'تم النسخ!' : 'نسخ أمر تثبيت Python'}</span>
            </button>
          </div>
        </div>

        {/* Step 3 */}
        <div className="rounded-2xl bg-slate-950/80 border border-slate-800 p-6 space-y-4">
          <div className="flex items-center justify-between">
            <span className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center font-bold text-sm">
              3
            </span>
            <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
              اختبار فوري
            </span>
          </div>
          <h3 className="font-bold text-slate-100 text-base">
            فحص تشغيل الـ Intent
          </h3>
          <p className="text-xs text-slate-400 leading-relaxed">
            اضغط زر الاختبار لإرسال Intent حي إلى تطبيق Termux للتأكد من استجابته الفورية:
          </p>
          <div className="space-y-2 pt-2">
            <button
              onClick={handleTriggerTestIntent}
              className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
            >
              <Zap className="w-4 h-4" />
              <span>إرسال Intent اختباري إلى تيرمكس</span>
            </button>

            <button
              onClick={handleOpenTermuxDirectly}
              className="w-full flex items-center justify-center gap-2 py-2 rounded-xl bg-slate-900 border border-yellow-500/30 hover:border-yellow-500/60 text-yellow-300 text-xs font-bold transition-all active:scale-95"
            >
              <Smartphone className="w-4 h-4 text-yellow-400" />
              <span>فتح تطبيق Termux على الهاتف الآن</span>
            </button>

            <button
              onClick={() => copyText(testIntentCommand, 'step3')}
              className="w-full text-center text-[11px] text-slate-400 hover:text-slate-200 transition-colors py-1"
            >
              أو نسخ أمر ADB / Terminal للاختبار اليدوي
            </button>
          </div>

          {testNotification && (
            <div className="p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{testNotification}</span>
            </div>
          )}
        </div>

      </div>

      {/* Technical Architecture Specs */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6">
        <h2 className="text-lg font-bold text-slate-100 flex items-center gap-2">
          <ShieldCheck className="w-5 h-5 text-emerald-400" />
          <span>المعايير التقنية المستخدمة في تطبيق أندرويد الأصلي (Architecture Details)</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <span className="text-yellow-400 font-mono font-bold block">1. Service Component Target</span>
            <p className="text-slate-300 font-mono">com.termux/.app.RunCommandService</p>
            <p className="text-slate-400 leading-relaxed">
              الخدمة الرسمية في تيرمكس لاستقبال ومعالجة أوامر التطبيقات الخارجية دون فتح نوافذ عشوائية.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <span className="text-cyan-400 font-mono font-bold block">2. Android Permission</span>
            <p className="text-slate-300 font-mono">com.termux.permission.RUN_COMMAND</p>
            <p className="text-slate-400 leading-relaxed">
              التصريح المعرّف في AndroidManifest.xml المدمج تلقائياً في حزمة الـ APK وكود Kotlin.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <span className="text-emerald-400 font-mono font-bold block">3. Execution Work Directory</span>
            <p className="text-slate-300 font-mono">/data/data/com.termux/files/home</p>
            <p className="text-slate-400 leading-relaxed">
              المجلد الرئيسي الافتراضي (HOME~) لضمان حفظ الملفات وتشغيل أوامر بايثون بصلاحيات المستخدم التامة.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-950 border border-slate-800/80 space-y-2">
            <span className="text-purple-400 font-mono font-bold block">4. Foreground Session Action</span>
            <p className="text-slate-300 font-mono">EXTRA_RUN_COMMAND_SESSION_ACTION = "0"</p>
            <p className="text-slate-400 leading-relaxed">
              يفتح جلسة تيرمكس في الواجهة التفاعلية ليتمكن المستخدم من رؤية تقدم التثبيت وإدخال البيانات مباشرة.
            </p>
          </div>
        </div>
      </div>

    </div>
  );
};
