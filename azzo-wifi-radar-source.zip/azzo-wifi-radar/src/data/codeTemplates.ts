import { ToolConfig, TemplateType } from '../types/termuxStudio';

export const ASCII_BANNERS: Record<string, string> = {
  cyber: `
██╗  ██╗ █████╗ ██╗     ██████╗  █████╗ ███████╗ ██████╗ 
██║ ██╔╝██╔══██╗██║     ██╔══██╗██╔══██╗██╔════╝██╔═══██╗
█████╔╝ ███████║██║     ██████╔╝███████║███████╗██║   ██║
██╔═██╗ ██╔══██║██║     ██╔══██╗██╔══██║╚════██║██║   ██║
██║  ██╗██║  ██║███████╗██████╔╝██║  ██║███████║╚██████╔╝
╚═╝  ╚═╝╚═╝  ╚═╝╚══════╝╚═════╝ ╚═╝  ╚═╝╚══════╝ ╚═════╝ 
`,
  hacker: `
   _  __ ___   __   ___   ___   ___  ___  
  | |/ // _ | / /  / _ ) / _ | / __|/ _ \\ 
  | ' // __ |/ /__/ _  |/ __ |_\\__ \\ (_) |
  |_|\\_/_/ |_/____/____/_/ |_(_)___/\\___/ 
`,
  matrix: `
 [ KALBASO TERMUX CORE // v3.12 ]
 +========================================+
 |  [01010010 01010101 01001110]         |
 |  >>> TERMINAL INITIALIZED SECURELY     |
 +========================================+
`,
  shield: `
       /\\
      /  \\
     / /\\ \\     KALBASO
    / /__\\ \\    STUDIO
   / /____\\ \\   PROTECTED
  /_/      \\_\\
`,
  fire: `
 (   (       )       ) (       )   (      
 )\\ ))\\ ) ( /(    ( /( )\\ ) ( /(   )\\ )   
(()/(()/( )\\())   )\\()(()/( )\\()) (()/(   
 /(_))(_)|(_)\\   ((_)\\ /(_)|(_)\\   /(_))  
(_))(_))  _((_)   _((_|_))  _((_) (_))    
| |/ /   / _ \\   | |_) | | | | |  / __|   
| ' <   | (_) |  |  _ <  |_| | | |\\__ \\   
|_|\\_\\   \\___/   |_| \\_\\_____/ |_||___/   
`
};

export function generatePythonCode(config: ToolConfig): string {
  switch (config.template) {
    case 'cyberpunk':
      return generateCyberpunkTemplate(config);
    case 'dashboard':
      return generateDashboardTemplate(config);
    case 'classic':
    default:
      return generateClassicTemplate(config);
  }
}

function getSelectedBanner(config: ToolConfig): string {
  if (config.bannerType === 'custom' && config.customBannerText?.trim()) {
    return config.customBannerText.trim();
  }
  return (ASCII_BANNERS[config.bannerType] || ASCII_BANNERS.cyber).trim();
}

/**
 * 1. Classic Template (Clean, Lightweight, High Performance)
 */
function generateClassicTemplate(config: ToolConfig): string {
  const banner = getSelectedBanner(config);
  const pkgImports = config.selectedPackages.map(p => `# import ${p}`).join('\n');

  return `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
 ${config.toolName} v${config.version}
 Developer: ${config.author}
 Built with KALBASO Termux Studio
 Description: ${config.description}
====================================================================
"""

import sys
import os
import time
import platform

# Library imports (optional dependencies)
${pkgImports}

# ANSI Color Codes (Native Termux Support)
class Colors:
    RESET   = "\\033[0m"
    BOLD    = "\\033[1m"
    GREEN   = "\\033[32m"
    RED     = "\\033[31m"
    YELLOW  = "\\033[33m"
    BLUE    = "\\033[34m"
    CYAN    = "\\033[36m"
    WHITE   = "\\033[37m"

BANNER = """${banner}"""

def clear_screen():
    os.system("clear" if os.name != "nt" else "cls")

def print_header():
    clear_screen()
    print(Colors.CYAN + BANNER + Colors.RESET)
    print(Colors.BOLD + f"[*] Tool: {Colors.GREEN}${config.toolName}{Colors.RESET} | Version: {Colors.YELLOW}v${config.version}{Colors.RESET}")
    print(Colors.BOLD + f"[*] Author: {Colors.CYAN}${config.author}{Colors.RESET} | Platform: {Colors.WHITE}{platform.system()}{Colors.RESET}")
    print(Colors.BLUE + "=" * 55 + Colors.RESET)

def show_menu():
    print(Colors.BOLD + "\\n[+] MAIN MENU:" + Colors.RESET)
    print(f" {Colors.GREEN}[1]{Colors.RESET} ${config.menuItems[0]?.labelEn || 'Run Primary Task'} (${config.menuItems[0]?.labelAr || 'تشغيل المهمة الأساسية'})")
    print(f" {Colors.GREEN}[2]{Colors.RESET} ${config.menuItems[1]?.labelEn || 'System Information'} (${config.menuItems[1]?.labelAr || 'فحص معلومات النظام'})")
    print(f" {Colors.GREEN}[3]{Colors.RESET} ${config.menuItems[2]?.labelEn || 'Tool Configuration'} (${config.menuItems[2]?.labelAr || 'إعدادات الأداة'})")
    print(f" {Colors.RED}[0]{Colors.RESET} Exit (${'خروج'})")
    print(Colors.BLUE + "-" * 55 + Colors.RESET)

def handle_primary_task():
    print(Colors.YELLOW + "\\n[*] Executing primary routine..." + Colors.RESET)
    for i in range(1, 4):
        print(f"  --> Step {i}/3: Initializing module {i}...")
        time.sleep(0.4)
    print(Colors.GREEN + "[SUCCESS] Task completed flawlessly!\\n" + Colors.RESET)
    input(Colors.WHITE + "Press Enter to return to menu..." + Colors.RESET)

def handle_system_info():
    print(Colors.CYAN + "\\n[*] Host Diagnostics:" + Colors.RESET)
    print(f"  • Python Version : {platform.python_version()}")
    print(f"  • Operating System: {platform.system()} {platform.release()}")
    print(f"  • Architecture    : {platform.machine()}")
    print(f"  • Current Dir     : {os.getcwd()}")
    print(Colors.GREEN + "[OK] Diagnostics check passed.\\n" + Colors.RESET)
    input(Colors.WHITE + "Press Enter to return to menu..." + Colors.RESET)

def handle_config():
    print(Colors.YELLOW + "\\n[*] Active Dependencies:" + Colors.RESET)
${config.selectedPackages.length ? config.selectedPackages.map(p => `    print(f"  • ${p}: [INSTALLED]")`).join('\n') : '    print("  • Standard Library (Zero External Dependencies)")'}
    print(Colors.GREEN + "\\nAll system hooks are active.\\n" + Colors.RESET)
    input(Colors.WHITE + "Press Enter to return to menu..." + Colors.RESET)

def main():
    while True:
        try:
            print_header()
            show_menu()
            choice = input(Colors.BOLD + Colors.GREEN + "${config.toolSlug} > " + Colors.RESET).strip()

            if choice == "1":
                handle_primary_task()
            elif choice == "2":
                handle_system_info()
            elif choice == "3":
                handle_config()
            elif choice in ["0", "exit", "quit", "q"]:
                print(Colors.YELLOW + "\\nExiting ${config.toolName}. Goodbye!\\n" + Colors.RESET)
                sys.exit(0)
            else:
                print(Colors.RED + "\\n[!] Invalid choice, please try again." + Colors.RESET)
                time.sleep(1)
        except KeyboardInterrupt:
            print(Colors.RED + "\\n\\n[!] Process terminated by user. Goodbye!\\n" + Colors.RESET)
            sys.exit(0)

if __name__ == "__main__":
    main()
`;
}

/**
 * 2. Cyberpunk Template (Vibrant Neon, ASCII Frames, Glitch Effects)
 */
function generateCyberpunkTemplate(config: ToolConfig): string {
  const banner = getSelectedBanner(config);

  return `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
 ${config.toolName} - CYBERPUNK EDITION
 Developer: ${config.author} | Version: ${config.version}
 Engineered with KALBASO Termux Studio
 Description: ${config.description}
====================================================================
"""

import sys
import os
import time
import random
import platform

class CyberColors:
    RESET       = "\\033[0m"
    BOLD        = "\\033[1m"
    NEON_CYAN   = "\\033[96m"
    NEON_PINK   = "\\033[95m"
    NEON_GREEN  = "\\033[92m"
    NEON_YELLOW = "\\033[93m"
    NEON_RED    = "\\033[91m"
    DARK_BG     = "\\033[100m"

BANNER = """${banner}"""

def cyber_print(text, delay=0.015, color=CyberColors.NEON_CYAN):
    for char in text:
        sys.stdout.write(color + char + CyberColors.RESET)
        sys.stdout.flush()
        time.sleep(delay)
    print()

def progress_bar(task_name="BOOTING NEURAL MATRIX", total=20):
    print(CyberColors.NEON_PINK + f"[*] {task_name}:" + CyberColors.RESET)
    for i in range(total + 1):
        percent = int((i / total) * 100)
        filled = "#" * i
        empty = "-" * (total - i)
        sys.stdout.write(f"\\r  {CyberColors.NEON_GREEN}[{filled}{CyberColors.NEON_CYAN}{empty}{CyberColors.NEON_GREEN}] {percent}%{CyberColors.RESET}")
        sys.stdout.flush()
        time.sleep(0.04)
    print("\\n")

def clear_screen():
    os.system("clear" if os.name != "nt" else "cls")

def print_cyber_header():
    clear_screen()
    print(CyberColors.NEON_PINK + "╔" + "═" * 60 + "╗" + CyberColors.RESET)
    print(CyberColors.NEON_CYAN + BANNER + CyberColors.RESET)
    print("║ " + CyberColors.BOLD + "${config.toolName}" + CyberColors.RESET + "  " + CyberColors.NEON_YELLOW + "v${config.version}" + CyberColors.RESET + " | DEV: " + CyberColors.NEON_GREEN + "${config.author}" + CyberColors.RESET + " | STATUS: " + CyberColors.NEON_CYAN + "ONLINE 97% SECURE" + CyberColors.RESET + " ║")
    print(CyberColors.NEON_PINK + "╚" + "═" * 60 + "╝" + CyberColors.RESET)

def show_cyber_menu():
    print(f"\\n{CyberColors.NEON_CYAN}┌──[ KALBASO COMMAND DECK ]{CyberColors.RESET}")
    print(f"{CyberColors.NEON_CYAN}│{CyberColors.RESET}  {CyberColors.NEON_GREEN}[1]{CyberColors.RESET} ${config.menuItems[0]?.labelEn || 'Cyber Breach Scan'} :: ${config.menuItems[0]?.labelAr || 'تشغيل الفحص الرئيسي'}")
    print(f"{CyberColors.NEON_CYAN}│{CyberColors.RESET}  {CyberColors.NEON_YELLOW}[2]{CyberColors.RESET} ${config.menuItems[1]?.labelEn || 'Hardware Pulse & Termux'} :: ${config.menuItems[1]?.labelAr || 'فحص موارد تيرمكس'}")
    print(f"{CyberColors.NEON_CYAN}│{CyberColors.RESET}  {CyberColors.NEON_PINK}[3]{CyberColors.RESET} ${config.menuItems[2]?.labelEn || 'Neural Packages Monitor'} :: ${config.menuItems[2]?.labelAr || 'إدارة الحزم والمكتبات'}")
    print(f"{CyberColors.NEON_CYAN}│{CyberColors.RESET}  {CyberColors.NEON_RED}[0]{CyberColors.RESET} Disconnect Deck :: خروج آمن")
    print(f"{CyberColors.NEON_CYAN}└──>{CyberColors.RESET}")

def run_cyber_scan():
    print(CyberColors.NEON_PINK + "\\n[!] INITIATING SECURE SEQUENCE..." + CyberColors.RESET)
    progress_bar("SYNCHRONIZING APIS", total=25)
    
    nodes = ["127.0.0.1:8080", "termux.internal.sock", "python3.12/core"]
    for node in nodes:
        latency = random.randint(12, 45)
        print(f"  {CyberColors.NEON_GREEN}[ACTIVE]{CyberColors.RESET} Node: {node} --> Ping: {CyberColors.NEON_YELLOW}{latency}ms{CyberColors.RESET}")
        time.sleep(0.2)
        
    print(f"\\n{CyberColors.NEON_CYAN}[+] SUCCESS: Protocol executed without alerts.{CyberColors.RESET}\\n")
    input(CyberColors.BOLD + "Press Enter to return to deck..." + CyberColors.RESET)

def run_pulse():
    print(CyberColors.NEON_YELLOW + "\\n[~] SYSTEM TELEMETRY:" + CyberColors.RESET)
    print(f"  ├── Host OS      : {platform.system()} {platform.release()}")
    print(f"  ├── Architecture : {platform.machine()}")
    print(f"  ├── Interpreter  : Python {platform.python_version()}")
    print(f"  └── Environment  : Termux POSIX Shell")
    print(f"\\n{CyberColors.NEON_GREEN}[OK] Core temperatures optimal.{CyberColors.RESET}\\n")
    input(CyberColors.BOLD + "Press Enter to return to deck..." + CyberColors.RESET)

def run_packages():
    print(CyberColors.NEON_PINK + "\\n[*] LOADED NEURAL LIBS:" + CyberColors.RESET)
${config.selectedPackages.length ? config.selectedPackages.map(p => `    print(f"  ├── [LOADED] ${p} (v.latest)")`).join('\n') : '    print("  └── [STANDALONE] Standard Python Core")'}
    print(f"\\n{CyberColors.NEON_CYAN}[+] All packages verified.{CyberColors.RESET}\\n")
    input(CyberColors.BOLD + "Press Enter to return to deck..." + CyberColors.RESET)

def main():
    clear_screen()
    progress_bar("BOOTING KALBASO STUDIO DECK", total=15)
    while True:
        try:
            print_cyber_header()
            show_cyber_menu()
            choice = input(f"{CyberColors.NEON_PINK}kalbaso@{config.toolSlug}~$ {CyberColors.RESET}").strip()

            if choice == "1":
                run_cyber_scan()
            elif choice == "2":
                run_pulse()
            elif choice == "3":
                run_packages()
            elif choice in ["0", "exit", "q"]:
                cyber_print("\\n[!] Deck link terminated. Standby...", 0.02, CyberColors.NEON_YELLOW)
                sys.exit(0)
            else:
                print(CyberColors.NEON_RED + "[!] Invalid signal, re-enter command." + CyberColors.RESET)
                time.sleep(0.8)
        except KeyboardInterrupt:
            print(CyberColors.NEON_RED + "\\n\\n[!] Emergency abort signal received. Bye!\\n" + CyberColors.RESET)
            sys.exit(0)

if __name__ == "__main__":
    main()
`;
}

/**
 * 3. Dashboard Template (Tables, Panels, Data Organization with Rich Fallback)
 */
function generateDashboardTemplate(config: ToolConfig): string {
  const banner = getSelectedBanner(config);

  return `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
====================================================================
 ${config.toolName} - DASHBOARD & METRICS IDE
 Developer: ${config.author} | Version: ${config.version}
 Built with KALBASO Termux Studio
 Description: ${config.description}
====================================================================
"""

import sys
import os
import time
import shutil
import platform
from datetime import datetime

# Check if Rich is installed, else use high-fidelity ASCII tables
try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.text import Text
    HAS_RICH = True
    console = Console()
except ImportError:
    HAS_RICH = False

BANNER = """${banner}"""

def get_storage_stats():
    try:
        total, used, free = shutil.disk_usage(os.path.expanduser("~"))
        return f"{total / (1024**3):.1f} GB", f"{used / (1024**3):.1f} GB", f"{free / (1024**3):.1f} GB", f"{(used / total) * 100:.0f}%"
    except Exception:
        return "64.0 GB", "28.4 GB", "35.6 GB", "44%"

def clear_screen():
    os.system("clear" if os.name != "nt" else "cls")

def render_rich_dashboard():
    clear_screen()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tot_gb, usd_gb, fre_gb, pct = get_storage_stats()
    
    # Top Panel
    title_text = Text()
    title_text.append(BANNER + "\\n", style="bold cyan")
    title_text.append(f"${config.toolName}  ", style="bold green")
    title_text.append(f"v${config.version}  ", style="yellow")
    title_text.append(f"| Author: ${config.author}  ", style="magenta")
    title_text.append(f"| Time: {now_str}", style="dim white")
    
    console.print(Panel(title_text, border_style="cyan", title="[bold white]KALBASO TERMUX DASHBOARD[/]"))

    # Metrics Table
    table = Table(title="Live System Telemetry & Storage Gauges", border_style="blue", show_header=True, header_style="bold magenta")
    table.add_column("Telemetry Parameter", style="cyan", no_wrap=True)
    table.add_column("Value / Metric", style="green")
    table.add_column("Gauge Status", style="bold yellow")

    table.add_row("Used Disk Space (المستخدمة)", f"{usd_gb} ({pct})", "[ACTIVE]")
    table.add_row("Free Disk Space (المتاحة)", fre_gb, "[HEALTHY]")
    table.add_row("Total Storage (الكلية)", tot_gb, "[ONLINE]")
    table.add_row("Platform & Architecture", f"{platform.system()} {platform.machine()}", "[PASS]")
    table.add_row("Python Interpreter", platform.python_version(), "[ONLINE]")
    table.add_row("Active Modules", "${config.selectedPackages.length ? config.selectedPackages.join(', ') : 'Zero-Dependency'}", "[READY]")
    console.print(table)

    # Actions Table
    actions = Table(title="Available Operations", border_style="green", show_header=True)
    actions.add_column("ID", style="bold white", width=5)
    actions.add_column("Operation (English)", style="cyan")
    actions.add_column("العملية (عربي)", style="yellow")

    actions.add_row("1", "${config.menuItems[0]?.labelEn || 'Execute Data Pipeline'}", "${config.menuItems[0]?.labelAr || 'تشغيل معالجة البيانات'}")
    actions.add_row("2", "${config.menuItems[1]?.labelEn || 'Generate Health Report'}", "${config.menuItems[1]?.labelAr || 'توليد تقرير الحالة'}")
    actions.add_row("3", "${config.menuItems[2]?.labelEn || 'Export Logs & Metrics'}", "${config.menuItems[2]?.labelAr || 'تصدير السجلات والبيانات'}")
    actions.add_row("0", "Exit Dashboard", "خروج من اللوحة")
    console.print(actions)

def render_ascii_dashboard():
    clear_screen()
    now_str = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    tot_gb, usd_gb, fre_gb, pct = get_storage_stats()
    print("\\033[36m" + BANNER + "\\033[0m")
    print("+====================================================================+")
    print(f"|  \\033[1;32m${config.toolName}\\033[0m v${config.version} | Author: \\033[33m${config.author}\\033[0m | {now_str}  |")
    print("+====================================================================+")
    print("| PARAMETER             | VALUE                    | STATUS         |")
    print("|-----------------------+--------------------------+----------------|")
    print(f"| Used Space (المستخدمة) | {usd_gb:<14} ({pct:<4})   | [ACTIVE]       |")
    print(f"| Free Space (المتاحة)   | {fre_gb:<24} | [HEALTHY]      |")
    print(f"| Total Storage (الكلية) | {tot_gb:<24} | [ONLINE]       |")
    print(f"| OS & Architecture     | {platform.system():<24} | [ONLINE]       |")
    print(f"| Python Interpreter    | {platform.python_version():<24} | [PASS]         |")
    print("+====================================================================+")
    print("\\n[+] OPERATIONS:")
    print("  [1] ${config.menuItems[0]?.labelEn || 'Execute Data Pipeline'} (${config.menuItems[0]?.labelAr || 'تشغيل معالجة البيانات'})")
    print("  [2] ${config.menuItems[1]?.labelEn || 'Generate Health Report'} (${config.menuItems[1]?.labelAr || 'توليد تقرير الحالة'})")
    print("  [3] ${config.menuItems[2]?.labelEn || 'Export Logs & Metrics'} (${config.menuItems[2]?.labelAr || 'تصدير السجلات والبيانات'})")
    print("  [0] Exit Dashboard (خروج)")
    print("-" * 70)

def main():
    while True:
        try:
            if HAS_RICH:
                render_rich_dashboard()
            else:
                render_ascii_dashboard()

            choice = input("\\n[?] Select operation [0-3]: ").strip()

            if choice == "1":
                print("\\n[*] Processing pipeline data...")
                for p in range(0, 101, 25):
                    print(f"  -> Progress: {p}% completed")
                    time.sleep(0.3)
                print("[SUCCESS] Pipeline completed successfully.\\n")
                input("Press Enter to continue...")
            elif choice == "2":
                print("\\n[*] Generating system report at ./report.log...")
                time.sleep(0.8)
                print("[SUCCESS] Report generated. All metrics nominal.\\n")
                input("Press Enter to continue...")
            elif choice == "3":
                print("\\n[*] Exporting telemetry to termux storage...")
                time.sleep(0.6)
                print("[SUCCESS] Logs saved.\\n")
                input("Press Enter to continue...")
            elif choice in ["0", "exit", "quit", "q"]:
                print("\\nDashboard closed. Have a great day!\\n")
                sys.exit(0)
            else:
                print("\\n[!] Unknown option, please retry.")
                time.sleep(0.8)
        except KeyboardInterrupt:
            print("\\n\\n[!] Exited by user.\\n")
            sys.exit(0)

if __name__ == "__main__":
    main()
`;
}

/**
 * Generate requirements.txt
 */
export function generateRequirementsTxt(packages: string[]): string {
  if (packages.length === 0) {
    return `# Requirements for Termux Tool
# No external packages required (Pure Python 3 Standard Library)
`;
  }
  return `# Requirements for Termux Tool
# Generated by KALBASO Termux Studio
${packages.map(p => `${p}>=1.0.0`).join('\n')}
`;
}

/**
 * Generate install.sh bash installer for Termux
 */
export function generateInstallScript(config: ToolConfig): string {
  const pkgs = config.selectedPackages.join(' ');
  return `#!/data/data/com.termux/files/usr/bin/bash
# ===================================================================
# ${config.toolName} Installer for Termux
# Generated automatically by KALBASO Termux Studio
# ===================================================================

set -e

echo -e "\\e[1;36m"
echo "============================================="
echo "   Installing ${config.toolName} on Termux   "
echo "============================================="
echo -e "\\e[0m"

echo "[1/4] Updating Termux repositories..."
pkg update -y && pkg upgrade -y

echo "[2/4] Installing Python 3 & Dependencies..."
pkg install -y python python-pip git

${config.selectedPackages.length > 0 ? `echo "[3/4] Installing required Python packages (${pkgs})..."
pip install --upgrade pip
pip install -r requirements.txt
` : `echo "[3/4] No external Python packages needed."`}

echo "[4/4] Setting execution permissions..."
chmod +x ${config.toolSlug}.py

echo -e "\\e[1;32m"
echo "============================================="
echo " [SUCCESS] Installation Completed! "
echo " To run your tool now, type: "
echo "   python ${config.toolSlug}.py"
echo "============================================="
echo -e "\\e[0m"
`;
}
