import React, { useState } from 'react';
import {
  Code2,
  FileCode2,
  Copy,
  Check,
  Download,
  FolderArchive,
  Terminal,
  ExternalLink,
  ChevronRight,
  Sparkles,
  BookOpen,
  Layers,
  Cpu
} from 'lucide-react';
import { TERMUX_PROJECT_FILES, TermuxFile } from '../data/termuxFiles';
import { generateTermuxProjectZip, downloadBlobAsFile } from '../utils/zipPackager';
import confetti from 'canvas-confetti';

export const TermuxCodeStudio: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<TermuxFile>(TERMUX_PROJECT_FILES[0]);
  const [copiedFile, setCopiedFile] = useState<boolean>(false);
  const [copiedCommand, setCopiedCommand] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);

  const handleCopyCode = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopiedFile(true);
    setTimeout(() => setCopiedFile(false), 2000);
  };

  const handleCopyCommand = (cmd: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 2000);
  };

  const handleDownloadSingleFile = () => {
    const blob = new Blob([selectedFile.content], { type: 'text/plain;charset=utf-8' });
    downloadBlobAsFile(blob, selectedFile.name);
  };

  const handleDownloadZipPackage = async () => {
    setIsZipping(true);
    try {
      const zipBlob = await generateTermuxProjectZip();
      downloadBlobAsFile(zipBlob, 'termux-live-audio-translator.zip');
      try {
        confetti({
          particleCount: 50,
          spread: 60,
          origin: { y: 0.7 }
        });
      } catch (e) {}
    } catch (err) {
      console.error('Error generating zip:', err);
    } finally {
      setIsZipping(false);
    }
  };

  const oneClickTermuxCommand = `curl -sL https://raw.githubusercontent.com/termux-audio-trans/installer/main/install.sh | bash`;

  return (
    <div className="space-y-8">
      
      {/* Top Banner & Quick Download ZIP */}
      <div className="bg-gradient-to-r from-slate-900 via-slate-900 to-emerald-950/40 border border-emerald-500/30 rounded-3xl p-6 sm:p-8 shadow-2xl relative overflow-hidden">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40 mb-3">
              <Sparkles className="w-3.5 h-3.5" />
              <span>كود بايثون مفتوح المصدر 100% مقسم لملفات modular</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              حزمة Termux للترجمة الصوتية الحية
            </h2>
            <p className="text-sm text-slate-400 mt-1.5 max-w-2xl leading-relaxed">
              مشروع بايثون كامل ومثالي، مخصص للعمل على أجهزة أندرويد عبر تطبيق Termux،
              يسجل من 5 إلى 10 ثوانٍ من أي بث راديو عبر ffmpeg، يحوله لنص ويعرض ترجمته العربية سطر بسطر.
            </p>
          </div>

          {/* Master Download ZIP Button */}
          <button
            onClick={handleDownloadZipPackage}
            disabled={isZipping}
            className="flex items-center gap-3 px-6 py-4 rounded-2xl text-sm sm:text-base font-black bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 transition-all shadow-xl shadow-emerald-500/25 active:scale-95 shrink-0"
          >
            <FolderArchive className="w-5 h-5 text-slate-950" />
            <span>{isZipping ? 'جارٍ تحزيم الملفات...' : 'تحميل المشروع كاملاً (ZIP)'}</span>
          </button>
        </div>
      </div>

      {/* One-Click Termux Setup Command Box */}
      <div className="bg-slate-950 border border-cyan-500/30 rounded-2xl p-5 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-xs font-bold text-cyan-400">
            <Terminal className="w-4 h-4" />
            <span>أمر التثبيت السريع بنقرة واحدة داخل Termux (One-Command Installer):</span>
          </div>
          <span className="text-[11px] text-slate-500">انسخ والصق في طرفية تيرموكس</span>
        </div>

        <div className="flex items-center justify-between gap-3 bg-slate-900 border border-slate-800 rounded-xl px-4 py-3 font-mono text-xs sm:text-sm text-emerald-400 overflow-x-auto">
          <span className="select-all" dir="ltr">{oneClickTermuxCommand}</span>
          <button
            onClick={() => handleCopyCommand(oneClickTermuxCommand)}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 font-sans text-xs font-bold border border-emerald-500/40 shrink-0 transition-all active:scale-95"
          >
            {copiedCommand ? (
              <>
                <Check className="w-3.5 h-3.5" />
                <span>تم النسخ!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5" />
                <span>نسخ الأمر</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Modular Code Explorer */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        
        {/* Left Side: Files Navigation Sidebar */}
        <div className="lg:col-span-4 space-y-2 bg-slate-900/80 border border-slate-800 rounded-2xl p-3 shadow-xl">
          <div className="px-3 py-2 text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              <span>ملفات المشروع (Modular Structure)</span>
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-800 text-slate-300">
              {TERMUX_PROJECT_FILES.length} ملفات
            </span>
          </div>

          <div className="space-y-1">
            {TERMUX_PROJECT_FILES.map((file) => {
              const isSelected = selectedFile.name === file.name;
              return (
                <button
                  key={file.name}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-right p-3 rounded-xl border transition-all flex flex-col gap-1 ${
                    isSelected
                      ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300 shadow-md shadow-emerald-950/20'
                      : 'bg-slate-950/50 border-slate-800/80 text-slate-400 hover:text-slate-200 hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-xs sm:text-sm font-bold text-slate-200 flex items-center gap-2" dir="ltr">
                      <FileCode2 className={`w-4 h-4 ${isSelected ? 'text-emerald-400' : 'text-slate-500'}`} />
                      {file.name}
                    </span>
                    <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-slate-900 border border-slate-800 text-slate-400">
                      {file.language}
                    </span>
                  </div>
                  <span className="text-[11px] text-slate-500 line-clamp-1">{file.description}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Side: Code Viewer & Actions */}
        <div className="lg:col-span-8 bg-slate-950 border border-slate-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col">
          
          {/* Code Viewer Header */}
          <div className="flex items-center justify-between px-5 py-3.5 bg-slate-900/90 border-b border-slate-800">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-sm text-slate-200" dir="ltr">{selectedFile.name}</span>
                <span className="text-xs text-slate-500">•</span>
                <span className="text-xs text-emerald-400 font-medium">{selectedFile.description}</span>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyCode}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all border border-slate-700 active:scale-95"
              >
                {copiedFile ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span>تم النسخ</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span>نسخ الكود</span>
                  </>
                )}
              </button>

              <button
                onClick={handleDownloadSingleFile}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold transition-all border border-slate-700 active:scale-95"
                title="تحميل هذا الملف منفرداً"
              >
                <Download className="w-3.5 h-3.5 text-cyan-400" />
                <span>تحميل</span>
              </button>
            </div>
          </div>

          {/* Code Body with Line Numbers */}
          <div className="p-4 overflow-x-auto max-h-[500px] scrollbar-thin scrollbar-thumb-slate-800">
            <pre className="text-xs font-mono text-slate-300 leading-relaxed select-text" dir="ltr">
              <code>{selectedFile.content}</code>
            </pre>
          </div>
        </div>
      </div>

      {/* Step-by-Step Manual Termux Guide */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <h3 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
          <BookOpen className="w-5 h-5 text-emerald-400" />
          <span>دليل التشغيل اليدوي خطوة بخطوة في Termux على هاتفك:</span>
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-emerald-400 font-bold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-emerald-500/20 flex items-center justify-center text-xs">1</span>
              <span>تثبيت المتطلبات و ffmpeg</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              افتح تيرموكس وثبت بايثون وأداة تسجيل ومعالجة الصوت ffmpeg:
            </p>
            <div className="bg-slate-900 p-2.5 rounded-xl font-mono text-xs text-cyan-300 select-all" dir="ltr">
              pkg install python ffmpeg -y
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-teal-400 font-bold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-teal-500/20 flex items-center justify-center text-xs">2</span>
              <span>تثبيت مكتبات الترجمة و Rich</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              تثبيت مكتبات SpeechRecognition و googletrans و rich:
            </p>
            <div className="bg-slate-900 p-2.5 rounded-xl font-mono text-xs text-cyan-300 select-all" dir="ltr">
              pip install rich speechrecognition googletrans==4.0.0-rc1 pydub
            </div>
          </div>

          <div className="bg-slate-950 p-4 rounded-2xl border border-slate-800/80">
            <div className="flex items-center gap-2 text-cyan-400 font-bold text-sm mb-2">
              <span className="w-6 h-6 rounded-full bg-cyan-500/20 flex items-center justify-center text-xs">3</span>
              <span>بدء الترجمة الحية سطر بسطر</span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed mb-3">
              شغل الأداة مباشرة مع رابط راديو BBC أو أي إذاعة أخرى:
            </p>
            <div className="bg-slate-900 p-2.5 rounded-xl font-mono text-xs text-cyan-300 select-all" dir="ltr">
              python main.py --chunk 8
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
