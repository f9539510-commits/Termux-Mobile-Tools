#!/usr/bin/env python3
import os
import zipfile
import shutil

print("[*] Packaging clean GitHub source code into 'azzo-wifi-radar-source.zip'...")

OUTPUT_ZIP = "azzo-wifi-radar-source.zip"
EXCLUDE_DIRS = {
    "node_modules",
    "dist",
    "out",
    ".git",
    "tmp",
    ".cache",
    ".idea",
    ".vscode",
    "coverage",
    ".aistudio"
}

EXCLUDE_EXTS = {
    ".apk",
    ".idsig",
    ".zip",
    ".tgz",
    ".log",
    ".tsbuildinfo"
}

EXCLUDE_FILES = {
    ".env",
    ".env.local",
    ".env.development.local",
    ".env.test.local",
    ".env.production.local",
    OUTPUT_ZIP
}

# Remove existing zip if present
if os.path.exists(OUTPUT_ZIP):
    os.remove(OUTPUT_ZIP)

count = 0
with zipfile.ZipFile(OUTPUT_ZIP, "w", zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk("."):
        # Modify dirs in-place to skip excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith(".")]
        
        rel_root = os.path.relpath(root, ".")
        if rel_root.startswith("."):
            continue
            
        for file in files:
            if file in EXCLUDE_FILES or file.startswith(".env"):
                continue
            _, ext = os.path.splitext(file)
            if ext.lower() in EXCLUDE_EXTS:
                continue
                
            full_path = os.path.join(root, file)
            # Store in archive relative to root (prefixed with clean project name)
            arcname = os.path.join("azzo-wifi-radar", os.path.relpath(full_path, "."))
            zipf.write(full_path, arcname=arcname)
            count += 1

print(f"[+] Successfully packaged {count} clean source files into '{OUTPUT_ZIP}'. Size: {os.path.getsize(OUTPUT_ZIP)} bytes.")

# Copy to public/ for static serving as well
os.makedirs("public", exist_ok=True)
shutil.copyfile(OUTPUT_ZIP, os.path.join("public", OUTPUT_ZIP))
print(f"[+] Copied to public/{OUTPUT_ZIP} for direct HTTP serving.")
