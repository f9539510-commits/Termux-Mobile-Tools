import JSZip from 'jszip';
import { ToolConfig } from '../types/termuxStudio';
import { generatePythonCode, generateRequirementsTxt, generateInstallScript } from '../data/codeTemplates';
import { NATIVE_ANDROID_FILES } from '../data/nativeAndroidSource';

/**
 * Downloads a generated Blob to the user's filesystem
 */
export function downloadBlobAsFile(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}

/**
 * Packages the generated Python tool project for Termux into a ready-to-run ZIP archive
 */
export async function generateToolZipPackage(config: ToolConfig): Promise<Blob> {
  const zip = new JSZip();
  const folder = zip.folder(config.toolSlug || 'kalbaso-tool');

  // Main Python script
  const pyCode = generatePythonCode(config);
  folder?.file(`${config.toolSlug}.py`, pyCode);

  // Requirements.txt
  const reqs = generateRequirementsTxt(config.selectedPackages);
  folder?.file('requirements.txt', reqs);

  // Install script
  const installSh = generateInstallScript(config);
  folder?.file('install.sh', installSh);

  // Readme
  const readme = `# ${config.toolName} v${config.version}
Developer: ${config.author}
Generated automatically with KALBASO Termux Studio

## 🚀 تشغيل الأداة في Termux:
1. انقل المجلد إلى Termux أو فك الضغط في المجلد الرئيسي:
   \`\`\`bash
   cd ${config.toolSlug}
   chmod +x install.sh
   ./install.sh
   \`\`\`
2. تشغيل الأداة:
   \`\`\`bash
   python ${config.toolSlug}.py
   \`\`\`
`;
  folder?.file('README.md', readme);

  return await zip.generateAsync({ type: 'blob' });
}

/**
 * Packages the complete Native Android Kotlin Project source code into a ZIP archive for GitHub
 */
export async function generateNativeAndroidProjectZip(): Promise<Blob> {
  const zip = new JSZip();
  const root = zip.folder('kalbaso-termux-studio-android-source');

  // Add all native Android files including GitHub Actions workflow and Gradle wrapper
  NATIVE_ANDROID_FILES.forEach(file => {
    root?.file(file.path, file.content);
  });

  // Add strings.xml
  root?.file('app/src/main/res/values/strings.xml', `<resources>
    <string name="app_name">KALBASO Termux Studio</string>
    <string name="developer_name">كالبسو مطروح (Calypsu) 🇪🇬</string>
    <string name="check_termux">فحص اتصال تيرمكس</string>
    <string name="install_pkg">تثبيت الحزمة عبر تيرمكس</string>
    <string name="push_tool">إرسال وتشغيل الأداة في تيرمكس</string>
</resources>
`);

  // Add colors.xml
  root?.file('app/src/main/res/values/colors.xml', `<resources>
    <color name="black">#FF030712</color>
    <color name="neon_cyan">#FF00F0FF</color>
    <color name="neon_green">#FF10B981</color>
    <color name="neon_pink">#FFFF007F</color>
    <color name="neon_red">#FFEF4444</color>
    <color name="card_bg">#FF0F172A</color>
</resources>
`);

  // Add styles.xml / themes.xml
  root?.file('app/src/main/res/values/themes.xml', `<resources>
    <style name="Theme.KalbasoTermuxStudio" parent="Theme.MaterialComponents.DayNight.NoActionBar">
        <item name="colorPrimary">@color/neon_green</item>
        <item name="colorPrimaryVariant">@color/neon_cyan</item>
        <item name="colorOnPrimary">@color/black</item>
        <item name="android:statusBarColor">@color/black</item>
        <item name="android:navigationBarColor">@color/black</item>
    </style>
</resources>
`);

  return await zip.generateAsync({ type: 'blob' });
}

/**
 * Packages the standalone Ezzo Security Research Android Project (com.example.ezu)
 */
export async function generateEzzoProjectZip(): Promise<Blob> {
  const zip = new JSZip();
  const root = zip.folder('ezzo-wifi-security-research-android');

  // AndroidManifest.xml
  root?.file('app/src/main/AndroidManifest.xml', `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.ezu">

    <uses-permission android:name="android.permission.ACCESS_WIFI_STATE" />
    <uses-permission android:name="android.permission.CHANGE_WIFI_STATE" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" />
    <uses-permission android:name="android.permission.MANAGE_EXTERNAL_STORAGE" />

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="Ezzo Research"
        android:theme="@style/Theme.AppCompat.DayNight.DarkActionBar"
        android:requestLegacyExternalStorage="true">
        <activity
            android:name=".MainActivity"
            android:exported="true">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`);

  // MainActivity.kt (Exact user code)
  root?.file('app/src/main/java/com/example/ezu/MainActivity.kt', `package com.example.ezu

import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    
    private lateinit var logView: TextView
    private val TAG = "EZZO_RESEARCH"
    private val logBuilder = StringBuilder()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        
        logView = findViewById(R.id.resultText)
        val btn = findViewById<Button>(R.id.scanButton)
        btn.text = "بدء اختبار الثغرة"
        
        btn.setOnClickListener {
            runSecurityTests()
        }
    }

    private fun runSecurityTests() {
        logBuilder.clear()
        addLog("=== بدء بحث عزو - \${getTime()} ===")
        addLog("الهدف: اختبار حدود WifiManager بدون روت")

        // اختبار 1: هل rapid scan بيسرب بيانات زيادة؟
        addLog("\\n[TEST 1] Rapid Scan Test")
        try {
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            for (i in 1..20) {
                wm.startScan()
                val res = wm.scanResults
                addLog("محاولة $i: لقيت \${res.size} شبكة")
                if (res.any { it.capabilities.contains("WPA") }) {
                    // ده طبيعي ومش ثغرة، بس بنسجله
                    addLog("-> الشبكات فيها WPA/WPA2 (طبيعي)")
                }
                Thread.sleep(100)
            }
        } catch (e: Exception) {
            addLog("TEST 1 ERROR (ممكن تكون ثغرة): \${e.message}")
            Log.e(TAG, "test1 failed", e)
        }

        // اختبار 2: هل نقدر نوصل لملف مش بتاعنا؟
        addLog("\\n[TEST 2] File Access Boundary Test")
        try {
            val testFile = File(Environment.getExternalStorageDirectory(), "Download/wifi_list.txt")
            testFile.writeText("test by ezzo")
            addLog("قدرنا نكتب في Download (مسموح)")
            
            val protectedFile = File("/data/misc/wifi/wpa_supplicant.conf")
            addLog("هل نقدر نقرا ملف النظام؟ \${protectedFile.exists()} - \${protectedFile.canRead()}")
            if (protectedFile.canRead()) {
                addLog("!!! ثغرة خطيرة لقيناها - قابلية قراءة ملف النظام بدون روت !!!")
            } else {
                addLog("النظام محمي (ده الطبيعي) - مفيش ثغرة هنا")
            }
        } catch (e: Exception) {
            addLog("TEST 2 محمي: \${e.message}")
        }

        // حفظ التقرير
        saveReport()
        addLog("\\n=== انتهى - التقرير اتحفظ في Download/ezzo_report.txt ===")
        addLog("ابعته لجوجل لو لقيت كلمة ثغرة خطيرة")
    }

    private fun addLog(s: String) {
        logBuilder.append(s).append("\\n")
        logView.text = logBuilder.toString()
        Log.d(TAG, s)
    }

    private fun saveReport() {
        try {
            val file = File(Environment.getExternalStorageDirectory(), "Download/ezzo_report.txt")
            file.writeText(logBuilder.toString())
        } catch (e: Exception) {}
    }

    private fun getTime(): String {
        return SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
    }
}`);

  // layout/activity_main.xml
  root?.file('app/src/main/res/layout/activity_main.xml', `<?xml version="1.0" encoding="utf-8"?>
<LinearLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:orientation="vertical"
    android:background="#0F172A"
    android:padding="16dp">

    <TextView
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="مختبر بحث عزو الأمني (EZZO RESEARCH)"
        android:textColor="#38BDF8"
        android:textSize="18sp"
        android:textStyle="bold"
        android:gravity="center"
        android:paddingBottom="12dp" />

    <Button
        android:id="@+id/scanButton"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:text="بدء اختبار الثغرة"
        android:backgroundTint="#0284C7"
        android:textColor="#FFFFFF"
        android:textStyle="bold"
        android:padding="14dp" />

    <ScrollView
        android:layout_width="match_parent"
        android:layout_height="0dp"
        android:layout_weight="1"
        android:layout_marginTop="16dp"
        android:background="#030712"
        android:padding="12dp">

        <TextView
            android:id="@+id/resultText"
            android:layout_width="match_parent"
            android:layout_height="wrap_content"
            android:fontFamily="monospace"
            android:text="اضغط الزر أعلاه لبدء الاختبار الأمني..."
            android:textColor="#10B981"
            android:textSize="13sp" />
    </ScrollView>
</LinearLayout>`);

  // build.gradle.kts (App level)
  root?.file('app/build.gradle.kts', `plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.ezu"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.ezu"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
}`);

  // settings.gradle.kts
  root?.file('settings.gradle.kts', `pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "EzzoResearch"
include(":app")`);

  // GitHub Actions Workflow to build APK
  root?.file('.github/workflows/build-apk.yml', `name: Build Ezzo Security Research APK

on:
  push:
    branches: [ main, master ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Setup Gradle
        uses: gradle/actions/setup-gradle@v3

      - name: Build APK
        run: ./gradlew assembleDebug

      - name: Upload APK Artifact
        uses: actions/upload-artifact@v4
        with:
          name: Ezzo-Security-Research-Debug-APK
          path: app/build/outputs/apk/debug/*.apk`);

  // README
  root?.file('README.md', `# بحث عزو - اختبار حدود WifiManager وملفات النظام (EZZO RESEARCH)
Package: \`com.example.ezu\`
Developer: Ezzo (عزو)

## 📌 الهدف من المشروع:
1. اختبار تروتلينغ وحماية \`WifiManager\` في أندرويد بدون روت.
2. فحص إمكانية الوصول إلى ملفات النظام المحمية \`/data/misc/wifi/wpa_supplicant.conf\`.
3. توليد وحفظ تقرير أمني تلقائي في \`/sdcard/Download/ezzo_report.txt\`.

## 🚀 كيفية البناء:
- قم بفتح المجلد مباشرة داخل Android Studio.
- أو ارفع الكود إلى مستودع GitHub وسيتم بناء ملف الـ APK تلقائياً عبر GitHub Actions.`);

  return await zip.generateAsync({ type: 'blob' });
}

