import React, { useState, useEffect } from 'react';
import { 
  PyPiPackageInfo, 
  SearchHistoryItem, 
  performSmartPackageSearch, 
  getSearchHistory, 
  saveSearchQuery, 
  clearSearchHistory,
  fetchPyPiPackage,
  CORE_OFFLINE_PACKAGES
} from '../utils/pypiSearchEngine';
import { installPackageInTermux } from '../utils/termuxBridge';
import { ToolConfig } from '../types/termuxStudio';
import { 
  Search, 
  Sparkles, 
  Terminal, 
  Download, 
  ExternalLink, 
  Clock, 
  Trash2, 
  Check, 
  Copy, 
  Plus, 
  Loader2, 
  Globe, 
  Tag,
  AlertCircle,
  PackageCheck
} from 'lucide-react';

interface SmartPyPiSearchProps {
  config: ToolConfig;
  onChangeConfig: (newConfig: ToolConfig) => void;
}

export const SmartPyPiSearch: React.FC<SmartPyPiSearchProps> = ({
  config,
  onChangeConfig
}) => {
  const [query, setQuery] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [progressMsg, setProgressMsg] = useState('');
  const [results, setResults] = useState<PyPiPackageInfo[]>(CORE_OFFLINE_PACKAGES);
  const [history, setHistory] = useState<SearchHistoryItem[]>([]);
  const [statusNotification, setStatusNotification] = useState<string | null>(null);
  const [copiedPkg, setCopiedPkg] = useState<string | null>(null);

  useEffect(() => {
    setHistory(getSearchHistory());
  }, []);

  const handleExecuteSearch = async (searchTerm: string, saveToHistory: boolean = true) => {
    const q = searchTerm.trim();
    if (!q) {
      setResults(CORE_OFFLINE_PACKAGES);
      return;
    }

    setIsLoading(true);
    setProgressMsg(`جارٍ البحث في مستودع PyPI عن "${q}"...`);

    try {
      const res = await performSmartPackageSearch(q, (msg) => setProgressMsg(msg));
      setResults(res);

      if (saveToHistory) {
        const updatedHistory = saveSearchQuery(q, res.length);
        setHistory(updatedHistory);
      }
    } catch (err) {
      console.error('Search error:', err);
    } finally {
      setIsLoading(false);
      setProgressMsg('');
    }
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleExecuteSearch(query, true);
  };

  const handleHistoryClick = (histQuery: string) => {
    setQuery(histQuery);
    handleExecuteSearch(histQuery, true);
  };

  const handleClearAllHistory = () => {
    clearSearchHistory();
    setHistory([]);
    showToast('تم مسح سجل البحث');
  };

  const showToast = (msg: string) => {
    setStatusNotification(msg);
    setTimeout(() => setStatusNotification(null), 3500);
  };

  /**
   * Installs the package directly in Termux using real Android Intent or Native Bridge
   */
  const handleInstallInTermux = async (pkgName: string) => {
    setCopiedPkg(pkgName);
    const res = await installPackageInTermux(pkgName);
    showToast(res.message);
    setTimeout(() => setCopiedPkg(null), 2500);

    // Also add to project if not already added
    if (!config.selectedPackages.includes(pkgName)) {
      onChangeConfig({
        ...config,
        selectedPackages: [...config.selectedPackages, pkgName]
      });
    }
  };

  const handleToggleAddToProject = (pkgName: string) => {
    const isAdded = config.selectedPackages.includes(pkgName);
    const updated = isAdded
      ? config.selectedPackages.filter(p => p !== pkgName)
      : [...config.selectedPackages, pkgName];
    onChangeConfig({ ...config, selectedPackages: updated });
    showToast(isAdded ? `أُزيلت ${pkgName} من requirements.txt` : `أُضيفت ${pkgName} إلى requirements.txt`);
  };

  const quickArabicSuggestions = [
    { label: 'طلبات (requests)', query: 'طلبات' },
    { label: 'تلوين (colorama)', query: 'تلوين' },
    { label: 'جداول (rich)', query: 'جداول' },
    { label: 'كشط ويب (bs4)', query: 'كشط' },
    { label: 'خادم (flask)', query: 'خادم' },
    { label: 'بيانات (pandas)', query: 'بيانات' },
    { label: 'تشفير (crypto)', query: 'تشفير' },
    { label: 'موارد (psutil)', query: 'موارد' }
  ];

  return (
    <div className="space-y-6">
      
      {/* Search Header Box */}
      <div className="rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-slate-950 border border-cyan-500/40 p-5 sm:p-7 space-y-4 shadow-xl">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center">
              <Search className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-100 flex items-center gap-2">
                <span>البحث الذكي عن المكتبات (PyPI Smart Search)</span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30">
                  عربي + English
                </span>
              </h2>
              <p className="text-xs text-slate-400">
                ابحث بالكلمات العربية (مثل: "طلبات"، "تلوين"، "جداول") أو باسم المكتبة مباشرة لجلب بياناتها الحية من PyPI JSON API
              </p>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 text-xs font-mono text-cyan-400">
            <Globe className="w-3.5 h-3.5" />
            <span>pypi.org/pypi/{'{pkg}'}/json</span>
          </div>
        </div>

        {/* Search Input Form */}
        <form onSubmit={handleFormSubmit} className="relative flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-cyan-400" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="اكتب ما تحتاجه بالعربي (مثال: طلبات، تلوين، كشط) أو بالإنجليزي (requests, flask)..."
              className="w-full pr-10 pl-4 py-3 rounded-xl bg-slate-950 border border-slate-700/80 text-sm text-slate-100 placeholder:text-slate-500 focus:outline-none focus:border-cyan-400 shadow-inner"
            />
          </div>

          <button
            type="submit"
            disabled={isLoading || !query.trim()}
            className="flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-cyan-500 to-teal-500 hover:from-cyan-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-cyan-500/25 active:scale-95 transition-all disabled:opacity-50 whitespace-nowrap"
          >
            {isLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
            <span>بحث ذكي</span>
          </button>
        </form>

        {/* Quick Suggestion Chips */}
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none pt-1">
          <span className="text-[11px] text-slate-400 whitespace-nowrap font-semibold">مقترحات شائعة:</span>
          {quickArabicSuggestions.map((sug) => (
            <button
              key={sug.query}
              type="button"
              onClick={() => {
                setQuery(sug.query);
                handleExecuteSearch(sug.query, true);
              }}
              className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300 hover:text-cyan-300 hover:border-cyan-500/40 text-xs font-mono whitespace-nowrap transition-all"
            >
              {sug.label}
            </button>
          ))}
        </div>

        {/* Toast / Status Notification */}
        {statusNotification && (
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-in fade-in">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{statusNotification}</span>
          </div>
        )}
      </div>

      {/* Search History Row */}
      {history.length > 0 && (
        <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 flex items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 overflow-x-auto scrollbar-none flex-1">
            <span className="text-slate-500 font-semibold flex items-center gap-1 shrink-0">
              <Clock className="w-3.5 h-3.5" />
              <span>سجل البحث:</span>
            </span>
            {history.map((item) => (
              <button
                key={item.id}
                onClick={() => handleHistoryClick(item.query)}
                className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 hover:border-cyan-500/40 text-slate-300 hover:text-cyan-300 font-mono text-xs whitespace-nowrap transition-colors"
              >
                {item.query}
              </button>
            ))}
          </div>

          <button
            onClick={handleClearAllHistory}
            className="text-slate-500 hover:text-red-400 p-1 rounded transition-colors shrink-0"
            title="مسح سجل البحث"
          >
            <Trash2 className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Loading State */}
      {isLoading && (
        <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 text-center space-y-3">
          <Loader2 className="w-7 h-7 text-cyan-400 animate-spin mx-auto" />
          <p className="text-xs text-slate-300 font-mono">{progressMsg || 'جارٍ البحث في PyPI...'}</p>
        </div>
      )}

      {/* Results List */}
      {!isLoading && results.length > 0 && (
        <div className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <span className="text-xs font-bold text-slate-300">
              نتائج البحث الحية من مستودع PyPI ({results.length} مكتبات):
            </span>
            <span className="text-[11px] text-slate-500">
              جميع المكتبات جاهزة للتثبيت الفوري في Termux
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {results.map((pkg) => {
              const isAddedToProject = config.selectedPackages.includes(pkg.name);
              return (
                <div
                  key={pkg.name}
                  className={`rounded-2xl border p-5 transition-all flex flex-col justify-between ${
                    isAddedToProject
                      ? 'bg-slate-900/90 border-cyan-500/50 ring-1 ring-cyan-500/30'
                      : 'bg-slate-950/80 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/40'
                  }`}
                >
                  <div className="space-y-3">
                    
                    {/* Header: Title, Version, PyPI Badge */}
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <div className="flex items-center gap-2">
                          <h3 className="text-base font-bold text-slate-100 font-mono">
                            {pkg.name}
                          </h3>
                          <span className="px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-mono text-[10px] font-bold">
                            v{pkg.version}
                          </span>
                        </div>
                        {pkg.author && (
                          <span className="text-[11px] text-slate-500 block mt-0.5">
                            المطور: {pkg.author}
                          </span>
                        )}
                      </div>

                      <a
                        href={pkg.packageUrl || `https://pypi.org/project/${pkg.name}/`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/40 transition-colors"
                        title="فتح صفحة المكتبة على PyPI"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                      </a>
                    </div>

                    {/* Arabic Semantic Insight Banner (if query was in Arabic) */}
                    {pkg.arabicInsight && (
                      <div className="p-2.5 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-xs text-cyan-300 leading-relaxed text-right flex items-start gap-2">
                        <Sparkles className="w-3.5 h-3.5 text-cyan-400 shrink-0 mt-0.5" />
                        <span>{pkg.arabicInsight}</span>
                      </div>
                    )}

                    {/* Official PyPI Summary */}
                    <p className="text-xs text-slate-300 leading-relaxed min-h-[38px] text-right">
                      {pkg.summary}
                    </p>

                    {/* Meta info tags */}
                    <div className="flex flex-wrap items-center gap-1.5 text-[10px] font-mono text-slate-400">
                      {pkg.sizeFormatted && (
                        <span className="px-2 py-0.5 rounded bg-emerald-950/40 border border-emerald-500/30 text-emerald-300">
                          حجم: {pkg.sizeFormatted}
                        </span>
                      )}
                      {pkg.license && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800">
                          {pkg.license}
                        </span>
                      )}
                      {pkg.requiresPython && (
                        <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-400">
                          Python {pkg.requiresPython}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Actions: Install in Termux via Intent & Add to Requirements & Direct Download */}
                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center gap-2">
                    <button
                      onClick={() => handleInstallInTermux(pkg.name)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-md shadow-emerald-500/15 transition-all active:scale-95"
                    >
                      <Terminal className="w-3.5 h-3.5" />
                      <span>{copiedPkg === pkg.name ? 'تم الإرسال لـ Termux!' : 'تثبيت في Termux'}</span>
                    </button>

                    {pkg.downloadUrl && (
                      <a
                        href={pkg.downloadUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="px-2.5 py-2 rounded-xl bg-slate-900 border border-slate-800 hover:border-emerald-500/40 text-slate-300 hover:text-emerald-400 transition-all flex items-center gap-1 text-xs font-semibold"
                        title={`تحميل ملف ${pkg.filename || 'الحزمة'} مباشرة`}
                      >
                        <Download className="w-3.5 h-3.5 text-emerald-400" />
                        <span className="hidden sm:inline">تحميل .whl</span>
                      </a>
                    )}

                    <button
                      onClick={() => handleToggleAddToProject(pkg.name)}
                      className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                        isAddedToProject
                          ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30'
                          : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
                      }`}
                      title="إضافة أو إزالة من requirements.txt"
                    >
                      {isAddedToProject ? (
                        <>
                          <Check className="w-3.5 h-3.5 text-cyan-400" />
                          <span>مُضافة</span>
                        </>
                      ) : (
                        <>
                          <Plus className="w-3.5 h-3.5" />
                          <span>إضافة</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* No results message */}
      {!isLoading && results.length === 0 && (
        <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800 text-center space-y-2">
          <AlertCircle className="w-6 h-6 text-slate-500 mx-auto" />
          <h4 className="text-sm font-bold text-slate-300">لم يتم العثور على نتائج</h4>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            جرب كتابة اسم الحزمة بالإنجليزية بدقة مثل requests أو flask، أو استخدم كلمات عربية عامة مثل "طلبات" أو "تلوين" أو "جداول".
          </p>
        </div>
      )}

    </div>
  );
};
