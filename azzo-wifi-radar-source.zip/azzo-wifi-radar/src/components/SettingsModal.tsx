import React, { useState, useEffect } from 'react';
import { AppSettings, GitHubConfig } from '../types/termuxStudio';
import { loadGitHubConfig } from '../utils/githubService';
import { 
  Settings, 
  X, 
  Check, 
  Terminal, 
  GitBranch, 
  User, 
  HardDrive, 
  Trash2, 
  ShieldCheck, 
  Sparkles,
  Smartphone
} from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenGitHubSetup: () => void;
  onOpenStorageModal: () => void;
  defaultAuthor: string;
  onUpdateDefaultAuthor: (author: string) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  onOpenGitHubSetup,
  onOpenStorageModal,
  defaultAuthor,
  onUpdateDefaultAuthor
}) => {
  const [authorName, setAuthorName] = useState(defaultAuthor);
  const [termuxHome, setTermuxHome] = useState('/data/data/com.termux/files/home');
  const [gitConfig, setGitConfig] = useState<GitHubConfig>(loadGitHubConfig());
  const [notification, setNotification] = useState<string | null>(null);

  useEffect(() => {
    if (isOpen) {
      setGitConfig(loadGitHubConfig());
      setAuthorName(defaultAuthor);
    }
  }, [isOpen, defaultAuthor]);

  if (!isOpen) return null;

  const handleSave = () => {
    onUpdateDefaultAuthor(authorName);
    setNotification('تم حفظ الإعدادات بنجاح!');
    setTimeout(() => {
      setNotification(null);
      onClose();
    }, 1200);
  };

  const handleClearCache = () => {
    if (confirm('هل تريد تفريغ الذاكرة المؤقتة وسجل البحث؟')) {
      localStorage.removeItem('kalbaso_pypi_search_history');
      setNotification('تم تفريغ الذاكرة المؤقتة');
      setTimeout(() => setNotification(null), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-[#030712] border border-slate-800 rounded-3xl shadow-2xl p-6 sm:p-7 overflow-hidden text-right space-y-5">
        
        {/* Glow */}
        <div className="absolute -top-16 -left-16 w-48 h-48 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 left-5 p-2 rounded-xl text-slate-400 hover:text-white bg-slate-900 border border-slate-800 transition-all"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-slate-800 text-emerald-400 border border-slate-700 flex items-center justify-center">
            <Settings className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-slate-100 flex items-center gap-2">
              <span>لوحة الإعدادات والتفضيلات (Settings Panel)</span>
            </h3>
            <p className="text-xs text-slate-400">
              تخصيص هوية المطور، مسارات Termux، وحسابات الربط
            </p>
          </div>
        </div>

        {/* Settings Form */}
        <div className="space-y-4 pt-1 text-xs">
          
          {/* Author Name */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <User className="w-4 h-4 text-emerald-400" />
              <span>اسم المطور الافتراضي (Default Author):</span>
            </label>
            <input
              type="text"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-100 font-mono text-xs focus:outline-none focus:border-emerald-500"
              placeholder="كالبسو مطروح (Calypsu)"
            />
            <span className="text-[10px] text-slate-500 block">
              يُدرج هذا الاسم تلقائياً في ترويسة ملفات بايثون وشاشات الأداة.
            </span>
          </div>

          {/* Termux Paths */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 space-y-2">
            <label className="font-semibold text-slate-200 flex items-center gap-1.5">
              <Terminal className="w-4 h-4 text-yellow-400" />
              <span>مسار المجلد الرئيسي لتيرمكس (Termux Home Path):</span>
            </label>
            <input
              type="text"
              value={termuxHome}
              onChange={(e) => setTermuxHome(e.target.value)}
              className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-slate-300 font-mono text-xs focus:outline-none focus:border-yellow-500"
            />
            <div className="flex items-center gap-2 text-[10px] text-slate-400">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>تصريح RunCommand: com.termux.permission.RUN_COMMAND (مفعل)</span>
            </div>
          </div>

          {/* Connected GitHub Status & Action */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                <GitBranch className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-200 block">حساب GitHub المربوط</span>
                <span className="text-[11px] text-slate-400 font-mono">
                  {gitConfig.isConnected ? `@${gitConfig.username} (متصل ✓)` : 'غير متصل بعد'}
                </span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenGitHubSetup();
              }}
              className="px-3 py-1.5 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30 text-xs font-bold transition-all"
            >
              {gitConfig.isConnected ? 'تعديل الحساب' : 'إعداد الحساب'}
            </button>
          </div>

          {/* Quick Storage Telemetry Launcher */}
          <div className="p-3.5 rounded-2xl bg-slate-900/70 border border-slate-800 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
                <HardDrive className="w-4 h-4" />
              </div>
              <div>
                <span className="font-bold text-slate-200 block">عدادات المساحة والذاكرة</span>
                <span className="text-[11px] text-slate-400">فحص تفصيلي للمساحة المستخدمة والمتاحة</span>
              </div>
            </div>

            <button
              onClick={() => {
                onClose();
                onOpenStorageModal();
              }}
              className="px-3 py-1.5 rounded-xl bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 text-xs font-bold transition-all"
            >
              فتح العدادات
            </button>
          </div>

          {/* Clear Cache */}
          <div className="pt-2 flex items-center justify-between text-slate-400">
            <button
              onClick={handleClearCache}
              className="flex items-center gap-1.5 text-[11px] text-red-400 hover:text-red-300 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>مسح سجل البحث والبيانات المؤقتة</span>
            </button>
          </div>

        </div>

        {notification && (
          <div className="p-2.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>{notification}</span>
          </div>
        )}

        {/* Footer Actions */}
        <div className="pt-3 border-t border-slate-800 flex items-center justify-between text-xs">
          <button
            onClick={handleSave}
            className="px-5 py-2.5 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold transition-all shadow-md shadow-emerald-500/20 active:scale-95"
          >
            حفظ التغييرات
          </button>

          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-colors"
          >
            إلغاء
          </button>
        </div>

      </div>
    </div>
  );
};
