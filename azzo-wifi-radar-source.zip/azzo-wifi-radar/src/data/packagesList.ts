import { PythonPackage } from '../types/termuxStudio';

export const POPULAR_PACKAGES: PythonPackage[] = [
  {
    id: 'requests',
    name: 'requests',
    category: 'network',
    descriptionAr: 'المكتبة القياسية لطلبات HTTP والتعامل مع الويب وAPIs.',
    descriptionEn: 'HTTP library for sending REST requests and web communication.',
    command: 'pip install requests',
    isPopular: true
  },
  {
    id: 'colorama',
    name: 'colorama',
    category: 'ui',
    descriptionAr: 'تلوين نصوص وخلفيات سطر الأوامر بألوان ANSI المتوافقة.',
    descriptionEn: 'Cross-platform colored terminal text & styles.',
    command: 'pip install colorama',
    isPopular: true
  },
  {
    id: 'rich',
    name: 'rich',
    category: 'ui',
    descriptionAr: 'مكتبة الواجهات المتقدمة والجداول والبانلز وأشرطة التقدم.',
    descriptionEn: 'Rich text and beautiful terminal formatting, tables & progress bars.',
    command: 'pip install rich',
    isPopular: true
  },
  {
    id: 'beautifulsoup4',
    name: 'beautifulsoup4',
    category: 'web',
    descriptionAr: 'استخراج وفلترة البيانات وعناصر HTML من صفحات الإنترنت.',
    descriptionEn: 'Screen-scraping library to parse HTML & XML documents.',
    command: 'pip install beautifulsoup4',
    isPopular: true
  },
  {
    id: 'pandas',
    name: 'pandas',
    category: 'data',
    descriptionAr: 'معالجة وتحليل البيانات الضخمة وجداول البيانات الحسابية.',
    descriptionEn: 'Data manipulation and analysis with DataFrame structures.',
    command: 'pip install pandas',
    isPopular: true
  },
  {
    id: 'flask',
    name: 'flask',
    category: 'web',
    descriptionAr: 'إطار عمل سريع لبناء خوادم ويب وواجهات برمجية API في تيرمكس.',
    descriptionEn: 'Lightweight WSGI web application framework & microservices.',
    command: 'pip install flask',
    isPopular: true
  },
  {
    id: 'pyfiglet',
    name: 'pyfiglet',
    category: 'ui',
    descriptionAr: 'توليد نصوص وشعارات ASCII عملاقة ومزخرفة للترمينال.',
    descriptionEn: 'Generates large ASCII art text banners from plain strings.',
    command: 'pip install pyfiglet',
    isPopular: true
  },
  {
    id: 'tqdm',
    name: 'tqdm',
    category: 'ui',
    descriptionAr: 'أشرطة تقدم تفاعلية سريعة وجميلة للحلقات التكرارية والعمليات.',
    descriptionEn: 'Fast, extensible progress meter for loops and tasks.',
    command: 'pip install tqdm',
    isPopular: true
  },
  {
    id: 'psutil',
    name: 'psutil',
    category: 'system',
    descriptionAr: 'فحص معلومات وموارد الجهاز: المعالج، الرام، القرص، والشبكة.',
    descriptionEn: 'Cross-platform process and system monitoring library.',
    command: 'pip install psutil',
    isPopular: true
  },
  {
    id: 'click',
    name: 'click',
    category: 'ui',
    descriptionAr: 'بناء واجهات أوامر CLI احترافية مع دعم المعاملات والخيارات.',
    descriptionEn: 'Composable command-line interface toolkit.',
    command: 'pip install click',
    isPopular: false
  },
  {
    id: 'prompt_toolkit',
    name: 'prompt_toolkit',
    category: 'ui',
    descriptionAr: 'إنشاء برومبت تفاعلي مع الإكمال التلقائي وتلوين الصيغ.',
    descriptionEn: 'Interactive command line prompts with auto-completion.',
    command: 'pip install prompt_toolkit',
    isPopular: false
  },
  {
    id: 'scapy',
    name: 'scapy',
    category: 'network',
    descriptionAr: 'أداة تحليل حزم الشبكة وتوليد الطلبات وفحص الاتصال.',
    descriptionEn: 'Packet manipulation library for networks and packet probing.',
    command: 'pip install scapy',
    isPopular: false
  },
  {
    id: 'aiohttp',
    name: 'aiohttp',
    category: 'network',
    descriptionAr: 'عميل وخادم HTTP غير متزامن (Asynchronous) عالي السرعة.',
    descriptionEn: 'Async HTTP client/server framework for asyncio.',
    command: 'pip install aiohttp',
    isPopular: false
  },
  {
    id: 'tabulate',
    name: 'tabulate',
    category: 'ui',
    descriptionAr: 'تنسيق وطباعة الجداول النصية بأشكال وشبكات أنيقة.',
    descriptionEn: 'Pretty-print tabular data in terminal with multiple grid styles.',
    command: 'pip install tabulate',
    isPopular: false
  },
  {
    id: 'cryptography',
    name: 'cryptography',
    category: 'security',
    descriptionAr: 'تشفير وفك تشفير البيانات وتوليد المفاتيح الآمنة.',
    descriptionEn: 'Cryptographic recipes and primitives for secure data.',
    command: 'pip install cryptography',
    isPopular: false
  },
  {
    id: 'schedule',
    name: 'schedule',
    category: 'system',
    descriptionAr: 'جدولة المهام الدورية وتشغيل الوظائف في أوقات محددة بسهولة.',
    descriptionEn: 'In-process scheduler for periodic jobs using human-readable syntax.',
    command: 'pip install schedule',
    isPopular: false
  }
];
