export interface PyPiPackageInfo {
  name: string;
  version: string;
  summary: string;
  arabicInsight?: string;
  author?: string;
  license?: string;
  homePage?: string;
  packageUrl?: string;
  downloadUrl?: string;
  filename?: string;
  sizeFormatted?: string;
  keywords?: string[];
  requiresPython?: string;
  installedLocally?: boolean;
}

export interface SearchHistoryItem {
  id: string;
  query: string;
  timestamp: number;
  resultCount: number;
}

export const CORE_OFFLINE_PACKAGES: PyPiPackageInfo[] = [
  {
    name: 'requests',
    version: '2.32.3',
    summary: 'مكتبة إرسال طلبات الويب REST API و HTTP القياسية والأكثر استخداماً في بايثون',
    arabicInsight: 'التعامل مع الروابط وجلب الـ APIs وإرسال البيانات',
    author: 'Kenneth Reitz',
    license: 'Apache 2.0',
    packageUrl: 'https://pypi.org/project/requests/',
    downloadUrl: 'https://files.pythonhosted.org/packages/f9/9b/335f9764261e915ed497fcdeb11df5dfd6f7bf257d4a6a2a686d80da4d54/requests-2.32.3-py3-none-any.whl',
    filename: 'requests-2.32.3-py3-none-any.whl',
    sizeFormatted: '63.2 KB'
  },
  {
    name: 'rich',
    version: '13.9.4',
    summary: 'تنسيق نصوص الطرفية وجداول البيانات وأشرطة التقدم الملونة بأسلوب Cyberpunk حديث',
    arabicInsight: 'بناء واجهات طرفية احترافية ملونة وجداول منظمة',
    author: 'Will McGugan',
    license: 'MIT',
    packageUrl: 'https://pypi.org/project/rich/',
    downloadUrl: 'https://files.pythonhosted.org/packages/14/0f/c6f78f309a478b0f4ef937a07fcadce1b3699b6bb3b719460012d93ee8a4/rich-13.9.4-py3-none-any.whl',
    filename: 'rich-13.9.4-py3-none-any.whl',
    sizeFormatted: '242 KB'
  },
  {
    name: 'colorama',
    version: '0.4.6',
    summary: 'دعم ألوان ANSI والـ ANSI Escape Sequences لنصوص الطرفية في تيرمكس',
    arabicInsight: 'تلوين مخرجات النصوص والأخطاء بالأحمر والأخضر والسيان',
    author: 'Jonathan Hartley',
    license: 'BSD-3-Clause',
    packageUrl: 'https://pypi.org/project/colorama/',
    downloadUrl: 'https://files.pythonhosted.org/packages/d1/d6/3965ed04c63042e047cb6a3e6ed1a63a35087b6a609aa3a15ed8ac56c221/colorama-0.4.6-py2.py3-none-any.whl',
    filename: 'colorama-0.4.6-py2.py3-none-any.whl',
    sizeFormatted: '25.3 KB'
  },
  {
    name: 'beautifulsoup4',
    version: '4.12.3',
    summary: 'استخراج وفلترة نصوص وبيانات صفحات الويب (Web Scraping / HTML Parsing)',
    arabicInsight: 'كشط البيانات من صفحات الويب وتحليل وسوم HTML',
    author: 'Leonard Richardson',
    license: 'MIT',
    packageUrl: 'https://pypi.org/project/beautifulsoup4/',
    downloadUrl: 'https://files.pythonhosted.org/packages/b1/bf/73871f3792235efe2ed01120e7dc69a92a54fb27f05c4b815b80ee9f5507/beautifulsoup4-4.12.3-py3-none-any.whl',
    filename: 'beautifulsoup4-4.12.3-py3-none-any.whl',
    sizeFormatted: '115 KB'
  },
  {
    name: 'scapy',
    version: '2.6.1',
    summary: 'فحص الشبكات، تحليل حزم TCP/IP، وتوليد واختبار الاتصالات الشبكية',
    arabicInsight: 'فحص المنافذ وتحليل البروتوكولات والشبكات',
    author: 'Philippe Biondi',
    license: 'GPLv2',
    packageUrl: 'https://pypi.org/project/scapy/',
    downloadUrl: 'https://files.pythonhosted.org/packages/49/b7/b753a3eb217983ea9cf69da97992ad7c39ee3144f80cfa3a95bbdb1c164b/scapy-2.6.1-py3-none-any.whl',
    filename: 'scapy-2.6.1-py3-none-any.whl',
    sizeFormatted: '2.9 MB'
  },
  {
    name: 'cryptography',
    version: '43.0.3',
    summary: 'خوارزميات التشفير القياسية (AES, RSA, ECC, HMAC) والشهادات الرقمية',
    arabicInsight: 'تشفير وحماية البيانات الحساسة وتوليد المفاتيح',
    author: 'Individual developers',
    license: 'Apache 2.0 / BSD',
    packageUrl: 'https://pypi.org/project/cryptography/',
    downloadUrl: 'https://pypi.org/project/cryptography/#files',
    filename: 'cryptography-43.0.3.tar.gz',
    sizeFormatted: '4.8 MB'
  },
  {
    name: 'pyfiglet',
    version: '1.0.2',
    summary: 'توليد الشعارات النصية الكبيرة (ASCII Art Banners) بخطوط متعددة للطرفية',
    arabicInsight: 'رسم شعار أداتك النصي المميز في بداية تشغيل الأداة',
    author: 'Christopher Jones',
    license: 'MIT',
    packageUrl: 'https://pypi.org/project/pyfiglet/',
    downloadUrl: 'https://files.pythonhosted.org/packages/14/06/ef92809e6cda9da525f2334f6bb992da76451e0ff3c332c86ebf9dae0750/pyfiglet-1.0.2-py3-none-any.whl',
    filename: 'pyfiglet-1.0.2-py3-none-any.whl',
    sizeFormatted: '18.2 KB'
  },
  {
    name: 'flask',
    version: '3.1.0',
    summary: 'خادم ويب ميكرو خفيف وسريع لبناء تطبيقات وواجهات RESTful على تيرمكس',
    arabicInsight: 'إنشاء خادم محلي أو واجهة تحكم للوصول عبر المتصفح',
    author: 'Armin Ronacher',
    license: 'BSD-3-Clause',
    packageUrl: 'https://pypi.org/project/flask/',
    downloadUrl: 'https://files.pythonhosted.org/packages/44/28/76a4cd5ab81c706c9e01f5fecf58c7e6c3a116819eb60851ecaa74853e34/flask-3.1.0-py3-none-any.whl',
    filename: 'flask-3.1.0-py3-none-any.whl',
    sizeFormatted: '102 KB'
  },
  {
    name: 'psutil',
    version: '6.1.0',
    summary: 'استعلام ومراقبة موارد النظام والذاكرة العشوائية والمعالج والشبكة على تيرمكس',
    arabicInsight: 'عدادات استهلاك الرام، المعالج، سعة التخزين، والبطارية',
    author: 'Giampaolo Rodola',
    license: 'BSD-3-Clause',
    packageUrl: 'https://pypi.org/project/psutil/',
    downloadUrl: 'https://pypi.org/project/psutil/#files',
    filename: 'psutil-6.1.0.tar.gz',
    sizeFormatted: '498 KB'
  },
  {
    name: 'paramiko',
    version: '3.5.0',
    summary: 'بروتوكول SSHv2 للاتصال الآمن بالخوادم البعيدة وإدارة الأنظمة والملفات',
    arabicInsight: 'الاتصال بالخوادم عبر SSH ونقل الملفات المشفر عبر SFTP',
    author: 'Jeff Forcier',
    license: 'LGPL-2.1',
    packageUrl: 'https://pypi.org/project/paramiko/',
    downloadUrl: 'https://files.pythonhosted.org/packages/34/00/c7f66a203f5685a111b7121703c1e285a2283b7ff48ef2e21245e35db0cb/paramiko-3.5.0-py3-none-any.whl',
    filename: 'paramiko-3.5.0-py3-none-any.whl',
    sizeFormatted: '214 KB'
  },
  {
    name: 'tqdm',
    version: '4.67.1',
    summary: 'أشرطة تقدم سريعة وتفاعلية للعمليات الطويلة والحلقات التكرارية',
    arabicInsight: 'عرض مؤشر النسبة المئوية وسرعة التحميل في الطرفية',
    author: 'Casper da Costa-Luis',
    license: 'MPL-2.0',
    packageUrl: 'https://pypi.org/project/tqdm/',
    downloadUrl: 'https://files.pythonhosted.org/packages/20/4e/1ad6c57f2010cfc24d142f36d4f6ef15bb9db4630a9117da20188b77a0bf/tqdm-4.67.1-py3-none-any.whl',
    filename: 'tqdm-4.67.1-py3-none-any.whl',
    sizeFormatted: '78.5 KB'
  },
  {
    name: 'sqlcipher3',
    version: '0.5.4',
    summary: 'محرك قاعدة بيانات SQLite مع تشفير كامل 256-bit AES لحماية السجلات',
    arabicInsight: 'حفظ وتخزين بيانات الأداة في قاعدة بيانات محلية مشفرة',
    author: 'Charles Leifer',
    license: 'Zlib',
    packageUrl: 'https://pypi.org/project/sqlcipher3/',
    downloadUrl: 'https://pypi.org/project/sqlcipher3/#files',
    filename: 'sqlcipher3-0.5.4.tar.gz',
    sizeFormatted: '110 KB'
  }
];

// Arabic semantic mapping dictionary to translate developer intent into real Python packages
export const ARABIC_SEMANTIC_MAP: Record<string, { packages: string[]; insight: string }> = {
  'طلبات': {
    packages: ['requests', 'httpx', 'aiohttp', 'urllib3'],
    insight: 'مكتبات إرسال واستقبال طلبات HTTP والـ APIs والتعامل مع خوادم الويب'
  },
  'طلب': {
    packages: ['requests', 'httpx'],
    insight: 'أشهر مكتبات إرسال طلبات الويب REST API في بايثون'
  },
  'تلوين': {
    packages: ['colorama', 'rich', 'termcolor', 'colored'],
    insight: 'تلوين نصوص الطرفية وتنسيق مخرجات الأوامر بألوان زاهية'
  },
  'الوان': {
    packages: ['colorama', 'rich', 'termcolor'],
    insight: 'مكتبات دعم ألوان ANSI والستايلات في تيرمكس'
  },
  'ألوان': {
    packages: ['colorama', 'rich', 'termcolor'],
    insight: 'مكتبات دعم ألوان ANSI والستايلات في تيرمكس'
  },
  'جداول': {
    packages: ['rich', 'tabulate', 'prettytable'],
    insight: 'عرض البيانات في جداول نصية منسقة وشبكات متقدمة'
  },
  'جدول': {
    packages: ['rich', 'tabulate', 'prettytable'],
    insight: 'تنسيق الجداول والقوائم في الطرفية'
  },
  'كشط': {
    packages: ['beautifulsoup4', 'lxml', 'scrapy', 'selenium'],
    insight: 'استخراج وفلترة نصوص وبيانات صفحات الويب (Web Scraping)'
  },
  'استخراج': {
    packages: ['beautifulsoup4', 'lxml', 'pandas'],
    insight: 'استخراج ومعالجة البيانات'
  },
  'ويب': {
    packages: ['requests', 'flask', 'beautifulsoup4', 'fastapi'],
    insight: 'حزم الويب والتعامل مع صفحات الإنترنت والخوادم'
  },
  'خادم': {
    packages: ['flask', 'fastapi', 'uvicorn', 'django'],
    insight: 'بناء خوادم وتطبيقات ويب وواجهات RESTful سريعة'
  },
  'سيرفر': {
    packages: ['flask', 'fastapi', 'uvicorn'],
    insight: 'خوادم ويب ميكرو خفيفة تعمل مباشرة على تيرمكس'
  },
  'بيانات': {
    packages: ['pandas', 'numpy', 'scipy'],
    insight: 'تحليل البيانات والمصفوفات الرياضية والجداول الكبيرة'
  },
  'ارقام': {
    packages: ['numpy', 'pandas', 'scipy'],
    insight: 'العمليات الحسابية والمصفوفات الرياضية عالية السرعة'
  },
  'أرقام': {
    packages: ['numpy', 'pandas'],
    insight: 'العمليات الحسابية والمصفوفات الرياضية عالية السرعة'
  },
  'تشفير': {
    packages: ['cryptography', 'pycryptodome', 'bcrypt'],
    insight: 'تشفير البيانات وتوليد المفاتيح والهاشات الآمنة'
  },
  'حماية': {
    packages: ['cryptography', 'paramiko'],
    insight: 'بروتوكولات الأمان والاتصال المشفر عبر SSH والشهادات'
  },
  'واجهة': {
    packages: ['rich', 'click', 'typer', 'prompt_toolkit'],
    insight: 'بناء واجهات تفاعلية وقوائم أزرار لسطر الأوامر'
  },
  'طرفية': {
    packages: ['rich', 'pyfiglet', 'colorama', 'click'],
    insight: 'تنسيق الطرفية والشعارات النصية والأوامر المخصصة'
  },
  'تقدم': {
    packages: ['tqdm', 'alive-progress', 'rich'],
    insight: 'أشرطة تقدم المهام والعمليات التكرارية الطويلة'
  },
  'شريط': {
    packages: ['tqdm', 'alive-progress', 'rich'],
    insight: 'عرض شريط التقدم ونسبة الإنجاز المئوية في الطرفية'
  },
  'موارد': {
    packages: ['psutil', 'gputil'],
    insight: 'مراقبة استهلاك المعالج والرام وسعة التخزين والبطارية'
  },
  'معالج': {
    packages: ['psutil'],
    insight: 'فحص سرعة المعالج واستخدامه ودرجة الحرارة'
  },
  'شبكة': {
    packages: ['scapy', 'requests', 'paramiko', 'socketio'],
    insight: 'فحص الشبكات وحزم الاتصال والبروتوكولات'
  },
  'شبكات': {
    packages: ['scapy', 'requests', 'paramiko'],
    insight: 'فحص الشبكات وحزم الاتصال والبروتوكولات'
  },
  'ذكاء': {
    packages: ['google-genai', 'openai', 'transformers'],
    insight: 'مكتبات الذكاء الاصطناعي وتوليد النصوص ومعالجة اللغات'
  },
  'صور': {
    packages: ['pillow', 'opencv-python', 'qrcode'],
    insight: 'معالجة وتعديل الصور وإنشاء رموز QR'
  },
  'مؤقت': {
    packages: ['schedule', 'apscheduler'],
    insight: 'جدولة المهام الدورية وتشغيل العمليات في أوقات محددة'
  },
  'جدولة': {
    packages: ['schedule', 'apscheduler'],
    insight: 'تشغيل مهام دورية متكررة كل دقيقة أو ساعة'
  }
};

const SEARCH_HISTORY_KEY = 'kalbaso_pypi_search_history';

/**
 * Loads search history from localStorage
 */
export function getSearchHistory(): SearchHistoryItem[] {
  if (typeof window === 'undefined') return [];
  try {
    const raw = localStorage.getItem(SEARCH_HISTORY_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

/**
 * Saves a new query to search history in localStorage
 */
export function saveSearchQuery(query: string, resultCount: number): SearchHistoryItem[] {
  if (typeof window === 'undefined' || !query.trim()) return [];
  try {
    const history = getSearchHistory().filter(item => item.query.toLowerCase() !== query.trim().toLowerCase());
    const newItem: SearchHistoryItem = {
      id: 'search_' + Date.now(),
      query: query.trim(),
      timestamp: Date.now(),
      resultCount
    };
    const updated = [newItem, ...history].slice(0, 12); // keep last 12
    localStorage.setItem(SEARCH_HISTORY_KEY, JSON.stringify(updated));
    return updated;
  } catch {
    return [];
  }
}

/**
 * Clears search history
 */
export function clearSearchHistory(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(SEARCH_HISTORY_KEY);
  } catch {}
}

/**
 * Fetches real-time package information directly from PyPI JSON API:
 * https://pypi.org/pypi/{package}/json
 */
export async function fetchPyPiPackage(packageName: string): Promise<PyPiPackageInfo | null> {
  const cleanName = packageName.trim().toLowerCase();
  if (!cleanName) return null;

  // Check if we have exact match in offline core catalog first
  const coreMatch = CORE_OFFLINE_PACKAGES.find(p => p.name.toLowerCase() === cleanName);

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 6000);

    const res = await fetch(`https://pypi.org/pypi/${cleanName}/json`, {
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (!res.ok) {
      return coreMatch || null;
    }

    const data = await res.json();
    const info = data.info || {};
    const urls = Array.isArray(data.urls) ? data.urls : [];

    // Find wheel or first release file
    const wheelFile = urls.find((u: any) => u.filename && u.filename.endsWith('.whl')) || urls[0];
    const downloadUrl = wheelFile?.url || coreMatch?.downloadUrl || `https://pypi.org/project/${cleanName}/#files`;
    const filename = wheelFile?.filename || coreMatch?.filename || `${cleanName}-${info.version || 'latest'}.whl`;
    const sizeBytes = wheelFile?.size || 0;
    const sizeFormatted = sizeBytes > 1024 * 1024 
      ? `${(sizeBytes / (1024 * 1024)).toFixed(1)} MB`
      : sizeBytes > 1024 
        ? `${(sizeBytes / 1024).toFixed(1)} KB`
        : coreMatch?.sizeFormatted || 'حزمة بايثون';

    return {
      name: info.name || cleanName,
      version: info.version || coreMatch?.version || 'latest',
      summary: info.summary || coreMatch?.summary || 'مكتبة بايثون متاحة على مستودع PyPI الرسمي',
      author: info.author || info.maintainer || coreMatch?.author || 'Open Source Community',
      license: info.license || coreMatch?.license || 'OSI Approved',
      homePage: info.home_page || info.project_url || `https://pypi.org/project/${cleanName}/`,
      packageUrl: info.package_url || `https://pypi.org/project/${cleanName}/`,
      downloadUrl,
      filename,
      sizeFormatted,
      arabicInsight: coreMatch?.arabicInsight,
      keywords: info.keywords ? (Array.isArray(info.keywords) ? info.keywords : info.keywords.split(',').map((k: string) => k.trim())) : [],
      requiresPython: info.requires_python || '>=3.7'
    };
  } catch (err) {
    return coreMatch || {
      name: cleanName,
      version: 'latest',
      summary: `مكتبة ${cleanName} على مستودع PyPI`,
      packageUrl: `https://pypi.org/project/${cleanName}/`,
      downloadUrl: `https://pypi.org/project/${cleanName}/#files`,
      filename: `${cleanName}.whl`,
      sizeFormatted: 'أمر تثبيت جاهز'
    };
  }
}

/**
 * Performs Smart Multi-Layer Search:
 * 1. Checks if the query matches Arabic semantic concepts (e.g. "طلبات" -> requests, aiohttp, etc.)
 * 2. Matches with pre-packaged core offline catalog
 * 3. Fetches live package data from PyPI JSON API
 */
export async function performSmartPackageSearch(
  query: string,
  onProgress?: (msg: string) => void
): Promise<PyPiPackageInfo[]> {
  const trimmed = query.trim().toLowerCase();
  if (!trimmed) return CORE_OFFLINE_PACKAGES.slice(0, 6);

  const candidatePackageNames: { name: string; arabicInsight?: string }[] = [];

  // 1. Check Arabic Semantic Map
  for (const [key, val] of Object.entries(ARABIC_SEMANTIC_MAP)) {
    if (trimmed.includes(key) || key.includes(trimmed)) {
      val.packages.forEach(pkg => {
        if (!candidatePackageNames.some(c => c.name === pkg)) {
          candidatePackageNames.push({ name: pkg, arabicInsight: val.insight });
        }
      });
    }
  }

  // 2. Check Core Offline catalog by name or summary
  CORE_OFFLINE_PACKAGES.forEach(pkg => {
    if (
      pkg.name.toLowerCase().includes(trimmed) || 
      pkg.summary.toLowerCase().includes(trimmed) ||
      (pkg.arabicInsight && pkg.arabicInsight.includes(trimmed))
    ) {
      if (!candidatePackageNames.some(c => c.name === pkg.name)) {
        candidatePackageNames.push({ name: pkg.name, arabicInsight: pkg.arabicInsight });
      }
    }
  });

  // 3. Direct candidate
  const isEnglishOrSlug = /^[a-zA-Z0-9_-]+$/.test(trimmed);
  if (isEnglishOrSlug && !candidatePackageNames.some(c => c.name === trimmed)) {
    candidatePackageNames.unshift({ name: trimmed });
  }

  if (candidatePackageNames.length === 0) {
    return CORE_OFFLINE_PACKAGES.slice(0, 6);
  }

  onProgress?.(`جارٍ جلب البيانات الحية من مستودع PyPI الرسمي لـ ${candidatePackageNames.length} مكتبات...`);

  // Query PyPI
  const results: PyPiPackageInfo[] = [];

  const promises = candidatePackageNames.slice(0, 10).map(async (candidate) => {
    const pypiData = await fetchPyPiPackage(candidate.name);
    if (pypiData) {
      if (candidate.arabicInsight) {
        pypiData.arabicInsight = candidate.arabicInsight;
      }
      return pypiData;
    }
    return null;
  });

  const settled = await Promise.all(promises);
  settled.forEach(item => {
    if (item && !results.some(r => r.name.toLowerCase() === item.name.toLowerCase())) {
      results.push(item);
    }
  });

  return results.length > 0 ? results : CORE_OFFLINE_PACKAGES.slice(0, 6);
}
