import { GitHubConfig } from '../types/termuxStudio';

const GITHUB_STORAGE_KEY = 'kalbaso_github_settings';

export const DEFAULT_GITHUB_CONFIG: GitHubConfig = {
  username: '',
  token: '',
  email: '',
  defaultRepo: 'kalbaso-termux-tools',
  isConnected: false
};

export function loadGitHubConfig(): GitHubConfig {
  if (typeof window === 'undefined') return DEFAULT_GITHUB_CONFIG;
  try {
    const raw = localStorage.getItem(GITHUB_STORAGE_KEY);
    return raw ? JSON.parse(raw) : DEFAULT_GITHUB_CONFIG;
  } catch {
    return DEFAULT_GITHUB_CONFIG;
  }
}

export function saveGitHubConfig(config: GitHubConfig): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.setItem(GITHUB_STORAGE_KEY, JSON.stringify(config));
  } catch (err) {
    console.error('Failed to save GitHub config:', err);
  }
}

export function clearGitHubConfig(): void {
  if (typeof window === 'undefined') return;
  try {
    localStorage.removeItem(GITHUB_STORAGE_KEY);
  } catch {}
}

export interface GitHubTestResult {
  success: boolean;
  user?: {
    login: string;
    name: string;
    avatar_url: string;
    public_repos: number;
    email: string;
  };
  error?: string;
}

/**
 * Validates Personal Access Token with authentic GitHub API
 */
export async function testGitHubConnection(token: string, username?: string): Promise<GitHubTestResult> {
  const cleanToken = token.trim();
  if (!cleanToken) {
    return { success: false, error: 'يرجى إدخال التوكن (Personal Access Token) أولاً' };
  }

  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 8000);

    const res = await fetch('https://api.github.com/user', {
      method: 'GET',
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'Authorization': `Bearer ${cleanToken}`
      },
      signal: controller.signal
    });
    clearTimeout(timeoutId);

    if (res.status === 401) {
      return { success: false, error: 'التوكن غير صالح أو منتهي الصلاحية (401 Unauthorized)' };
    }

    if (!res.ok) {
      return { success: false, error: `خطأ في الاتصال بـ GitHub API (رمز: ${res.status})` };
    }

    const data = await res.json();
    
    // Check if username was provided and matches
    if (username && username.trim() && data.login.toLowerCase() !== username.trim().toLowerCase()) {
      return {
        success: true,
        user: data,
        error: `تنبيه: التوكن صالح للمستخدم (${data.login}) بينما كتبت (${username.trim()})`
      };
    }

    return {
      success: true,
      user: data
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.name === 'AbortError' ? 'انتهت مهلة الاتصال بخوادم GitHub' : (err?.message || 'تعذر الاتصال بـ GitHub')
    };
  }
}

/**
 * Pushes a file directly to a GitHub Repository via GitHub Contents API
 */
export async function pushFileToGitHubRepo(params: {
  token: string;
  owner: string;
  repo: string;
  path: string;
  content: string;
  commitMessage: string;
}): Promise<{ success: boolean; commitUrl?: string; error?: string }> {
  const { token, owner, repo, path, content, commitMessage } = params;
  
  try {
    const cleanToken = token.trim();
    const cleanOwner = owner.trim();
    const cleanRepo = repo.trim();
    const cleanPath = path.trim().replace(/^\//, '');

    // 1. Check if file already exists to get its SHA (required by GitHub API for updates)
    let fileSha: string | undefined;
    try {
      const getRes = await fetch(`https://api.github.com/repos/${cleanOwner}/${cleanRepo}/contents/${cleanPath}`, {
        headers: {
          'Accept': 'application/vnd.github.v3+json',
          'Authorization': `Bearer ${cleanToken}`
        }
      });
      if (getRes.ok) {
        const fileData = await getRes.json();
        fileSha = fileData.sha;
      }
    } catch {}

    // 2. Base64 encode file content (UTF-8 safe)
    const base64Content = btoa(unescape(encodeURIComponent(content)));

    // 3. Send PUT request to create/update file
    const putRes = await fetch(`https://api.github.com/repos/${cleanOwner}/${cleanRepo}/contents/${cleanPath}`, {
      method: 'PUT',
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'Authorization': `Bearer ${cleanToken}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: commitMessage,
        content: base64Content,
        sha: fileSha
      })
    });

    if (putRes.status === 404) {
      return {
        success: false,
        error: `المستودع (${cleanOwner}/${cleanRepo}) غير موجود، أو التوكن لا يمتلك صلاحية repo.`
      };
    }

    if (!putRes.ok) {
      const errJson = await putRes.json().catch(() => ({}));
      return {
        success: false,
        error: errJson.message || `فشل الرفع برمز حالة ${putRes.status}`
      };
    }

    const resData = await putRes.json();
    return {
      success: true,
      commitUrl: resData.commit?.html_url || `https://github.com/${cleanOwner}/${cleanRepo}`
    };
  } catch (err: any) {
    return {
      success: false,
      error: err?.message || 'تعذر إتمام عملية الرفع إلى GitHub'
    };
  }
}

/**
 * Generates automated Termux Bash / Python script that securely sets up Git,
 * writes ~/.netrc with strict 0600 permissions, and configures automated push
 */
export function generateTermuxGitSetupScript(config: GitHubConfig, toolSlug: string): string {
  const username = config.username || 'your_username';
  const token = config.token || 'your_token';
  const repo = config.defaultRepo || 'kalbaso-termux-tools';

  return `#!/data/data/com.termux/files/usr/bin/bash
# ===================================================================
# KALBASO GitHub Auto-Config & Security Setup for Termux
# Developer: كالبسو مطروح (Calypsu)
# ===================================================================

set -e

echo -e "\\e[1;36m[*] Configuring GitHub Credentials securely in Termux...\\e[0m"

# 1. Setup git user info
git config --global user.name "${username}"
${config.email ? `git config --global user.email "${config.email}"` : ''}

# 2. Securely write credentials into ~/.netrc with strict 0600 permissions (Protected)
mkdir -p "$HOME"
cat << 'EOF' > "$HOME/.netrc"
machine github.com
login ${username}
password ${token}

machine api.github.com
login ${username}
password ${token}
EOF

# Enforce secure permissions 600 (Only owner can read/write)
chmod 600 "$HOME/.netrc"
echo -e "\\e[1;32m[✓] ~/.netrc created and protected with chmod 600 (Strict permissions)\\e[0m"

# 3. Create or push repository automatically
TARGET_DIR="$HOME/kalbaso_tools/${toolSlug}"
if [ -d "$TARGET_DIR" ]; then
    cd "$TARGET_DIR"
    git init -b main 2>/dev/null || git init
    git add .
    git commit -m "Auto Push: ${toolSlug} created with KALBASO Termux Studio" || true
    git remote remove origin 2>/dev/null || true
    git remote add origin "https://github.com/${username}/${repo}.git"
    echo -e "\\e[1;33m[*] Pushing ${toolSlug} to https://github.com/${username}/${repo}...\\e[0m"
    git push -u origin main
    echo -e "\\e[1;32m[✓] Successfully pushed to GitHub!\\e[0m"
else
    echo -e "\\e[1;33m[i] Credentials verified. To push this tool, run this from $TARGET_DIR\\e[0m"
fi
`;
}

/**
 * Creates repository on GitHub if it doesn't already exist
 */
export async function createGitHubRepositoryIfNotExists(
  token: string,
  repoName: string
): Promise<{ success: boolean; repoUrl?: string; error?: string }> {
  try {
    const res = await fetch('https://api.github.com/user/repos', {
      method: 'POST',
      headers: {
        'Accept': 'application/vnd.github.v3+json',
        'Authorization': `Bearer ${token.trim()}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        name: repoName.trim(),
        description: 'KALBASO Termux Studio Native Android IDE (Developed by كالبسو مطروح Calypsu 🇪🇬)',
        private: false,
        auto_init: false
      })
    });

    if (res.status === 201 || res.status === 200) {
      const data = await res.json();
      return { success: true, repoUrl: data.html_url };
    }

    // 422 usually means repository already exists, which is completely fine!
    if (res.status === 422) {
      return { success: true };
    }

    const err = await res.json().catch(() => ({}));
    return { success: false, error: err.message || `رمز الخطأ: ${res.status}` };
  } catch (e: any) {
    return { success: false, error: e?.message || 'تعذر الاتصال بخوادم GitHub' };
  }
}

/**
 * Pushes the full Android Kotlin Project with GitHub Actions APK auto-builder to GitHub
 */
export async function pushFullAndroidProjectToGitHub(params: {
  token: string;
  owner: string;
  repo: string;
  projectFiles: { path: string; content: string }[];
  onProgress?: (current: number, total: number, path: string) => void;
}): Promise<{ success: boolean; actionsUrl: string; repoUrl: string; pushedCount: number; error?: string }> {
  const { token, owner, repo, projectFiles, onProgress } = params;
  const repoName = repo.trim() || 'kalbaso-termux-studio';
  const cleanOwner = owner.trim();

  // 1. Ensure repo exists
  await createGitHubRepositoryIfNotExists(token, repoName);

  let successCount = 0;
  const total = projectFiles.length;

  for (let i = 0; i < total; i++) {
    const file = projectFiles[i];
    onProgress?.(i + 1, total, file.path);

    const res = await pushFileToGitHubRepo({
      token,
      owner: cleanOwner,
      repo: repoName,
      path: file.path,
      content: file.content,
      commitMessage: `Add ${file.path} (Ready for GitHub Actions APK Build)`
    });

    if (res.success) {
      successCount++;
    } else {
      console.warn(`Failed to push file ${file.path}:`, res.error);
    }
    // slight delay to prevent GitHub secondary rate limiting
    await new Promise(r => setTimeout(r, 200));
  }

  const actionsUrl = `https://github.com/${cleanOwner}/${repoName}/actions`;
  const repoUrl = `https://github.com/${cleanOwner}/${repoName}`;

  if (successCount === 0) {
    return {
      success: false,
      actionsUrl,
      repoUrl,
      pushedCount: 0,
      error: 'لم يتمكن التطبيق من رفع الملفات. تأكد أن التوكن يمتلك صلاحيات repo كاملة.'
    };
  }

  return {
    success: true,
    actionsUrl,
    repoUrl,
    pushedCount: successCount
  };
}
