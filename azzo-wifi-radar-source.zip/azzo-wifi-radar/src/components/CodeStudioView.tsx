import React, { useState } from 'react';
import { ToolConfig, GitHubConfig } from '../types/termuxStudio';
import { generatePythonCode, generateRequirementsTxt, generateInstallScript } from '../data/codeTemplates';
import { generateToolZipPackage, downloadBlobAsFile } from '../utils/nativeZipPackager';
import { runCommandInTermux, saveScriptToDevice } from '../utils/termuxBridge';
import confetti from 'canvas-confetti';
import { 
  Terminal, 
  Copy, 
  Download, 
  Play, 
  Check, 
  FileCode, 
  Archive, 
  Sparkles, 
  Send, 
  RefreshCw,
  GitBranch,
  UploadCloud,
  Settings
} from 'lucide-react';

interface CodeStudioViewProps {
  config: ToolConfig;
  gitConfig?: GitHubConfig;
  onOpenGitHubModal?: () => void;
}

export const CodeStudioView: React.FC<CodeStudioViewProps> = ({ 
  config,
  gitConfig,
  onOpenGitHubModal
}) => {
  const [activeFileTab, setActiveFileTab] = useState<'python' | 'requirements' | 'installSh' | 'oneLiner'>('python');
  const [isCopied, setIsCopied] = useState<boolean>(false);
  const [isZipping, setIsZipping] = useState<boolean>(false);
  
  // Interactive Terminal Runner State
  const [terminalRunning, setTerminalRunning] = useState<boolean>(false);
  const [terminalLogs, setTerminalLogs] = useState<string[]>([]);
  const [terminalInput, setTerminalInput] = useState<string>('');

  const pythonCode = generatePythonCode(config);
  const requirementsTxt = generateRequirementsTxt(config.selectedPackages);
  const installSh = generateInstallScript(config);

  // One-liner Termux command that creates the file and executes it directly
  const oneLinerCommand = `mkdir -p ~/kalbaso_tools && cat << 'EOF' > ~/kalbaso_tools/${config.toolSlug}.py
${pythonCode}
EOF
chmod +x ~/kalbaso_tools/${config.toolSlug}.py && python ~/kalbaso_tools/${config.toolSlug}.py`;

  const handleCopy = (text: string) => {
    navigator.clipboard.writeText(text);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2500);
  };

  const handleDownloadPython = () => {
    const blob = new Blob([pythonCode], { type: 'text/x-python;charset=utf-8' });
    downloadBlobAsFile(blob, `${config.toolSlug}.py`);
  };

  const handleDownloadZip = async () => {
    try {
      setIsZipping(true);
      const zipBlob = await generateToolZipPackage(config);
      downloadBlobAsFile(zipBlob, `${config.toolSlug}-kalbaso-package.zip`);
      try {
        confetti({ particleCount: 40, spread: 50, origin: { y: 0.7 } });
      } catch {}
    } finally {
      setIsZipping(false);
    }
  };

  const [statusNotification, setStatusNotification] = useState<string | null>(null);

  /**
   * Send code directly to Termux via Intent or Android Deep Link & save to device
   */
  const handlePushToTermux = async () => {
    // 1. Save file directly to device
    saveScriptToDevice(`${config.toolSlug}.py`, pythonCode);

    // 2. Execute via Termux Bridge
    const res = await runCommandInTermux(oneLinerCommand);
    setStatusNotification(res.message);
    setTimeout(() => setStatusNotification(null), 4000);
  };

  // Start Interactive Terminal Test Run
  const startLiveRun = () => {
    setTerminalRunning(true);
    setTerminalLogs([
      `[*] Booting ${config.toolName} in simulated Termux environment...`,
      `[*] Target Python: 3.12.4 POSIX (aarch64)`,
      `------------------------------------------------------------`,
      `[+] ${config.toolName} v${config.version} initialized!`,
      `[+] Author: ${config.author}`,
      `------------------------------------------------------------`,
      `[1] تشغيل المهمة الرئيسية (${config.menuItems[0]?.labelAr || 'Primary Routine'})`,
      `[2] فحص موارد النظام والذاكرة`,
      `[3] استعراض الحزم النشطة (${config.selectedPackages.length} مكتبات)`,
      `[0] خروج من الأداة`,
      `------------------------------------------------------------`,
      `${config.toolSlug} > يرجى كتابة رقم الخيار (1-3 أو 0) ثم الضغط على Enter:`
    ]);
  };

  const handleTerminalSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = terminalInput.trim();
    if (!val) return;

    const newLogs = [...terminalLogs, `${config.toolSlug} > ${val}`];

    if (val === '1') {
      newLogs.push(
        `[*] جاري تنفيذ المهمة الأساسية للأداة...`,
        `  --> تحميل الوحدات البرمجية... [100%]`,
        `  --> فحص الاتصال وقنوات الإدخال... [OK]`,
        `[SUCCESS] اكتملت المهمة البرمجية بنجاح تام!`,
        `${config.toolSlug} > اختر العملية التالية (1-3 أو 0 للخروج):`
      );
    } else if (val === '2') {
      newLogs.push(
        `[*] تشخيص البيئة والنظام:`,
        `  • نظام التشغيل : Linux Android (Termux POSIX)`,
        `  • بيئة المعالج  : ARM64-v8a (64-bit)`,
        `  • مفسر بايثون  : Python 3.12.4`,
        `  • المسار الحالي : /data/data/com.termux/files/home`,
        `[OK] جميع الموارد تعمل بأعلى كفاءة.`,
        `${config.toolSlug} > اختر العملية التالية (1-3 أو 0 للخروج):`
      );
    } else if (val === '3') {
      newLogs.push(
        `[*] المكتبات المربوطة بالأداة:`,
        ...(config.selectedPackages.length
          ? config.selectedPackages.map(p => `  • ${p} : [مُثبتة وجاهزة للاستدعاء]`)
          : [`  • مكتبات بايثون القياسية (بدون متطلبات خارجية)`]),
        `${config.toolSlug} > اختر العملية التالية (1-3 أو 0 للخروج):`
      );
    } else if (val === '0' || val.toLowerCase() === 'exit') {
      newLogs.push(`[!] تم إنهاء جلسة ${config.toolName}. شكراً لاستخدامك الأداة!`);
    } else {
      newLogs.push(`[!] خيار غير صحيح (${val}). اكتب 1 أو 2 أو 3 أو 0 للخروج.`);
    }

    setTerminalLogs(newLogs);
    setTerminalInput('');
  };

  const getActiveCode = () => {
    switch (activeFileTab) {
      case 'requirements':
        return requirementsTxt;
      case 'installSh':
        return installSh;
      case 'oneLiner':
        return oneLinerCommand;
      case 'python':
      default:
        return pythonCode;
    }
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Studio Header Bar */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-950 to-[#030712] border border-purple-500/30 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/30 text-purple-400 text-xs font-bold font-mono">
              <FileCode className="w-3.5 h-3.5" />
              <span>مولد الكود ومحرر الطرفية (Code Generator & Live Terminal)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
              كود بايثون حقيقي 100% مبني ومجهز لتيرمكس
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
              تم توليد كود الأداة بالكامل وفق القالب المختار (<span className="text-purple-300 font-bold">{config.template}</span>) مع الشعار واسم المطور، ومكتبات <code className="text-cyan-300 font-mono">requirements.txt</code> وسكربت التثبيت <code className="text-emerald-300 font-mono">install.sh</code>.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => handleCopy(getActiveCode())}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-purple-500/40 text-purple-300 hover:bg-purple-500/10 text-xs font-bold transition-all"
            >
              {isCopied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              <span>{isCopied ? 'تم النسخ!' : 'نسخ الكود'}</span>
            </button>

            <button
              onClick={handleDownloadPython}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10 text-xs font-bold transition-all"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل {config.toolSlug}.py</span>
            </button>

            <button
              onClick={handleDownloadZip}
              disabled={isZipping}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-indigo-600 hover:from-purple-400 hover:to-indigo-500 text-white font-bold text-xs shadow-lg shadow-purple-500/20 active:scale-95 transition-all disabled:opacity-50"
            >
              <Archive className="w-4 h-4" />
              <span>{isZipping ? 'جارٍ الضغط...' : 'تنزيل حزمة ZIP'}</span>
            </button>

            <button
              onClick={handlePushToTermux}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
            >
              <Send className="w-4 h-4" />
              <span>إرسال لتيرمكس (Intent)</span>
            </button>

            {/* GitHub Setup Button */}
            <button
              onClick={onOpenGitHubModal}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10 text-xs font-bold transition-all"
              title="إعداد حساب GitHub وحفظ التوكن في ~/.netrc بصلابة chmod 600"
            >
              <GitBranch className="w-4 h-4 text-cyan-400" />
              <span>Setup GitHub Account</span>
              {gitConfig?.isConnected && <Check className="w-3.5 h-3.5 text-emerald-400" />}
            </button>

            {/* Push File Button */}
            <button
              onClick={onOpenGitHubModal}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white font-bold text-xs shadow-lg shadow-cyan-600/20 active:scale-95 transition-all"
              title="رفع الأداة مباشرة إلى مستودع GitHub"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Push File (GitHub)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Real-time Status Alert */}
      {statusNotification && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs sm:text-sm font-semibold flex items-center gap-2.5 animate-in fade-in duration-200">
          <Check className="w-5 h-5 text-emerald-400 shrink-0" />
          <span>{statusNotification}</span>
        </div>
      )}

      {/* Code Editor & Live Runner Split Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Column: Code Editor & Files Tabs (7 cols) */}
        <div className="lg:col-span-7 rounded-2xl bg-slate-950 border border-slate-800 overflow-hidden flex flex-col shadow-2xl">
          
          {/* File Tabs */}
          <div className="flex items-center justify-between border-b border-slate-800/80 bg-slate-900/80 px-4 py-2">
            <div className="flex items-center gap-1.5 overflow-x-auto text-xs font-mono">
              <button
                onClick={() => setActiveFileTab('python')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all ${
                  activeFileTab === 'python'
                    ? 'bg-purple-500/20 text-purple-300 border border-purple-500/40 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <FileCode className="w-3.5 h-3.5 text-purple-400" />
                <span>{config.toolSlug}.py</span>
              </button>

              <button
                onClick={() => setActiveFileTab('requirements')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all ${
                  activeFileTab === 'requirements'
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>requirements.txt</span>
              </button>

              <button
                onClick={() => setActiveFileTab('installSh')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all ${
                  activeFileTab === 'installSh'
                    ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <span>install.sh</span>
              </button>

              <button
                onClick={() => setActiveFileTab('oneLiner')}
                className={`flex items-center gap-2 px-3 py-1.5 rounded-lg transition-all ${
                  activeFileTab === 'oneLiner'
                    ? 'bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 font-bold'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                <Terminal className="w-3.5 h-3.5 text-yellow-400" />
                <span>أمر سطر واحد لتيرمكس</span>
              </button>
            </div>

            <button
              onClick={() => handleCopy(getActiveCode())}
              className="text-xs text-slate-400 hover:text-white flex items-center gap-1 font-mono"
            >
              <Copy className="w-3 h-3" />
              <span>نسخ</span>
            </button>
          </div>

          {/* Code Viewer with Line Numbers */}
          <div className="p-4 overflow-x-auto max-h-[560px] scrollbar-thin font-mono text-xs leading-relaxed text-slate-300 dir-ltr text-left selection:bg-purple-500/30 selection:text-purple-200">
            <pre className="whitespace-pre">
              {getActiveCode()}
            </pre>
          </div>
        </div>

        {/* Right Column: Interactive Terminal Test Runner (5 cols) */}
        <div className="lg:col-span-5 rounded-2xl bg-[#030712] border border-emerald-500/30 overflow-hidden flex flex-col shadow-2xl justify-between">
          
          {/* Terminal Window Bar */}
          <div className="flex items-center justify-between border-b border-slate-900 bg-slate-950 px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-yellow-500/80 inline-block"></span>
              <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
              <span className="text-xs font-mono text-slate-400 mr-2">termux@android ~/{config.toolSlug}</span>
            </div>

            <button
              onClick={startLiveRun}
              className="flex items-center gap-1.5 px-3 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 hover:bg-emerald-500/30 text-xs font-bold transition-all active:scale-95"
            >
              <Play className="w-3.5 h-3.5 fill-current" />
              <span>{terminalRunning ? 'إعادة التشغيل' : 'تجربة الأداة حياً'}</span>
            </button>
          </div>

          {/* Terminal Output Screen */}
          <div className="p-4 font-mono text-xs text-emerald-400 space-y-2 min-h-[380px] max-h-[460px] overflow-y-auto scrollbar-thin dir-ltr text-left select-text">
            {!terminalRunning ? (
              <div className="h-full flex flex-col items-center justify-center text-center p-6 space-y-4 text-slate-500">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                  <Terminal className="w-6 h-6" />
                </div>
                <div>
                  <h4 className="font-bold text-slate-300 text-sm">المشغل التجريبي التفاعلي المباشر</h4>
                  <p className="text-xs text-slate-500 mt-1 max-w-xs">
                    اضغط زر "تجربة الأداة حياً" لمعاينة واجهة الأداة، القائمة التفاعلية، والألوان مباشرة قبل نقلها للهاتف.
                  </p>
                </div>
                <button
                  onClick={startLiveRun}
                  className="px-4 py-2 rounded-xl bg-emerald-500 text-slate-950 font-bold text-xs shadow-lg shadow-emerald-500/20"
                >
                  بدء التجربة الآن ▶
                </button>
              </div>
            ) : (
              terminalLogs.map((log, index) => (
                <div key={index} className="leading-relaxed whitespace-pre-wrap break-words">
                  {log}
                </div>
              ))
            )}
          </div>

          {/* Terminal Input Form */}
          {terminalRunning && (
            <form onSubmit={handleTerminalSubmit} className="p-3 bg-slate-950 border-t border-slate-900 flex items-center gap-2">
              <span className="text-emerald-400 font-mono text-xs font-bold">$</span>
              <input
                type="text"
                value={terminalInput}
                onChange={(e) => setTerminalInput(e.target.value)}
                placeholder="اكتب رقم الخيار (1-3 أو 0) واضغط Enter..."
                className="flex-1 bg-transparent border-none text-slate-100 text-xs font-mono focus:outline-none placeholder:text-slate-600"
                autoFocus
              />
              <button
                type="submit"
                className="px-3 py-1 rounded bg-emerald-500 text-slate-950 text-xs font-bold font-mono"
              >
                إرسال
              </button>
            </form>
          )}

        </div>
      </div>

    </div>
  );
};
