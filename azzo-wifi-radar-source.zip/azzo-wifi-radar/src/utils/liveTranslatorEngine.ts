export interface SubtitleItem {
  id: string;
  chunkNumber: number;
  timestamp: string;
  durationSeconds: number;
  originalText: string;
  translatedText: string;
  sourceLang: string;
  confidence: number;
}

/**
 * ترجمة النصوص إلى العربية الفصحى عبر واجهة الترجمة السحابية السريعة
 */
export async function translateToArabic(text: string, sourceLang: string = 'auto'): Promise<string> {
  if (!text || !text.trim()) return '';

  const cleanText = text.trim();

  // المحاولة الأولى: عبر واجهة Google Translate المجانية
  try {
    const sl = sourceLang === 'auto' ? 'auto' : sourceLang;
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${sl}&tl=ar&dt=t&q=${encodeURIComponent(cleanText)}`;
    
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      if (Array.isArray(data) && Array.isArray(data[0])) {
        const fullTranslation = data[0]
          .map((part: any) => (part && part[0] ? part[0] : ''))
          .join('');
        if (fullTranslation && fullTranslation.trim()) {
          return fullTranslation.trim();
        }
      }
    }
  } catch (err) {
    console.warn('Direct translation failed, attempting fallback...', err);
  }

  // المحاولة الثانية: خدمة بديلة سريعة MyMemory
  try {
    const mmUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(cleanText)}&langpair=${sourceLang === 'auto' ? 'en' : sourceLang}|ar`;
    const mmRes = await fetch(mmUrl);
    if (mmRes.ok) {
      const mmData = await mmRes.json();
      if (mmData?.responseData?.translatedText) {
        return mmData.responseData.translatedText;
      }
    }
  } catch (err) {
    console.warn('MyMemory fallback failed:', err);
  }

  return cleanText;
}

/**
 * تشغيل الصوت العربي نطقاً (Arabic Text-to-Speech)
 */
export function speakArabicText(text: string) {
  if (!('speechSynthesis' in window)) return;

  window.speechSynthesis.cancel();
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = 'ar-SA';
  utterance.rate = 0.95;
  utterance.pitch = 1.0;

  // البحث عن صوت عربي نقي
  const voices = window.speechSynthesis.getVoices();
  const arabicVoice = voices.find(v => v.lang.startsWith('ar') || v.name.toLowerCase().includes('arabic'));
  if (arabicVoice) {
    utterance.voice = arabicVoice;
  }

  window.speechSynthesis.speak(utterance);
}

/**
 * تصدير سجلات الترجمة الحية كملف ترجمات SRT متوافق مع كافة مشغلات الفيديو والصوت
 */
export function exportSubtitlesAsSrt(subtitles: SubtitleItem[]): string {
  return subtitles
    .map((sub, index) => {
      const startSec = index * 8;
      const endSec = startSec + sub.durationSeconds;

      const formatTime = (secs: number) => {
        const h = Math.floor(secs / 3600).toString().padStart(2, '0');
        const m = Math.floor((secs % 3600) / 60).toString().padStart(2, '0');
        const s = Math.floor(secs % 60).toString().padStart(2, '0');
        return `${h}:${m}:${s},000`;
      };

      return `${index + 1}\n${formatTime(startSec)} --> ${formatTime(endSec)}\n${sub.translatedText}\n[${sub.originalText}]\n`;
    })
    .join('\n');
}

/**
 * تصدير سجلات الترجمة كنص بسيط
 */
export function exportSubtitlesAsTxt(subtitles: SubtitleItem[]): string {
  const header = `=== سجل الترجمة الحية Live Audio Translator ===\nتاريخ التصدير: ${new Date().toLocaleString('ar')}\nإجمالي المقاطع المترجمة: ${subtitles.length}\n${'='.repeat(50)}\n\n`;
  const body = subtitles
    .map(
      (s) =>
        `[${s.timestamp}] مقطع #${s.chunkNumber} (${s.durationSeconds} ثوانٍ)\nالأصل (${s.sourceLang}): ${s.originalText}\nالترجمة العربية: ${s.translatedText}\n${'-'.repeat(40)}`
    )
    .join('\n\n');

  return header + body;
}

/**
 * إعداد فحص دعم SpeechRecognition في المتصفح
 */
export function getSpeechRecognitionConstructor(): any {
  if (typeof window === 'undefined') return null;
  return (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition || null;
}
