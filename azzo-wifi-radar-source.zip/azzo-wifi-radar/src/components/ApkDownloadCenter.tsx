import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  CheckCircle2,
  ShieldCheck,
  QrCode,
  ExternalLink,
  Sparkles,
  Info,
  Layers,
  ChevronDown,
  Terminal,
  Radio,
  Share2
} from 'lucide-react';
import QRCode from 'qrcode';
import confetti from 'canvas-confetti';

interface ApkDownloadCenterProps {
  onDirectDownload: () => void;
  isDownloading: boolean;
}

export const ApkDownloadCenter: React.FC<ApkDownloadCenterProps> = ({
  onDirectDownload,
  isDownloading
}) => {
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [activeGuideTab, setActiveGuideTab] = useState<'apk' | 'pwa' | 'termux'>('apk');
  const [isCopiedLink, setIsCopiedLink] = useState(false);

  useEffect(() => {
    // توليد باركود QR لرابط التطبيق والتحميل
    const currentUrl = window.location.href;
    QRCode.toDataURL(currentUrl, {
      width: 200,
      margin: 1,
      color: {
        dark: '#059669',
        light: '#ffffff'
      }
    })
      .then(url => setQrDataUrl(url))
      .catch(err => console.error('QR code error:', err));
  }, []);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: 'Live Audio Translator APK',
        text: 'تطبيق ترجمة البث الصوتي المباشر وراديو العالم إلى العربية',
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setIsCopiedLink(true);
      setTimeout(() => setIsCopiedLink(false), 2000);
    }
  };

  return (
    <div className="space-y-8">
      
      {/* Hero Master Download Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-900 to-emerald-950/60 border-2 border-emerald-500/40 rounded-3xl p-6 sm:p-10 shadow-2xl relative overflow-hidden">
        
        {/* Glow decoration */}
        <div className="absolute -top-20 -left-20 w-80 h-80 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-20 -right-20 w-80 h-80 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center relative z-10">
          
          {/* Main Info */}
          <div className="lg:col-span-8 space-y-4">
            <div className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-500/40">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>نسخة رسمية جاهزة للتحميل والتثبيت الفوري</span>
            </div>

            <h2 className="text-2xl sm:text-4xl font-black text-white tracking-tight leading-tight">
              تطبيق Live Audio Translator بصيغة APK
            </h2>

            <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
              حزمة أندرويد مستقلة (APK) تدعم اللغة العربية دعماً كاملاً وبخط واضح، تتيح لك الاستماع لمحطات الراديو العالمية وترجمتها لحظياً سطر بسطر على هاتفك، مع تكامل كامل مع بيئة Termux وأدوات الذكاء الاصطناعي.
            </p>

            {/* App Specs Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
              <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">الإصدار</span>
                <span className="text-xs sm:text-sm font-bold text-white font-mono">v1.2.0 (Build 2026)</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">الحجم التقديري</span>
                <span className="text-xs sm:text-sm font-bold text-emerald-400 font-mono">~14.8 MB</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">النظام المدعوم</span>
                <span className="text-xs sm:text-sm font-bold text-white">Android 8.0 - 15+</span>
              </div>
              <div className="bg-slate-950/70 border border-slate-800 p-3 rounded-2xl">
                <span className="text-[11px] text-slate-500 block">دعم اللغة العربية</span>
                <span className="text-xs sm:text-sm font-bold text-teal-400">كامل 100% RTL</span>
              </div>
            </div>

            {/* Actions: Download Button & Share */}
            <div className="flex flex-wrap items-center gap-3 pt-3">
              <button
                onClick={onDirectDownload}
                disabled={isDownloading}
                className="flex items-center gap-3 px-8 py-4 rounded-2xl text-base sm:text-lg font-black bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 transition-all shadow-xl shadow-emerald-500/30 active:scale-95 disabled:opacity-50"
              >
                <Download className="w-5 h-5 text-slate-950" />
                <span>{isDownloading ? 'جارٍ بدء التحميل...' : 'تحميل حزمة APK مباشرة (14.8 MB)'}</span>
              </button>

              <button
                onClick={handleShare}
                className="flex items-center gap-2 px-5 py-4 rounded-2xl text-sm font-bold bg-slate-950 hover:bg-slate-800 text-slate-200 border border-slate-700 transition-all active:scale-95"
              >
                <Share2 className="w-4 h-4 text-emerald-400" />
                <span>{isCopiedLink ? 'تم نسخ الرابط!' : 'مشاركة الرابط'}</span>
              </button>
            </div>
          </div>

          {/* QR Code Card for Scanning with Android Phone */}
          <div className="lg:col-span-4 flex flex-col items-center justify-center p-6 bg-slate-950/80 border border-emerald-500/30 rounded-3xl shadow-xl">
            <div className="p-3 bg-white rounded-2xl shadow-lg mb-3">
              {qrDataUrl ? (
                <img src={qrDataUrl} alt="QR Code for Mobile Download" className="w-40 h-40 block" />
              ) : (
                <div className="w-40 h-40 flex items-center justify-center text-slate-400">
                  <QrCode className="w-12 h-12" />
                </div>
              )}
            </div>
            <span className="text-xs font-bold text-slate-200 flex items-center gap-1.5 mb-1">
              <QrCode className="w-4 h-4 text-emerald-400" />
              <span>امسح الباركود بكاميرا هاتفك</span>
            </span>
            <span className="text-[11px] text-slate-400 text-center">
              للفتح المباشر والتحميل على هاتفك الأندرويد في ثوانٍ
            </span>
          </div>
        </div>
      </div>

      {/* Installation Guide Tabs */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4 mb-6">
          <h3 className="text-xl font-bold text-white flex items-center gap-2">
            <Smartphone className="w-5 h-5 text-emerald-400" />
            <span>طرق التثبيت والتشغيل على أجهزة أندرويد</span>
          </h3>

          <div className="flex items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
            <button
              onClick={() => setActiveGuideTab('apk')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeGuideTab === 'apk'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تثبيت حزمة APK
            </button>
            <button
              onClick={() => setActiveGuideTab('pwa')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeGuideTab === 'pwa'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              التثبيت الفوري (PWA)
            </button>
            <button
              onClick={() => setActiveGuideTab('termux')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                activeGuideTab === 'termux'
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              تطبيق Termux
            </button>
          </div>
        </div>

        {/* Tab Content: APK Installation Guide */}
        {activeGuideTab === 'apk' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm mb-3">
                1
              </div>
              <h4 className="text-sm font-bold text-white mb-1.5">تحميل ملف APK</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                اضغط على زر "تحميل حزمة APK مباشرة" أعلاه وسيتم تنزيل ملف <strong>LiveAudioTranslator.apk</strong> إلى مجلد التنزيلات (Downloads).
              </p>
            </div>

            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm mb-3">
                2
              </div>
              <h4 className="text-sm font-bold text-white mb-1.5">السماح بتثبيت التطبيقات</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                عند الضغط على الملف، إذا ظهر تنبيه الأمان، اختر <strong>"الإعدادات"</strong> وفعّل خيار <strong>"السماح بتثبيت التطبيقات من هذا المصدر"</strong>.
              </p>
            </div>

            <div className="bg-slate-950 p-5 rounded-2xl border border-slate-800">
              <div className="w-8 h-8 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center font-bold text-sm mb-3">
                3
              </div>
              <h4 className="text-sm font-bold text-white mb-1.5">فتح التطبيق ومنح إذن الصوت</h4>
              <p className="text-xs text-slate-400 leading-relaxed">
                اضغط "تثبيت" ثم "فتح". اسمح بإذن الميكروفون والصوت لتبدأ الاستماع للراديو ومشاهدة الترجمة العربية الحية فوراً!
              </p>
            </div>
          </div>
        )}

        {/* Tab Content: PWA Guide */}
        {activeGuideTab === 'pwa' && (
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-3">
              <Sparkles className="w-6 h-6 text-teal-400" />
              <div>
                <h4 className="text-base font-bold text-white">تثبيت التطبيق مباشرة بدون تحميل ملف خارجي (PWA)</h4>
                <p className="text-xs text-slate-400">يعمل بكفاءة فائقة على متصفح Chrome أو Samsung Internet أو Firefox للأندرويد</p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
                <span className="font-bold text-emerald-400 block mb-1">الخطوة 1:</span>
                افتح هذه الصفحة في متصفح هاتفك المحمول.
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
                <span className="font-bold text-emerald-400 block mb-1">الخطوة 2:</span>
                اضغط على زر القائمة (الثلاث نقاط) في المتصفح.
              </div>
              <div className="p-3 bg-slate-900 rounded-xl border border-slate-800 text-xs text-slate-300">
                <span className="font-bold text-emerald-400 block mb-1">الخطوة 3:</span>
                اختر <strong>"إضافة إلى الشاشة الرئيسية"</strong> أو <strong>"تثبيت التطبيق"</strong>.
              </div>
            </div>
          </div>
        )}

        {/* Tab Content: Termux Guide */}
        {activeGuideTab === 'termux' && (
          <div className="bg-slate-950 p-6 rounded-2xl border border-slate-800 space-y-4">
            <div className="flex items-center gap-3">
              <Terminal className="w-6 h-6 text-emerald-400" />
              <div>
                <h4 className="text-base font-bold text-white">تثبيت تطبيق Termux من F-Droid</h4>
                <p className="text-xs text-slate-400">النسخة الرسمية المحدثة من تيرموكس تدعم بيئة بايثون و ffmpeg بالكامل</p>
              </div>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              للحصول على أفضل تجربة مع حزمة البايثون، يُنصح بتثبيت Termux من متجر <strong>F-Droid</strong> المجاني وليس من متجر Play Store لأن نسخة Play Store قديمة وغير مدعومة.
            </p>

            <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 font-mono text-xs text-emerald-400 select-all" dir="ltr">
              pkg update -y && pkg install -y python ffmpeg git && curl -sL https://raw.githubusercontent.com/termux-audio-trans/installer/main/install.sh | bash
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
