#!/usr/bin/env python3
import os
import sys
import subprocess
import shutil

print("[*] Starting Standalone Offline Android APK Build for KALBASO Termux Studio...")

BUILD_DIR = "/tmp/build_apk_calypso"
if os.path.exists(BUILD_DIR):
    shutil.rmtree(BUILD_DIR)

os.makedirs(f"{BUILD_DIR}/src/com/calypso/kalbasotermuxstudio", exist_ok=True)
os.makedirs(f"{BUILD_DIR}/res/values", exist_ok=True)
os.makedirs(f"{BUILD_DIR}/res/drawable", exist_ok=True)
os.makedirs(f"{BUILD_DIR}/bin/classes", exist_ok=True)
os.makedirs(f"{BUILD_DIR}/assets", exist_ok=True)

# 1. Prepare assets from dist/ (copying web app files while excluding recursive APKs)
print("[*] Copying dist web app assets into Android assets directory...")
DIST_DIR = "dist"
for root, dirs, files in os.walk(DIST_DIR):
    rel_path = os.path.relpath(root, DIST_DIR)
    dest_dir = os.path.join(f"{BUILD_DIR}/assets", rel_path)
    os.makedirs(dest_dir, exist_ok=True)
    for file in files:
        if file.endswith(".apk") or file.endswith(".idsig"):
            continue  # do not duplicate APKs inside assets
        src_file = os.path.join(root, file)
        dest_file = os.path.join(dest_dir, file)
        shutil.copyfile(src_file, dest_file)

# 2. AndroidManifest.xml
manifest_content = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.calypso.kalbasotermuxstudio"
    android:versionCode="1"
    android:versionName="1.0.0">

    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="33" />

    <uses-permission android:name="com.termux.permission.RUN_COMMAND" />
    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application
        android:label="@string/app_name"
        android:icon="@drawable/ic_launcher"
        android:allowBackup="true"
        android:hardwareAccelerated="true"
        android:theme="@android:style/Theme.DeviceDefault.NoActionBar">

        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>

    </application>
</manifest>
"""

with open(f"{BUILD_DIR}/AndroidManifest.xml", "w", encoding="utf-8") as f:
    f.write(manifest_content)

# 3. strings.xml
strings_content = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">KALBASO Termux Studio</string>
    <string name="developer_name">كالبسو مطروح (Calypsu)</string>
</resources>
"""
with open(f"{BUILD_DIR}/res/values/strings.xml", "w", encoding="utf-8") as f:
    f.write(strings_content)

# 4. Icon
shutil.copyfile("public/app_icon.jpg", f"{BUILD_DIR}/res/drawable/ic_launcher.jpg")

# 5. Native Java Activity (Offline WebView loading file:///android_asset/index.html)
java_activity = """package com.calypso.kalbasotermuxstudio;

import android.app.Activity;
import android.os.Bundle;
import android.os.Environment;
import android.content.Intent;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.JavascriptInterface;
import android.widget.Toast;
import android.view.KeyEvent;
import java.io.File;
import java.io.FileOutputStream;

/**
 * KALBASO Termux Studio
 * Developer: Calypsu Matrouh (كالبسو مطروح) 🇪🇬
 * Offline Standalone Android App with Native Termux RUN_COMMAND Bridge
 */
public class MainActivity extends Activity {

    private WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        webView = new WebView(this);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setAllowFileAccessFromFileURLs(true);
        settings.setAllowUniversalAccessFromFileURLs(true);
        settings.setUseWideViewPort(true);
        settings.setLoadWithOverviewMode(true);
        settings.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.startsWith("intent:") || url.startsWith("tel:") || url.startsWith("mailto:") || url.startsWith("market:")) {
                    try {
                        Intent intent = Intent.parseUri(url, Intent.URI_INTENT_SCHEME);
                        if (intent != null) {
                            startActivity(intent);
                            return true;
                        }
                    } catch (Exception e) {
                        // ignore
                    }
                    return true;
                }
                return false;
            }
        });

        // Add native bridge to dispatch Termux commands directly
        webView.addJavascriptInterface(new TermuxWebAppInterface(this), "AndroidTermuxBridge");

        // Load 100% offline standalone studio interface from inside APK
        webView.loadUrl("file:///android_asset/index.html");
        setContentView(webView);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if ((keyCode == KeyEvent.KEYCODE_BACK) && webView.canGoBack()) {
            webView.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    public static class TermuxWebAppInterface {
        private Activity activity;

        public TermuxWebAppInterface(Activity activity) {
            this.activity = activity;
        }

        private void copyToClipboard(String label, String text) {
            try {
                ClipboardManager clipboard = (ClipboardManager) activity.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText(label, text);
                clipboard.setPrimaryClip(clip);
            } catch (Exception ignored) {}
        }

        private void launchTermuxApp() {
            try {
                Intent launchIntent = activity.getPackageManager().getLaunchIntentForPackage("com.termux");
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    activity.startActivity(launchIntent);
                }
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void installPackage(String packageName) {
            final String pkg = packageName.trim();
            final String cmd = "pip install --upgrade " + pkg;
            copyToClipboard("pip_install", cmd);

            // Dispatch Termux RUN_COMMAND Intent
            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName("com.termux", "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/pip");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"install", "--upgrade", pkg});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
            intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");

            try {
                activity.startService(intent);
            } catch (Exception e) {
                launchTermuxApp();
            }

            launchTermuxApp();
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "تم فتح تيرمكس ونسخ أمر pip للحافظة!", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void runCommand(String command) {
            final String cmd = command.trim();
            copyToClipboard("termux_command", cmd);

            Intent intent = new Intent("com.termux.RUN_COMMAND");
            intent.setClassName("com.termux", "com.termux.app.RunCommandService");
            intent.putExtra("com.termux.RUN_COMMAND_PATH", "/data/data/com.termux/files/usr/bin/bash");
            intent.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", new String[]{"-c", cmd});
            intent.putExtra("com.termux.RUN_COMMAND_WORKDIR", "/data/data/com.termux/files/home");
            intent.putExtra("com.termux.RUN_COMMAND_BACKGROUND", false);
            intent.putExtra("com.termux.RUN_COMMAND_SESSION_ACTION", "0");

            try {
                activity.startService(intent);
            } catch (Exception e) {
                launchTermuxApp();
            }

            launchTermuxApp();
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, "تم فتح Termux ونسخ الأمر للحافظة! الصق الأمر واضغط Enter", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void openTermux(String command) {
            if (command != null && !command.isEmpty()) {
                copyToClipboard("termux_command", command);
            }
            launchTermuxApp();
        }

        @JavascriptInterface
        public boolean saveFileToDownloads(String fileName, String content) {
            try {
                File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists()) {
                    dir.mkdirs();
                }
                File file = new File(dir, fileName);
                FileOutputStream fos = new FileOutputStream(file);
                fos.write(content.getBytes("UTF-8"));
                fos.close();

                activity.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(activity, "تم حفظ الملف بنجاح في مجلد Downloads!", Toast.LENGTH_SHORT).show();
                    }
                });
                return true;
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public void shareScript(String title, String content) {
            try {
                Intent shareIntent = new Intent(Intent.ACTION_SEND);
                shareIntent.setType("text/plain");
                shareIntent.putExtra(Intent.EXTRA_SUBJECT, title);
                shareIntent.putExtra(Intent.EXTRA_TEXT, content);
                activity.startActivity(Intent.createChooser(shareIntent, "مشاركة الكود البرمجي"));
            } catch (Exception ignored) {}
        }

        @JavascriptInterface
        public void showToast(final String message) {
            activity.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(activity, message, Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface
        public boolean isTermuxInstalled() {
            try {
                activity.getPackageManager().getPackageInfo("com.termux", 0);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
"""

with open(f"{BUILD_DIR}/src/com/calypso/kalbasotermuxstudio/MainActivity.java", "w", encoding="utf-8") as f:
    f.write(java_activity)

# 6. Compile Java
print("[*] Compiling Java Activity...")
cmd_javac = [
    "javac",
    "-source", "8",
    "-target", "8",
    "-bootclasspath", "/tmp/android.jar",
    "-cp", "/tmp/android.jar",
    "-d", f"{BUILD_DIR}/bin/classes",
    f"{BUILD_DIR}/src/com/calypso/kalbasotermuxstudio/MainActivity.java"
]
subprocess.run(cmd_javac, check=True)

# 7. Dalvik DEX compilation
print("[*] Converting bytecode to Dalvik DEX...")
cmd_dx = [
    "/usr/bin/dalvik-exchange",
    "--dex",
    f"--output={BUILD_DIR}/bin/classes.dex",
    f"{BUILD_DIR}/bin/classes"
]
subprocess.run(cmd_dx, check=True)

# 8. AAPT packaging with Assets folder
print("[*] Packaging binary resources, AXML & offline assets with AAPT...")
cmd_aapt = [
    "aapt",
    "package",
    "-f",
    "-m",
    "-J", f"{BUILD_DIR}/src",
    "-M", f"{BUILD_DIR}/AndroidManifest.xml",
    "-S", f"{BUILD_DIR}/res",
    "-A", f"{BUILD_DIR}/assets",
    "-I", "/tmp/android.jar",
    "-F", f"{BUILD_DIR}/bin/intermediate.apk"
]
subprocess.run(cmd_aapt, check=True)

# Add classes.dex into the APK
print("[*] Adding classes.dex to APK archive...")
subprocess.run(["aapt", "add", f"{BUILD_DIR}/bin/intermediate.apk", "classes.dex"], cwd=f"{BUILD_DIR}/bin", check=True)

# 9. Zipalign (4-byte alignment)
print("[*] Aligning APK with zipalign...")
cmd_zipalign = [
    "zipalign",
    "-f",
    "-v", "4",
    f"{BUILD_DIR}/bin/intermediate.apk",
    f"{BUILD_DIR}/bin/aligned.apk"
]
subprocess.run(cmd_zipalign, check=True)

# 10. Keystore and apksigner
KEYSTORE = "/tmp/calypso_release.jks"
if not os.path.exists(KEYSTORE):
    cmd_keytool = [
        "keytool",
        "-genkey",
        "-v",
        "-keystore", KEYSTORE,
        "-alias", "calypso",
        "-keyalg", "RSA",
        "-keysize", "2048",
        "-validity", "10000",
        "-storepass", "calypso2026",
        "-keypass", "calypso2026",
        "-dname", "CN=Calypsu Matrouh, OU=KALBASO, O=Termux Studio, L=Matrouh, ST=Egypt, C=EG"
    ]
    subprocess.run(cmd_keytool, check=True)

# Sign with APK Signature Scheme v1, v2, v3
print("[*] Signing APK with apksigner (v1, v2, v3 schemes)...")
TARGET_APK = "public/KALBASO-Termux-Studio.apk"
cmd_sign = [
    "apksigner",
    "sign",
    "--ks", KEYSTORE,
    "--ks-pass", "pass:calypso2026",
    "--key-pass", "pass:calypso2026",
    "--v1-signing-enabled", "true",
    "--v2-signing-enabled", "true",
    "--v3-signing-enabled", "true",
    "--out", TARGET_APK,
    f"{BUILD_DIR}/bin/aligned.apk"
]
subprocess.run(cmd_sign, check=True)

# Verify APK
print("[*] Verifying signed APK with apksigner...")
cmd_verify = ["apksigner", "verify", "-v", TARGET_APK]
verify_res = subprocess.run(cmd_verify, capture_output=True, text=True, check=True)
print(verify_res.stdout)

# Copy to artifacts directory and other fallback paths
shutil.copyfile(TARGET_APK, "public/Calpso-ESP266.apk")
shutil.copyfile(TARGET_APK, "public/LiveAudioTranslator.apk")
shutil.copyfile(TARGET_APK, "public/calypso-os-esp266-launcher.apk")
shutil.copyfile(TARGET_APK, ".aistudio/artifacts/brain/1ba6cef8-9780-4c3c-b4cb-69e50773fb50/KALBASO-Termux-Studio.apk")

print(f"[SUCCESS] 100% Offline Standalone Android APK created successfully at {TARGET_APK} (Size: {os.path.getsize(TARGET_APK)} bytes)!")
