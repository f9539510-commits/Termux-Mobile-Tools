#!/data/data/com.termux/files/usr/bin/bash
# =========================================================
# عزو شبكات | Ezzo Networks CLI for Termux
# فحص وتحليل شبكات الواي فاي الحقيقي سطر الأوامر
# =========================================================

CYAN='\033[0;36m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
PURPLE='\033[0;35m'
BLUE='\033[0;34m'
NC='\033[0m'
BOLD='\033[1m'

clear
echo -e "${CYAN}${BOLD}"
echo "  ███████╗███████╗███████╗ ██████╗ "
echo "  ██╔════╝╚══███╔╝╚══███╔╝██╔═══██╗"
echo "  █████╗    ███╔╝   ███╔╝ ██║   ██║"
echo "  ██╔══╝   ███╔╝   ███╔╝  ██║   ██║"
echo "  ███████╗███████╗███████╗╚██████╔╝"
echo "  ╚══════╝╚══════╝╚══════╝ ╚═════╝ "
echo -e "${YELLOW}  ★ رادار عزو لفحص وتحليل شبكات الواي فاي الحقيقي ★${NC}"
echo -e "${PURPLE}  ==============================================${NC}"
echo ""

# Check dependencies
if ! command -v termux-wifi-scaninfo &> /dev/null; then
    echo -e "${YELLOW}[!] جاري تثبيت حزم termux-api و jq المطلوبة للفحص...${NC}"
    pkg update -y && pkg install -y termux-api jq curl
fi

SCAN_FILE="/tmp/ezzo_wifi_scan.json"

scan_wifi() {
    echo -e "${CYAN}[*] جاري فحص رقاقة الواي فاي بالأقمار والموقع (Live Scan)...${NC}"
    termux-wifi-scaninfo > "$SCAN_FILE" 2>/dev/null
    
    COUNT=$(jq '. | length' "$SCAN_FILE" 2>/dev/null || echo 0)
    
    if [ "$COUNT" -eq 0 ] || [ -z "$COUNT" ]; then
        echo -e "${RED}[!] لم يتم العثور على شبكات أو صلاحية الموقع غير مفعّلة في تيرمكس.${NC}"
        echo -e "${YELLOW}[i] تأكد من: 1) تشغيل الواي فاي  2) تشغيل الـ GPS  3) إعطاء Termux:API إذن الموقع.${NC}"
        return 1
    fi
    
    echo -e "${GREEN}[✓] تم رصد ${COUNT} شبكة واي فاي حقيقية بنجاح!${NC}"
    return 0
}

display_table() {
    echo ""
    echo -e "${BOLD}${BLUE}╔════╦══════════════════════════╦═══════════════════╦════════╦═══════╦══════════════╦════════╗${NC}"
    printf "${BOLD}${BLUE}║${YELLOW} %-2s ${BLUE}║${CYAN} %-24s ${BLUE}║${PURPLE} %-17s ${BLUE}║${GREEN} %-6s ${BLUE}║${NC} %-5s ${BLUE}║${YELLOW} %-12s ${BLUE}║${RED} %-6s ${BLUE}║\n" "#" "اسم الشبكة (SSID)" "BSSID (MAC)" "الإشارة" "قناة" "التشفير" "WPS"
    echo -e "${BLUE}╠════╬══════════════════════════╬═══════════════════╬════════╬═══════╬══════════════╬════════╣${NC}"
    
    INDEX=1
    jq -c '.[]' "$SCAN_FILE" 2>/dev/null | while read -r net; do
        SSID=$(echo "$net" | jq -r '.ssid // "[مخفية]"' | cut -c1-24)
        BSSID=$(echo "$net" | jq -r '.bssid // "00:00:00:00:00:00"')
        RSSI=$(echo "$net" | jq -r '.rssi // 0')
        FREQ=$(echo "$net" | jq -r '.frequency_mhz // 2437')
        CAPS=$(echo "$net" | jq -r '.capabilities // ""')
        
        SEC="WPA2"
        if [[ "$CAPS" == *"WPA3"* ]] || [[ "$CAPS" == *"SAE"* ]]; then
            SEC="WPA3"
        elif [[ "$CAPS" == *"WEP"* ]]; then
            SEC="WEP"
        elif [[ "$CAPS" != *"WPA"* ]]; then
            SEC="OPEN"
        fi
        
        CH=1
        if [ "$FREQ" -ge 2412 ] && [ "$FREQ" -le 2484 ]; then
            CH=$(( (FREQ - 2407) / 5 ))
        elif [ "$FREQ" -ge 5170 ] && [ "$FREQ" -le 5825 ]; then
            CH=$(( (FREQ - 5000) / 5 ))
        fi
        
        WPS="لا"
        if [[ "$CAPS" == *"WPS"* ]]; then
            WPS="مفعل"
        fi
        
        printf "${BLUE}║${YELLOW} %-2d ${BLUE}║${NC} %-24s ${BLUE}║${NC} %-17s ${BLUE}║${GREEN} %-4s dB ${BLUE}║${NC} %-5s ${BLUE}║${YELLOW} %-12s ${BLUE}║${RED} %-6s ${BLUE}║\n" "$INDEX" "$SSID" "$BSSID" "$RSSI" "$CH" "$SEC" "$WPS"
        INDEX=$((INDEX + 1))
    done
    echo -e "${BLUE}╚════╩══════════════════════════╩═══════════════════╩════════╩═══════╩══════════════╩════════╝${NC}"
    echo ""
}

audit_network() {
    CHOICE=$1
    NET=$(jq -c ".[$((CHOICE - 1))]" "$SCAN_FILE" 2>/dev/null)
    if [ -z "$NET" ] || [ "$NET" == "null" ]; then
        echo -e "${RED}[!] اختيار غير صحيح.${NC}"
        return
    fi
    
    SSID=$(echo "$NET" | jq -r '.ssid')
    BSSID=$(echo "$NET" | jq -r '.bssid')
    RSSI=$(echo "$NET" | jq -r '.rssi')
    FREQ=$(echo "$NET" | jq -r '.frequency_mhz')
    CAPS=$(echo "$NET" | jq -r '.capabilities')
    
    echo -e "${GREEN}${BOLD}═════════════════════════════════════════════════${NC}"
    echo -e "${YELLOW}  فحص واختبار أمني لشبكة: ${BOLD}$SSID${NC}"
    echo -e "${CYAN}  الهدف: BSSID: $BSSID | التردد: ${FREQ}MHz | الإشارة: ${RSSI}dBm${NC}"
    echo -e "${GREEN}═════════════════════════════════════════════════${NC}"
    echo ""
    echo -e "${BOLD}[1] فحص ثغرات WPS:${NC}"
    if [[ "$CAPS" == *"WPS"* ]]; then
        echo -e "${RED}  [!] تنبيه: خاصية WPS مفعّلة في هذا الراوتر!${NC}"
        echo -e "  يمكنك اختبار هجمات WPS PIN عبر الأوامر التالية:"
        echo -e "  ${YELLOW}reaver -i wlan0 -b $BSSID -vv -K 1${NC}"
        echo -e "  ${YELLOW}bully wlan0 -b $BSSID -d -v 3${NC}"
    else
        echo -e "${GREEN}  [✓] ممتاز: خاصية WPS معطلة (الراوتر محمي ضد ثغرات الـ PIN).${NC}"
    fi
    echo ""
    echo -e "${BOLD}[2] فحص التشفير والتقاط Handshake:${NC}"
    echo -e "  التشفير: ${YELLOW}$CAPS${NC}"
    echo -e "  أمر التقاط الحزم والمصافحة:"
    echo -e "  ${CYAN}airodump-ng -c 6 --bssid $BSSID -w ezzo_capture wlan0${NC}"
    echo ""
    echo -e "${BOLD}[3] فحص استقرار الإشارة (Ping / Latency):${NC}"
    echo -e "  قوة الإشارة الحالية: ${GREEN}${RSSI} dBm${NC}"
    echo ""
    echo -e "${PURPLE}اضغط Enter للعودة للقائمة الرئيسية...${NC}"
    read -r
}

# Initial Scan
scan_wifi
if [ $? -eq 0 ]; then
    display_table
fi

while true; do
    echo -e "${YELLOW}اختر عملية:${NC}"
    echo -e "  [${GREEN}1-${COUNT}${NC}] فحص واختبار شبكة معينة بالتفصيل"
    echo -e "  [${CYAN}R${NC}] إعادة مسح الشبكات الحقيقية (Refresh Scan)"
    echo -e "  [${PURPLE}S${NC}] مزامنة الشبكات مع تطبيق الويب فوراً"
    echo -e "  [${RED}Q${NC}] خروج"
    echo ""
    read -p "أدخل اختيارك: " opt
    
    case "$opt" in
        [rR])
            clear
            scan_wifi
            if [ $? -eq 0 ]; then
                display_table
            fi
            ;;
        [sS])
            read -p "أدخل رابط التطبيق (مثال: https://...): " HOST_URL
            if [ -n "$HOST_URL" ]; then
                curl -s -X POST -H "Content-Type: application/json" -d @"$SCAN_FILE" "${HOST_URL}/api/wifi/sync"
                echo -e "${GREEN}[✓] تم إرسال الشبكات إلى شاشة التطبيق بنجاح!${NC}"
            fi
            ;;
        [qQ])
            echo -e "${GREEN}شكراً لاستخدامك عزو شبكات!${NC}"
            exit 0
            ;;
        *)
            if [[ "$opt" =~ ^[0-9]+$ ]] && [ "$opt" -ge 1 ] && [ "$opt" -le "$COUNT" ]; then
                clear
                audit_network "$opt"
                clear
                display_table
            else
                echo -e "${RED}[!] اختيار غير صحيح.${NC}"
            fi
            ;;
    esac
done
