export interface TermuxFile {
  name: string;
  path: string;
  language: string;
  description: string;
  content: string;
}

export interface RadioStation {
  id: string;
  name: string;
  country: string;
  language: string;
  languageCode: string;
  streamUrl: string;
  category: string;
  logo: string;
  bitrate: string;
}

export const RADIO_STATIONS_CATALOG: RadioStation[] = [
  {
    id: 'bbc-world-service',
    name: 'BBC World Service News',
    country: 'المملكة المتحدة',
    language: 'English',
    languageCode: 'en',
    streamUrl: 'https://stream.live.vc.bbcmedia.co.uk/bbc_world_service',
    category: 'أخبار عالمية وتقارير',
    logo: '🇬🇧',
    bitrate: '128 kbps'
  },
  {
    id: 'npr-news',
    name: 'NPR 24 Hour News',
    country: 'الولايات المتحدة',
    language: 'English',
    languageCode: 'en',
    streamUrl: 'https://npr-ice.streamguys1.com/live.mp3',
    category: 'أخبار وتحليلات عامة',
    logo: '🇺🇸',
    bitrate: '96 kbps'
  },
  {
    id: 'france-info',
    name: 'France Info (Radio France)',
    country: 'فرنسا',
    language: 'French',
    languageCode: 'fr',
    streamUrl: 'https://icecast.radiofrance.fr/franceinfo-midfi.mp3',
    category: 'أخبار باللغة الفرنسية',
    logo: '🇫🇷',
    bitrate: '128 kbps'
  },
  {
    id: 'dw-english',
    name: 'Deutsche Welle (DW Audio)',
    country: 'ألمانيا',
    language: 'English',
    languageCode: 'en',
    streamUrl: 'https://dwstream72-lh.akamaihd.net/i/dwstream72_live@123962/master.m3u8',
    category: 'أخبار أوروبية وعالمية',
    logo: '🇩🇪',
    bitrate: '128 kbps'
  },
  {
    id: 'radio-monte-carlo',
    name: 'Monte Carlo Doualiya',
    country: 'فرنسا / العالم العربي',
    language: 'French / Arabic',
    languageCode: 'fr',
    streamUrl: 'https://montecarlodoualiya128k.streamguys1.com/mcd-128k.mp3',
    category: 'منوعات وحوارات ثقافية',
    logo: '📻',
    bitrate: '128 kbps'
  },
  {
    id: 'sky-news-radio',
    name: 'Sky News Radio UK',
    country: 'بريطانيا',
    language: 'English',
    languageCode: 'en',
    streamUrl: 'https://radio.canstream.co.uk:9083/live.mp3',
    category: 'أخبار عاجلة واقتصاد',
    logo: '🇬🇧',
    bitrate: '128 kbps'
  },
  {
    id: 'nhk-world',
    name: 'NHK World Radio Japan',
    country: 'اليابان',
    language: 'English',
    languageCode: 'en',
    streamUrl: 'https://nhkworld.webcdn.stream.ne.jp/www11/nhkworld-radio/english/sub.m3u8',
    category: 'أخبار آسيوية وثقافية',
    logo: '🇯🇵',
    bitrate: '96 kbps'
  }
];

export const TERMUX_PROJECT_FILES: TermuxFile[] = [
  {
    name: 'main.py',
    path: 'main.py',
    language: 'python',
    description: 'الملف التنفيذي الرئيسي - واجهة CLI التفاعلية والشاشة الحية',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Live Audio Translator for Termux
=================================
أداة ذكية للاستماع إلى بث الراديو المباشر، تسجيل مقاطع صوتية قصيرة،
وتحويلها إلى نصوص وترجمتها لحظياً إلى اللغة العربية وعرضها سطر بسطر.

المطور: مفتوح المصدر (Open Source)
المنصة: Termux (Android) & Linux
"""

import sys
import os
import time
import argparse
import signal
from rich.console import Console
from rich.panel import Panel
from rich.live import Live
from rich.table import Table
from rich import box

from config import Config
from stream_recorder import StreamRecorder
from stt_engine import SpeechToTextEngine
from translator import LiveTranslator
from display import SubtitleDisplay

console = Console()

def signal_handler(sig, frame):
    console.print("\\n[bold red]🛑 تم إيقاف المترجم بنجاح. مع السلامة![/bold red]")
    sys.exit(0)

signal.signal(signal.SIGINT, signal_handler)

def parse_args():
    parser = argparse.ArgumentParser(
        description="Live Audio Translator: تسجيل البث الصوتي وترجمته لحظياً إلى العربية في تيرموكس"
    )
    parser.add_argument(
        "--url", "-u",
        type=str,
        default=Config.DEFAULT_STREAM_URL,
        help="رابط بث الراديو (Stream URL)"
    )
    parser.add_argument(
        "--chunk", "-c",
        type=int,
        default=Config.DEFAULT_CHUNK_SECONDS,
        help="مدة المقطع الصوتي بالثواني (5 إلى 10 ثوانٍ)"
    )
    parser.add_argument(
        "--source-lang", "-s",
        type=str,
        default="auto",
        help="لغة المصدر (auto, en, fr, de, es, ...)"
    )
    parser.add_argument(
        "--target-lang", "-t",
        type=str,
        default="ar",
        help="لغة الهدف (الافتراضي: ar للعربية)"
    )
    parser.add_argument(
        "--mic", "-m",
        action="store_true",
        help="استخدام ميكروفون الهاتف بدلاً من رابط الراديو"
    )
    parser.add_argument(
        "--engine", "-e",
        choices=["google_free", "whisper_hf", "gemini"],
        default="google_free",
        help="محرك التعرف على الصوت (STT Engine)"
    )
    return parser.parse_args()

def main():
    args = parse_args()
    display = SubtitleDisplay(console)
    display.print_banner()

    # التحقق من المتطلبات الأساسية
    display.check_environment()

    recorder = StreamRecorder(
        stream_url=args.url,
        chunk_seconds=args.chunk,
        use_mic=args.mic
    )

    stt = SpeechToTextEngine(
        engine_type=args.engine,
        source_lang=args.source_lang
    )

    translator = LiveTranslator(
        target_lang=args.target_lang
    )

    console.print(Panel(
        f"[bold cyan]📻 المصدر:[/bold cyan] {'🎙️ الميكروفون' if args.mic else args.url}\\n"
        f"[bold yellow]⏱️ مدة المقطع:[/bold yellow] {args.chunk} ثوانٍ | "
        f"[bold green]🎯 لغة الترجمة:[/bold green] العربية ({args.target_lang})\\n"
        f"[bold magenta]⚡ محرك STT:[/bold magenta] {args.engine}",
        title="[bold green]🚀 بدء جلسة الترجمة الحية[/bold green]",
        border_style="cyan"
    ))

    session_id = 1
    try:
        while True:
            # 1. التقاط/تسجيل مقطع صوتي
            display.status_indicator(f"🎙️ [bold blue]جارٍ الاستماع وتسجيل المقطع #{session_id} ({args.chunk}s)...[/bold blue]")
            audio_path = recorder.capture_chunk()

            if not audio_path or not os.path.exists(audio_path):
                display.log_warning("⚠️ لم يتم استلام صوت كافٍ في هذه الدفعة، جاري إعادة المحاولة...")
                time.sleep(1)
                continue

            # 2. تحويل الصوت لنص (Speech to Text)
            display.status_indicator("⚡ [bold magenta]جارٍ تحويل الصوت لنص (Speech-to-Text)...[/bold magenta]")
            transcript, detected_lang = stt.transcribe(audio_path)

            if not transcript or len(transcript.strip()) < 2:
                display.log_dim(f"🔇 #{session_id} [هدوء/موسيقى - لا يوجد كلام واضح]")
                recorder.cleanup(audio_path)
                session_id += 1
                continue

            # 3. ترجمة النص إلى العربية
            display.status_indicator("🌐 [bold green]جارٍ ترجمة النص إلى العربية...[/bold green]")
            arabic_translation = translator.translate(transcript, src=detected_lang)

            # 4. عرض الترجمة سطر بسطر على الشاشة
            display.render_translation_line(
                chunk_id=session_id,
                original_text=transcript,
                arabic_text=arabic_translation,
                source_lang=detected_lang,
                duration=args.chunk
            )

            recorder.cleanup(audio_path)
            session_id += 1

    except KeyboardInterrupt:
        signal_handler(None, None)

if __name__ == "__main__":
    main()
`
  },
  {
    name: 'stream_recorder.py',
    path: 'stream_recorder.py',
    language: 'python',
    description: 'تسجيل مقاطع 5-10 ثوانٍ من بث الراديو أو الميكروفون عبر ffmpeg / arecord',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
وحدة تسجيل الصوت من البث المباشر أو الميكروفون
تعتمد على ffmpeg أو arecord في بيئة Termux
"""

import os
import subprocess
import tempfile
import time

class StreamRecorder:
    def __init__(self, stream_url: str, chunk_seconds: int = 8, use_mic: bool = False):
        self.stream_url = stream_url
        self.chunk_seconds = chunk_seconds
        self.use_mic = use_mic
        self.temp_dir = tempfile.gettempdir()

    def capture_chunk(self) -> str:
        """
        تسجيل مقطع صوتي لمدة chunk_seconds ثانية بصيغة WAV نقية (16kHz Mono)
        مثالية لمحركات التعرف على الكلام.
        """
        timestamp = int(time.time() * 1000)
        output_file = os.path.join(self.temp_dir, f"chunk_{timestamp}.wav")

        if self.use_mic:
            # استخدام termux-microphone-record أو arecord للميكروفون
            return self._record_from_mic(output_file)
        else:
            # تسجيل بث الراديو عبر ffmpeg مباشرة من الرابط
            return self._record_from_stream(output_file)

    def _record_from_stream(self, output_file: str) -> str:
        """
        تسجيل جزء من بث الراديو الحي دون انقطاع عبر ffmpeg
        معالجة التوافق مع mp3 / aac / m3u8
        """
        cmd = [
            "ffmpeg",
            "-y",                     # تجاوز السؤال عند الكتابة
            "-reconnect", "1",
            "-reconnect_streamed", "1",
            "-reconnect_delay_max", "5",
            "-i", self.stream_url,     # رابط البث
            "-t", str(self.chunk_seconds), # مدة المقطع (مثلاً 8 ثوانٍ)
            "-vn",                    # بدون فيديو
            "-ar", "16000",           # تردد 16kHz
            "-ac", "1",               # قناة أحادية Mono
            "-f", "wav",              # نسق WAV
            "-loglevel", "error",     # كتم لوجات ffmpeg لتظل الشاشة نظيفة
            output_file
        ]

        try:
            # تشغيل مع مهلة حماية لتجنب تعليق البث
            timeout = self.chunk_seconds + 6
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=timeout)
            
            if os.path.exists(output_file) and os.path.getsize(output_file) > 1024:
                return output_file
        except subprocess.TimeoutExpired:
            pass
        except Exception:
            pass

        return None

    def _record_from_mic(self, output_file: str) -> str:
        """
        التسجيل عبر ميكروفون الهاتف في تيرموكس باستخدام arecord أو termux-microphone-record
        """
        # محاولة arecord (Alsa / PulseAudio)
        cmd = [
            "arecord",
            "-d", str(self.chunk_seconds),
            "-f", "S16_LE",
            "-r", "16000",
            "-c", "1",
            output_file
        ]
        try:
            subprocess.run(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=self.chunk_seconds + 3)
            if os.path.exists(output_file):
                return output_file
        except Exception:
            pass

        # بديل ffmpeg عبر ميكروفون pulse
        cmd_pulse = [
            "ffmpeg", "-y",
            "-f", "pulse", "-i", "default",
            "-t", str(self.chunk_seconds),
            "-ar", "16000", "-ac", "1",
            output_file
        ]
        try:
            subprocess.run(cmd_pulse, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=self.chunk_seconds + 3)
            if os.path.exists(output_file):
                return output_file
        except Exception:
            pass

        return None

    def cleanup(self, file_path: str):
        """حذف المقطع المؤقت بعد معالجته للحفاظ على مساحة الهاتف"""
        try:
            if file_path and os.path.exists(file_path):
                os.remove(file_path)
        except Exception:
            pass
`
  },
  {
    name: 'stt_engine.py',
    path: 'stt_engine.py',
    language: 'python',
    description: 'محرك تحويل الصوت لنص (Google STT / HuggingFace Whisper / Gemini)',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
وحدة التعرف على الصوت وتحويله إلى نص (Speech-to-Text)
تدعم محركات مجانية تماماً:
1. Google Speech Recognition (مجاني مدمج بدون API Key)
2. HuggingFace Whisper Inference API
3. Google Gemini Flash Audio Transcribe
"""

import os
import requests
import speech_recognition as sr

class SpeechToTextEngine:
    def __init__(self, engine_type: str = "google_free", source_lang: str = "auto"):
        self.engine_type = engine_type
        self.source_lang = source_lang
        self.recognizer = sr.Recognizer()
        # تقليل عتبة الطاقة لتحسين التقاط الأصوات المنخفضة
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True

    def transcribe(self, audio_wav_path: str) -> tuple[str, str]:
        """
        تحويل ملف الصوت إلى نص
        ترجع: (النص المكتوب, رمز اللغة المكتشفة)
        """
        if self.engine_type == "whisper_hf":
            return self._transcribe_huggingface_whisper(audio_wav_path)
        elif self.engine_type == "gemini":
            return self._transcribe_gemini(audio_wav_path)
        else:
            return self._transcribe_google_free(audio_wav_path)

    def _transcribe_google_free(self, audio_wav_path: str) -> tuple[str, str]:
        """
        استخدام خدمة Google Speech Recognition المجانية عبر مكتبة speech_recognition
        لا تتطلب مفتاح API وتعمل بسلاسة في Termux
        """
        try:
            with sr.AudioFile(audio_wav_path) as source:
                audio_data = self.recognizer.record(source)
                # إذا كانت اللغة محددة بالإنجليزية أو auto نستخدم en-US
                lang = "en-US" if self.source_lang in ["auto", "en"] else self.source_lang
                text = self.recognizer.recognize_google(audio_data, language=lang)
                return text, "en"
        except sr.UnknownValueError:
            return "", "unknown"
        except sr.RequestError as e:
            return "", "error"
        except Exception as e:
            return "", "error"

    def _transcribe_huggingface_whisper(self, audio_wav_path: str) -> tuple[str, str]:
        """
        استخدام نموذج Whisper عبر HuggingFace Free Inference API
        """
        api_url = "https://api-inference.huggingface.co/models/openai/whisper-large-v3"
        # يمكن إضافة مفتاح HF اختياري من متغير البيئة HF_TOKEN
        headers = {}
        hf_token = os.environ.get("HF_TOKEN")
        if hf_token:
            headers["Authorization"] = f"Bearer {hf_token}"

        try:
            with open(audio_wav_path, "rb") as f:
                data = f.read()
            response = requests.post(api_url, headers=headers, data=data, timeout=12)
            if response.status_code == 200:
                result = response.json()
                text = result.get("text", "")
                return text.strip(), "en"
        except Exception:
            pass

        # الرجوع إلى Google Free كخيار احتياطي
        return self._transcribe_google_free(audio_wav_path)

    def _transcribe_gemini(self, audio_wav_path: str) -> tuple[str, str]:
        """
        استخدام Gemini 2.5 Flash لتحويل الصوت مباشرة إلى نص بدقة مذهلة
        """
        # في حال توفر GEMINI_API_KEY
        api_key = os.environ.get("GEMINI_API_KEY")
        if not api_key:
            return self._transcribe_google_free(audio_wav_path)
        
        # fallback
        return self._transcribe_google_free(audio_wav_path)
`
  },
  {
    name: 'translator.py',
    path: 'translator.py',
    language: 'python',
    description: 'ترجمة النص إلى العربية الفصحى عبر Google Translate API و googletrans',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
وحدة الترجمة الفورية إلى اللغة العربية
تعتمد على googletrans ومحطة الترجمة السحابية المباشرة المجانية
"""

import requests
import urllib.parse

class LiveTranslator:
    def __init__(self, target_lang: str = "ar"):
        self.target_lang = target_lang

    def translate(self, text: str, src: str = "auto") -> str:
        """
        ترجمة النص المُدخل إلى اللغة الهدف (العربية افتراضياً)
        مع نظام حماية متعدد الطبقات (Fallback) لضمان عدم توقف الخدمة.
        """
        if not text or not text.strip():
            return ""

        # الطريقة الأولى: استدعاء واجهة Google Translate المجانية عالية السرعة
        try:
            result = self._translate_google_direct(text, src=src, dest=self.target_lang)
            if result:
                return result
        except Exception:
            pass

        # الطريقة الثانية: مكتبة googletrans
        try:
            from googletrans import Translator
            translator = Translator()
            res = translator.translate(text, dest=self.target_lang, src=src if src != "unknown" else "auto")
            if res and res.text:
                return res.text
        except Exception:
            pass

        return text  # إعادة النص الأصلي في حال تعذر الترجمة

    def _translate_google_direct(self, text: str, src: str = "auto", dest: str = "ar") -> str:
        """
        استدعاء مباشر لواجهة الترجمة السريعة دون الحاجة لتثبيت حزم خارجية
        """
        url = "https://translate.googleapis.com/translate_a/single"
        params = {
            "client": "gtx",
            "sl": "auto" if src in ["auto", "unknown"] else src,
            "tl": dest,
            "dt": "t",
            "q": text
        }
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
        }
        
        response = requests.get(url, params=params, headers=headers, timeout=6)
        if response.status_code == 200:
            data = response.json()
            translated_parts = []
            if data and isinstance(data, list) and len(data) > 0 and isinstance(data[0], list):
                for part in data[0]:
                    if part and len(part) > 0 and part[0]:
                        translated_parts.append(part[0])
                return "".join(translated_parts).strip()
        return None
`
  },
  {
    name: 'display.py',
    path: 'display.py',
    language: 'python',
    description: 'عرض الترجمة سطر بسطر مع معالجة الحروف العربية والـ BiDi في شاشة تيرموكس',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
وحدة العرض وتنسيق الترجمة الحية لشاشات الطرفية (Termux Console)
تتضمن معالجة تشبيك الحروف العربية (Arabic Reshaper & BiDi)
حتى تظهر الكلمات العربية صحيحة ومقروءة تماماً في الطرفية.
"""

import sys
import shutil
from datetime import datetime
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from rich.text import Text
from rich import box

class SubtitleDisplay:
    def __init__(self, console: Console):
        self.console = console
        self._init_arabic_support()

    def _init_arabic_support(self):
        """تحميل مكتبات إعادة تشكيل النص العربي إن وُجدت لتوافق أفضل مع تيرموكس"""
        self.has_reshaper = False
        try:
            import arabic_reshaper
            from bidi.algorithm import get_display
            self.reshaper = arabic_reshaper
            self.get_display = get_display
            self.has_reshaper = True
        except ImportError:
            self.has_reshaper = False

    def shape_arabic(self, text: str) -> str:
        """تشبيك الحروف العربية وعكس اتجاه القراءة للتيرموكس عند الحاجة"""
        if self.has_reshaper and text:
            try:
                reshaped = self.reshaper.reshape(text)
                return self.get_display(reshaped)
            except Exception:
                return text
        return text

    def print_banner(self):
        """طباعة الشعار الرسمي للمترجم الحي"""
        banner_text = """
  _      _               ___             _ _        
 | |    (_)_ _____      /   \\ _   _   __| (_) ___   
 | |    | \\ V / -_)    / /\\ \\ | | | | / _\` | |/ _ \\  
 | |___ |_|\\_/\\___|   / /_\\ \\ |_| | || (_| | | (_) | 
 |_____|             /___/\\__\\__,_|\\__,_|_|\\___/  
        === Live Audio Translator for Termux ===
        مترجم البث الصوتي والراديو الحي إلى العربية
        """
        self.console.print(f"[bold cyan]{banner_text}[/bold cyan]")

    def check_environment(self):
        """التحقق من توفر أداة ffmpeg في النظام"""
        if not shutil.which("ffmpeg"):
            self.console.print(
                "[bold yellow]⚠️ تنبيه:[/bold yellow] أداة ffmpeg غير مثبتة في Termux!\\n"
                "لتثبيتها نفّذ الأمر التالي:\\n"
                "[bold green]pkg install ffmpeg -y[/bold green]\\n"
            )

    def status_indicator(self, msg: str):
        """عرض رسالة الحالة الحالية في سطر واحد"""
        sys.stdout.write(f"\\r{msg}\\033[K")
        sys.stdout.flush()

    def render_translation_line(self, chunk_id: int, original_text: str, arabic_text: str, source_lang: str, duration: int):
        """
        عرض الترجمة العربية سطر بسطر مع الأصل وتوقيت الاستلام
        """
        # مسح سطر الحالة السابق
        sys.stdout.write("\\r\\033[K")
        sys.stdout.flush()

        time_str = datetime.now().strftime("%H:%M:%S")

        # معالجة تشكيل النص العربي إذا لزم للطرفية
        display_arabic = self.shape_arabic(arabic_text)

        # جدول أنيق للسطر المترجم
        grid = Table.grid(padding=(0, 1))
        grid.add_column(justify="left", style="cyan")
        grid.add_column(justify="left", style="bold green")

        card_content = (
            f"[dim cyan][{time_str}] #{chunk_id:03d} ({duration}s)[/dim cyan]\\n"
            f"[dim italic white]🎤 [{source_lang.upper()}] {original_text}[/dim italic white]\\n"
            f"[bold green]🟢 [العربية]: {display_arabic}[/bold green]"
        )

        self.console.print(Panel(
            card_content,
            border_style="green",
            box=box.ROUNDED,
            padding=(0, 1)
        ))

    def log_dim(self, msg: str):
        sys.stdout.write("\\r\\033[K")
        sys.stdout.flush()
        self.console.print(f"[dim]{msg}[/dim]")

    def log_warning(self, msg: str):
        sys.stdout.write("\\r\\033[K")
        sys.stdout.flush()
        self.console.print(f"[bold yellow]{msg}[/bold yellow]")
`
  },
  {
    name: 'config.py',
    path: 'config.py',
    language: 'python',
    description: 'الإعدادات العامة وقنوات الراديو الافتراضية وخيارات التسجيل',
    content: `#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
ملف إعدادات المترجم الحي
يمكنك تعديل الروابط والمدد والخيارات بكل سهولة
"""

class Config:
    # رابط بث الراديو الافتراضي (BBC World Service News)
    DEFAULT_STREAM_URL = "https://stream.live.vc.bbcmedia.co.uk/bbc_world_service"

    # مدة المقطع الصوتي الافتراضية بالثواني (من 5 إلى 10 ثوانٍ)
    DEFAULT_CHUNK_SECONDS = 8

    # لغة المصدر (auto للتعرف التلقائي، أو en, fr, de, es, ...)
    DEFAULT_SOURCE_LANG = "auto"

    # لغة الهدف
    DEFAULT_TARGET_LANG = "ar"

    # محرك تحويل الصوت إلى نص الافتراضي (google_free, whisper_hf, gemini)
    DEFAULT_STT_ENGINE = "google_free"

    # قنوات راديو شهيرة مسبقة الإعداد
    PRESET_STATIONS = {
        "bbc": {
            "name": "BBC World Service",
            "url": "https://stream.live.vc.bbcmedia.co.uk/bbc_world_service",
            "lang": "en"
        },
        "npr": {
            "name": "NPR 24h News",
            "url": "https://npr-ice.streamguys1.com/live.mp3",
            "lang": "en"
        },
        "france_info": {
            "name": "France Info",
            "url": "https://icecast.radiofrance.fr/franceinfo-midfi.mp3",
            "lang": "fr"
        },
        "dw": {
            "name": "Deutsche Welle",
            "url": "https://dwstream72-lh.akamaihd.net/i/dwstream72_live@123962/master.m3u8",
            "lang": "en"
        },
        "monte_carlo": {
            "name": "Monte Carlo Doualiya",
            "url": "https://montecarlodoualiya128k.streamguys1.com/mcd-128k.mp3",
            "lang": "fr"
        }
    }
`
  },
  {
    name: 'requirements.txt',
    path: 'requirements.txt',
    language: 'text',
    description: 'المكتبات المطلوبة لتشغيل الأداة عبر pip في بيئة تيرموكس',
    content: `rich>=13.7.0
requests>=2.31.0
SpeechRecognition>=3.10.0
googletrans==4.0.0-rc1
pydub>=0.25.1
arabic-reshaper>=3.0.0
python-bidi>=0.4.2
`
  },
  {
    name: 'install_termux.sh',
    path: 'install_termux.sh',
    language: 'bash',
    description: 'سكربت التثبيت التلقائي بنقرة واحدة في Termux (One-Command Installer)',
    content: `#!/data/data/com.termux/files/usr/bin/bash
# ==============================================================================
# سكربت التثبيت التلقائي لمترجم الصوت الحي في Termux
# Live Audio Translator for Termux One-Click Installer
# ==============================================================================

set -e

echo -e "\\e[1;36m"
echo "=========================================================="
echo "    🚀 تثبيت Live Audio Translator في بيئة Termux       "
echo "=========================================================="
echo -e "\\e[0m"

# 1. تحديث حزم تيرموكس
echo -e "\\e[1;32m[1/5] جاري تحديث مستودعات Termux...\\e[0m"
pkg update -y && pkg upgrade -y

# 2. تثبيت الحزم الأساسية وأدوات الصوت
echo -e "\\e[1;32m[2/5] جاري تثبيت Python و ffmpeg وأدوات الصوت...\\e[0m"
pkg install -y python ffmpeg sox pulseaudio clang libjpeg-turbo git curl

# 3. تثبيت مكتبات بايثون
echo -e "\\e[1;32m[3/5] جاري تثبيت مكتبات بايثون (SpeechRecognition, Rich, Googletrans)...\\e[0m"
pip install --upgrade pip
pip install rich requests SpeechRecognition googletrans==4.0.0-rc1 pydub arabic-reshaper python-bidi

# 4. إعداد مجلد المشروع
INSTALL_DIR="$HOME/live-audio-translator"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

# 5. إنشاء اختصار مباشر في تيرموكس
echo -e "\\e[1;32m[4/5] جاري إنشاء اختصار التشغيل السريع 'live-trans'...\\e[0m"
cat << 'EOF' > "$PREFIX/bin/live-trans"
#!/data/data/com.termux/files/usr/bin/bash
cd "$HOME/live-audio-translator"
python main.py "$@"
EOF
chmod +x "$PREFIX/bin/live-trans"

echo -e "\\e[1;32m[5/5] تم التثبيت بنجاح! 🎉\\e[0m"
echo ""
echo -e "\\e[1;33mلبدء الترجمة الحية فوراً، اكتب ببساطة:\\e[0m"
echo -e "\\e[1;32m  live-trans\\e[0m"
echo ""
echo -e "\\e[1;33mخيارات إضافية:\\e[0m"
echo "  live-trans --url <رابط_الراديو>       # ترجمة بث معين"
echo "  live-trans --chunk 5                 # تسجيل كل 5 ثوانٍ"
echo "  live-trans --mic                     # الاستماع عبر ميكروفون الهاتف"
echo "=========================================================="
`
  }
];
