import React from 'react';
import { Radio, Terminal, Code2, Download, Smartphone, Volume2, Sparkles } from 'lucide-react';

export type ActiveTab = 'studio' | 'termux-code' | 'simulator' | 'apk';

interface AppHeaderProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  isStreaming: boolean;
  onOpenApkModal: () => void;
}

export const AppHeader: React.FC<AppHeaderProps> = ({
  activeTab,
  onTabChange,
  isStreaming,
  onOpenApkModal
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-xl border-b border-emerald-500/20 shadow-2xl shadow-emerald-950/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Logo & Identity */}
          <div className="flex items-center gap-3.5">
            <div className="relative group cursor-pointer" onClick={() => onTabChange('studio')}>
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-500 via-teal-600 to-cyan-700 flex items-center justify-center shadow-lg shadow-emerald-500/30 group-hover:shadow-emerald-500/50 transition-all border border-emerald-300/30">
                <Radio className="w-6 h-6 text-white animate-pulse" />
              </div>
              {isStreaming && (
                <span className="absolute -top-1 -right-1 flex h-3.5 w-3.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-3.5 w-3.5 bg-emerald-500 border-2 border-slate-950"></span>
                </span>
              )}
            </div>

            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black tracking-tight text-white flex items-center gap-2">
                  <span className="bg-gradient-to-r from-emerald-400 via-teal-300 to-cyan-400 bg-clip-text text-transparent">
                    Live Audio Translator
                  </span>
                </h1>
                <span className="hidden sm:inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-xs font-semibold bg-emerald-500/15 text-emerald-400 border border-emerald-500/30">
                  <Sparkles className="w-3 h-3" /> Termux & APK
                </span>
              </div>
              <p className="text-xs text-slate-400 font-medium hidden sm:block">
                مترجم البث الصوتي والراديو الحي إلى نصوص عربية لحظية سطر بسطر
              </p>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="flex items-center gap-2 sm:gap-3">
            <button
              onClick={onOpenApkModal}
              className="flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-bold bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-slate-950 transition-all shadow-md shadow-emerald-500/20 active:scale-95"
            >
              <Smartphone className="w-4 h-4 text-slate-950" />
              <span className="hidden md:inline">تحميل APK المباشر</span>
              <span className="md:hidden">APK</span>
            </button>
          </div>
        </div>

        {/* Tab Navigation Navigation Bar */}
        <nav className="flex space-x-2 space-x-reverse overflow-x-auto pb-3 pt-1 scrollbar-none border-t border-slate-800/60">
          <button
            onClick={() => onTabChange('studio')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'studio'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>الاستوديو والمترجم المباشر</span>
            {isStreaming && (
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            )}
          </button>

          <button
            onClick={() => onTabChange('termux-code')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'termux-code'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>حزمة Termux البرمجية (Python)</span>
            <span className="px-1.5 py-0.2 rounded bg-slate-800 text-[10px] text-cyan-300">7 ملفات</span>
          </button>

          <button
            onClick={() => onTabChange('simulator')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Terminal className="w-4 h-4" />
            <span>محاكي طرفية Termux</span>
          </button>

          <button
            onClick={() => onTabChange('apk')}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all whitespace-nowrap ${
              activeTab === 'apk'
                ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>تثبيت APK وأندرويد</span>
            <span className="px-1.5 py-0.2 rounded bg-emerald-950/80 text-[10px] text-emerald-400 border border-emerald-500/30">APK جاهز</span>
          </button>
        </nav>
      </div>
    </header>
  );
};
