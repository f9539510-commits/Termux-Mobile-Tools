export type TemplateType = 'classic' | 'cyberpunk' | 'dashboard';

export interface PythonPackage {
  id: string;
  name: string;
  version?: string;
  category: 'ui' | 'network' | 'web' | 'system' | 'data' | 'security';
  descriptionAr: string;
  descriptionEn: string;
  command: string;
  isPopular?: boolean;
}

export interface MenuItemOption {
  id: string;
  labelAr: string;
  labelEn: string;
  actionCode: string;
}

export interface ToolConfig {
  toolName: string;
  toolSlug: string;
  author: string;
  version: string;
  description: string;
  template: TemplateType;
  bannerType: 'cyber' | 'hacker' | 'matrix' | 'shield' | 'fire' | 'custom';
  customBannerText?: string;
  selectedPackages: string[];
  menuItems: MenuItemOption[];
}

export interface GitHubConfig {
  username: string;
  token: string;
  email?: string;
  defaultRepo?: string;
  isConnected: boolean;
  avatarUrl?: string;
  name?: string;
  lastTested?: number;
}

export interface AppSettings {
  defaultAuthor: string;
  termuxHomeDir: string;
  autoSaveToDownloads: boolean;
  themeMode: 'cyber-dark' | 'matrix-green' | 'neon-purple';
  github: GitHubConfig;
}

export interface AndroidProjectFile {
  path: string;
  content: string;
  description: string;
}
