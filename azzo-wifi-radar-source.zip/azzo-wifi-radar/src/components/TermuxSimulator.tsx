import React, { useState, useEffect, useRef } from 'react';
import { Terminal, Play, Square, RefreshCw, Sparkles, Send, HelpCircle } from 'lucide-react';
import { translateToArabic } from '../utils/liveTranslatorEngine';

interface TerminalLine {
  id: string;
  type: 'system' | 'prompt' | 'info' | 'speech' | 'translation' | 'warning' | 'error';
  text: string;
  timestamp?: string;
  rawHtml?: boolean;
}

export const TermuxSimulator: React.FC = () => {
  const [isRunning, setIsRunning] = useState<boolean>(false);
  const [inputCommand, setInputCommand] = useState<string>('');
  const [lines, setLines] = useState<TerminalLine[]>([
    {
      id: 'init-1',
      type: 'system',
      text: 'Termux (v0.118.1) - aarch64 Android Linux terminal'
    },
    {
      id: 'init-2',
      type: 'system',
      text: 'Type "live-trans" or "python main.py" to start live audio translator.'
    }
  ]);

  const terminalEndRef = useRef<HTMLDivElement | null>(null);
  const loopTimerRef = useRef<any>(null);
  const chunkCountRef = useRef<number>(1);

  useEffect(() => {
    terminalEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [lines]);

  const simulatedSentences = [
    { en: "World health organization releases new guidelines on daily physical activity and clean air.", ar: "منظمة الصحة العالمية تصدر إرشادات جديدة بشأن النشاط البدني اليومي والهواء النظيف." },
    { en: "Renewable energy investments reach an unprecedented historic milestone across global markets.", ar: "استثمارات الطاقة المتجددة تسجل إنجازاً تاريخياً غير مسبوق في الأسواق العالمية." },
    { en: "Space agency confirms successful deployment of the new atmospheric research satellite.", ar: "وكالة الفضاء تؤكد نجاح نشر القمر الاصطناعي الجديد المخصص لأبحاث الغلاف الجوي." },
    { en: "International tech summit showcases latest generation of real-time voice translation chips.", ar: "القمة التقنية الدولية تستعرض أحدث جيل من رقائق الترجمة الصوتية الفورية." },
    { en: "Global trade forum discusses economic cooperation and modern maritime logistics routes.", ar: "المنتدى التجاري العالمي يناقش التعاون الاقتصادي ومسارات الخدمات اللوجستية البحرية الحديثة." }
  ];

  const startSimulatorSession = () => {
    setIsRunning(true);
    chunkCountRef.current = 1;

    setLines(prev => [
      ...prev,
      { id: `cmd-${Date.now()}`, type: 'prompt', text: '$ live-trans --chunk 8 --engine google_free' },
      { id: `b-1`, type: 'info', text: '   _      _               ___             _ _        ' },
      { id: `b-2`, type: 'info', text: '  | |    (_)_ _____      /   \\ _   _   __| (_) ___   ' },
      { id: `b-3`, type: 'info', text: '  | |    | \\ V / -_)    / /\\ \\ | | | | / _` | |/ _ \\  ' },
      { id: `b-4`, type: 'info', text: '  | |___ |_|\\_/\\___|   / /_\\ \\ |_| | || (_| | | (_) | ' },
      { id: `b-5`, type: 'info', text: '  |_____|             /___/\\__\\__,_|\\__,_|_|\\___/  ' },
      { id: `b-6`, type: 'info', text: '  === Live Audio Translator for Termux ===' },
      { id: `b-7`, type: 'info', text: '  [✓] ffmpeg audio pipeline verified (16000 Hz Mono)' },
      { id: `b-8`, type: 'info', text: '  [✓] Radio Stream: BBC World Service (128 kbps)' },
      { id: `b-9`, type: 'info', text: '  [✓] STT Engine: Google Speech Recognition (Free)' },
      { id: `b-10`, type: 'info', text: '  ---------------------------------------------------------' }
    ]);

    runNextChunk();
  };

  const runNextChunk = () => {
    const chunkNum = chunkCountRef.current;
    const timeStr = new Date().toTimeString().split(' ')[0];

    // خطوة 1: التسجيل
    setLines(prev => [
      ...prev,
      {
        id: `rec-${Date.now()}`,
        type: 'system',
        text: `[${timeStr}] 🎙️ جارٍ الاستماع وتسجيل المقطع #${chunkNum.toString().padStart(3, '0')} (8 ثوانٍ عبر ffmpeg)...`
      }
    ]);

    // خطوة 2: التحويل لنص والترجمة
    loopTimerRef.current = setTimeout(() => {
      const sample = simulatedSentences[(chunkNum - 1) % simulatedSentences.length];

      setLines(prev => [
        ...prev,
        {
          id: `stt-${Date.now()}`,
          type: 'speech',
          text: `[${timeStr}] 🎤 [EN]: "${sample.en}"`
        },
        {
          id: `trans-${Date.now()}`,
          type: 'translation',
          text: `[${timeStr}] 🟢 [العربية]: ${sample.ar}`
        }
      ]);

      chunkCountRef.current += 1;

      // جدولة المقطع التالي إذا كان لا يزال قيد التشغيل
      loopTimerRef.current = setTimeout(() => {
        runNextChunk();
      }, 3500);

    }, 3000);
  };

  const stopSimulatorSession = () => {
    setIsRunning(false);
    if (loopTimerRef.current) {
      clearTimeout(loopTimerRef.current);
      loopTimerRef.current = null;
    }
    setLines(prev => [
      ...prev,
      {
        id: `stop-${Date.now()}`,
        type: 'warning',
        text: '^C\n🛑 تم إيقاف المترجم بنجاح (Process terminated by user).'
      }
    ]);
  };

  const handleCommandSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputCommand.trim()) return;

    const cmd = inputCommand.trim();
    setInputCommand('');

    setLines(prev => [...prev, { id: `user-${Date.now()}`, type: 'prompt', text: `$ ${cmd}` }]);

    if (cmd === 'clear') {
      setLines([]);
      return;
    }

    if (cmd === 'help') {
      setLines(prev => [
        ...prev,
        {
          id: `help-${Date.now()}`,
          type: 'info',
          text: 'Available Commands:\n - live-trans : Start translator\n - python main.py --chunk 5 : Run with 5s chunk\n - clear : Clear terminal screen\n - help : Show this help message'
        }
      ]);
      return;
    }

    if (cmd.startsWith('python main.py') || cmd === 'live-trans') {
      startSimulatorSession();
      return;
    }

    setLines(prev => [
      ...prev,
      {
        id: `err-${Date.now()}`,
        type: 'error',
        text: `bash: ${cmd}: command not found. Try "live-trans" or "help".`
      }
    ]);
  };

  useEffect(() => {
    return () => {
      if (loopTimerRef.current) clearTimeout(loopTimerRef.current);
    };
  }, []);

  return (
    <div className="space-y-6">
      
      {/* Intro Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 bg-slate-900/90 border border-slate-800 p-5 rounded-2xl">
        <div>
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <Terminal className="w-5 h-5 text-emerald-400" />
            <span>محاكي طرفية تيرموكس (Termux Interactive Shell)</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1">
            جرّب سلوك كود بايثون والشاشة الحية سطر بسطر كما تعمل بالضبط على هاتف أندرويد
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          {isRunning ? (
            <button
              onClick={stopSimulatorSession}
              className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-red-600 hover:bg-red-500 text-white transition-all active:scale-95 shadow-md shadow-red-600/30"
            >
              <Square className="w-4 h-4 fill-current" />
              <span>إيقاف التشغيل (Ctrl+C)</span>
            </button>
          ) : (
            <button
              onClick={startSimulatorSession}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl text-xs sm:text-sm font-bold bg-emerald-500 hover:bg-emerald-400 text-slate-950 transition-all active:scale-95 shadow-md shadow-emerald-500/30"
            >
              <Play className="w-4 h-4 fill-current text-slate-950" />
              <span>تشغيل live-trans تجريبياً</span>
            </button>
          )}

          <button
            onClick={() => setLines([])}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
            title="مسح الطرفية"
          >
            <RefreshCw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Terminal Screen Container */}
      <div className="bg-[#050811] border-2 border-emerald-500/30 rounded-2xl shadow-2xl overflow-hidden font-mono flex flex-col h-[520px]">
        
        {/* Terminal Header Window Controls */}
        <div className="bg-slate-900/90 px-4 py-2.5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-amber-500/80 inline-block"></span>
            <span className="w-3 h-3 rounded-full bg-emerald-500/80 inline-block"></span>
            <span className="text-xs text-slate-400 font-bold ml-2">termux@android:~ (live-audio-translator)</span>
          </div>
          <span className="text-[11px] text-emerald-400 font-bold">Python 3.11.8 • Rich CLI</span>
        </div>

        {/* Terminal Output Body */}
        <div className="flex-1 p-4 overflow-y-auto space-y-2 text-xs sm:text-sm leading-relaxed scrollbar-thin scrollbar-thumb-slate-800">
          {lines.map((line) => {
            switch (line.type) {
              case 'prompt':
                return (
                  <div key={line.id} className="text-cyan-400 font-bold" dir="ltr">
                    {line.text}
                  </div>
                );
              case 'info':
                return (
                  <div key={line.id} className="text-cyan-300 whitespace-pre" dir="ltr">
                    {line.text}
                  </div>
                );
              case 'speech':
                return (
                  <div key={line.id} className="text-slate-400 italic bg-slate-900/40 p-2 rounded-lg border border-slate-800" dir="ltr">
                    {line.text}
                  </div>
                );
              case 'translation':
                return (
                  <div key={line.id} className="text-emerald-300 font-bold bg-emerald-950/40 p-2 rounded-lg border border-emerald-500/40 shadow-sm">
                    {line.text}
                  </div>
                );
              case 'warning':
                return (
                  <div key={line.id} className="text-amber-400 font-medium">
                    {line.text}
                  </div>
                );
              case 'error':
                return (
                  <div key={line.id} className="text-red-400">
                    {line.text}
                  </div>
                );
              default:
                return (
                  <div key={line.id} className="text-slate-400">
                    {line.text}
                  </div>
                );
            }
          })}
          <div ref={terminalEndRef} />
        </div>

        {/* Command Input Bar */}
        <form onSubmit={handleCommandSubmit} className="bg-slate-900/90 border-t border-slate-800 p-2.5 flex items-center gap-2">
          <span className="text-emerald-400 font-bold pl-2 text-sm" dir="ltr">$</span>
          <input
            type="text"
            value={inputCommand}
            onChange={(e) => setInputCommand(e.target.value)}
            placeholder="اكتب أمراً هنا (مثال: live-trans أو help أو clear)..."
            className="flex-1 bg-transparent border-none text-slate-100 placeholder-slate-600 focus:outline-none text-xs sm:text-sm font-mono"
            dir="ltr"
          />
          <button
            type="submit"
            className="px-3 py-1.5 rounded-lg bg-emerald-500 text-slate-950 font-bold text-xs hover:bg-emerald-400 transition-all flex items-center gap-1"
          >
            <Send className="w-3 h-3" />
            <span>تنفيذ</span>
          </button>
        </form>
      </div>
    </div>
  );
};
