import React from 'react';
import { StudioTab } from './StudioHeader';
import { ToolConfig, GitHubConfig } from '../types/termuxStudio';
import { 
  Sparkles, 
  Layers, 
  Package, 
  Terminal, 
  GitBranch, 
  Smartphone, 
  Settings, 
  ArrowRight, 
  CheckCircle2, 
  Cpu, 
  HardDrive,
  Play,
  UploadCloud,
  FileCode2
} from 'lucide-react';

interface HomeDashboardViewProps {
  onNavigateTab: (tab: StudioTab) => void;
  toolConfig: ToolConfig;
  gitConfig: GitHubConfig;
  onOpenStorageModal: () => void;
  onOpenGitHubModal: () => void;
  onOpenSettingsModal: () => void;
}

export const HomeDashboardView: React.FC<HomeDashboardViewProps> = ({
  onNavigateTab,
  toolConfig,
  gitConfig,
  onOpenStorageModal,
  onOpenGitHubModal,
  onOpenSettingsModal
}) => {
  return (
    <div className="space-y-6 sm:space-y-8 animate-in fade-in duration-300">
      
      {/* Hero Welcome Card */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900/90 via-[#030712] to-slate-950 border border-emerald-500/30 p-6 sm:p-8 shadow-2xl">
        <div className="absolute top-0 right-0 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-80 h-80 bg-cyan-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>

        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-2.5 text-right">
            
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              <span>مرحباً بك في بيئة تطوير Termux المتكاملة</span>
            </div>

            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-extrabold text-slate-100 tracking-tight">
              KALBASO Termux Studio
            </h1>

            <p className="text-xs sm:text-sm text-slate-400 max-w-2xl leading-relaxed">
              طور أدوات تيرمكس باحترافية، بدون تعقيد، مع قوالب بايثون جاهزة، ومدير مكتبات ذكي، وربط تلقائي مع تيرمكس ورفع مباشر إلى GitHub.
            </p>

            <div className="flex items-center gap-2 text-xs pt-1 font-mono text-slate-300 font-semibold">
              <span className="text-slate-400">مطور التطبيق:</span>
              <span className="text-emerald-400 font-bold">كالبسو مطروح (Calypsu)</span>
              <span className="text-base">🇪🇬</span>
              <span className="text-slate-600">|</span>
              <span className="text-cyan-400">Native Android • MIT License</span>
            </div>
          </div>

          {/* Quick Action Pill on Hero */}
          <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
            <button
              onClick={() => onNavigateTab('templates')}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all"
            >
              <Play className="w-4 h-4 fill-current" />
              <span>إنشاء أداة جديدة الآن</span>
            </button>

            <button
              onClick={onOpenGitHubModal}
              className="flex-1 md:flex-initial flex items-center justify-center gap-2 px-4 py-3 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-cyan-500/30 text-cyan-300 font-bold text-xs sm:text-sm transition-all"
            >
              <GitBranch className="w-4 h-4 text-cyan-400" />
              <span>{gitConfig.isConnected ? 'رفع إلى GitHub' : 'إعداد GitHub'}</span>
            </button>
          </div>
        </div>

        {/* Live Status Bar in Hero */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 mt-6 pt-5 border-t border-slate-900 text-xs">
          
          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <div className="truncate">
              <span className="text-slate-500 block text-[10px]">حالة Termux:</span>
              <span className="font-semibold text-slate-200">جاهز للربط ✓</span>
            </div>
          </div>

          <div 
            onClick={onOpenGitHubModal}
            className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2 cursor-pointer hover:border-cyan-500/40 transition-colors"
          >
            <GitBranch className="w-4 h-4 text-cyan-400 shrink-0" />
            <div className="truncate">
              <span className="text-slate-500 block text-[10px]">حساب GitHub:</span>
              <span className={`font-semibold ${gitConfig.isConnected ? 'text-emerald-400' : 'text-slate-400'}`}>
                {gitConfig.isConnected ? `@${gitConfig.username}` : 'انقر للربط'}
              </span>
            </div>
          </div>

          <div className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-purple-400 shrink-0" />
            <div className="truncate">
              <span className="text-slate-500 block text-[10px]">الأداة الحالية:</span>
              <span className="font-semibold text-slate-200 font-mono">{toolConfig.toolName}</span>
            </div>
          </div>

          <div 
            onClick={onOpenStorageModal}
            className="p-2.5 rounded-xl bg-slate-950/60 border border-slate-800/80 flex items-center gap-2 cursor-pointer hover:border-emerald-500/40 transition-colors"
          >
            <HardDrive className="w-4 h-4 text-yellow-400 shrink-0" />
            <div className="truncate">
              <span className="text-slate-500 block text-[10px]">عداد المساحة:</span>
              <span className="font-semibold text-emerald-400 font-mono">35.6 GB حرة (فحص)</span>
            </div>
          </div>

        </div>
      </div>

      {/* Main Shortcuts Grid (بطاقات الاختصارات المنظمة) */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-slate-400 px-1">
          الاختصارات الرئيسية السريعة (Quick Shortcuts):
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          
          {/* Card 1: Templates */}
          <div 
            onClick={() => onNavigateTab('templates')}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-emerald-500/50 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg hover:shadow-emerald-950/30"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Layers className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-300 border border-emerald-500/30 font-bold">
                  3 قوالب جاهزة
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-emerald-300 transition-colors">
                  قوالب واجهات الأدوات
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  اختر بين القالب الكلاسيكي، أو السايبربنك الملون، أو لوحة التحكم (Dashboard) مع تخصيص الاسم واللوجو.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-emerald-400">
              <span>بدء تخصيص الأداة</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

          {/* Card 2: Package Manager & Smart Search */}
          <div 
            onClick={() => onNavigateTab('packages')}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-cyan-500/50 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg hover:shadow-cyan-950/30"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Package className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-300 border border-cyan-500/30 font-bold">
                  PyPI Smart Search
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                  مدير مكتبات بايثون (pip)
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  ابحث بالعربي والإنجليزي في مستودع PyPI الرسمي وثبّت المكتبات بنقرة واحدة عبر Intent تيرمكس.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-cyan-400">
              <span>تصفح وتثبيت الحزم</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

          {/* Card 3: Code Studio & Terminal */}
          <div 
            onClick={() => onNavigateTab('generator')}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-purple-500/50 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg hover:shadow-purple-950/30"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Terminal className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-300 border border-purple-500/30 font-bold">
                  Interactive Terminal
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-purple-300 transition-colors">
                  مولد الكود ومحرر الطرفية
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  معاينة كود بايثون الحقيقي، تجربة الأداة حياً في طرفية تفاعلية، وتوليد أمر سطر واحد لتيرمكس.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-purple-400">
              <span>فتح الكود والمشغل</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

          {/* Card 4: GitHub Integration */}
          <div 
            onClick={onOpenGitHubModal}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-teal-500/50 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg hover:shadow-teal-950/30"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <GitBranch className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-teal-500/10 text-teal-300 border border-teal-500/30 font-bold">
                  Setup & Push
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-teal-300 transition-colors">
                  إعداد ورفع GitHub
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  اربط حساب GitHub عبر Personal Access Token وارفع ملفات أداتك مباشرة لمستودعك مع حماية 600.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-teal-400">
              <span>{gitConfig.isConnected ? 'رفع الأداة الآن' : 'إعداد الحساب والتوكن'}</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

          {/* Card 5: Termux Bridge & Intent */}
          <div 
            onClick={() => onNavigateTab('bridge')}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-yellow-500/50 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg hover:shadow-yellow-950/30"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Cpu className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-yellow-500/10 text-yellow-300 border border-yellow-500/30 font-bold">
                  RUN_COMMAND
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-yellow-300 transition-colors">
                  ربط تيرمكس و Intent
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  تفعيل استقبال الأوامر التلقائية في تيرمكس، فحص الصلاحيات، وإرسال أوامر اختبارية حقيقية.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-yellow-400">
              <span>فحص وإعداد الربط</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

          {/* Card 6: Settings Panel */}
          <div 
            onClick={onOpenSettingsModal}
            className="group relative cursor-pointer rounded-2xl bg-slate-950/70 border border-slate-800/80 hover:border-slate-600 hover:bg-slate-900/60 p-5 transition-all duration-200 flex flex-col justify-between space-y-4 shadow-lg"
          >
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="w-10 h-10 rounded-xl bg-slate-800 text-slate-300 border border-slate-700 flex items-center justify-center group-hover:scale-105 transition-transform">
                  <Settings className="w-5 h-5" />
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-400 border border-slate-700 font-bold">
                  لوحة التحكم
                </span>
              </div>

              <div>
                <h3 className="text-base font-bold text-slate-100 group-hover:text-slate-200 transition-colors">
                  لوحة التحكم والإعدادات
                </h3>
                <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                  تعديل اسم المطور الافتراضي، مسارات تيرمكس، فحص المساحة، ومسح الذاكرة المؤقتة بسهولة.
                </p>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t border-slate-900 text-xs font-bold text-slate-300">
              <span>فتح الإعدادات</span>
              <ArrowRight className="w-4 h-4 rtl:rotate-180 group-hover:translate-x-[-4px] transition-transform" />
            </div>
          </div>

        </div>
      </div>

    </div>
  );
};
