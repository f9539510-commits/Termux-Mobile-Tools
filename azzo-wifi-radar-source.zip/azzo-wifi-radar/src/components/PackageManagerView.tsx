import React, { useState } from 'react';
import { POPULAR_PACKAGES } from '../data/packagesList';
import { ToolConfig, PythonPackage } from '../types/termuxStudio';
import { generateRequirementsTxt } from '../data/codeTemplates';
import { downloadBlobAsFile } from '../utils/nativeZipPackager';
import { installPackageInTermux, runCommandInTermux } from '../utils/termuxBridge';
import { SmartPyPiSearch } from './SmartPyPiSearch';
import { 
  Package, 
  Download, 
  Terminal, 
  Copy, 
  Check, 
  Plus, 
  Search, 
  Sparkles, 
  ListFilter,
  CheckCircle2
} from 'lucide-react';

interface PackageManagerViewProps {
  config: ToolConfig;
  onChangeConfig: (newConfig: ToolConfig) => void;
}

export const PackageManagerView: React.FC<PackageManagerViewProps> = ({
  config,
  onChangeConfig
}) => {
  const [activeSubTab, setActiveSubTab] = useState<'smart-search' | 'popular'>('smart-search');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [customPackageName, setCustomPackageName] = useState('');
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'info'; text: string } | null>(null);

  const togglePackage = (pkgName: string) => {
    const isSelected = config.selectedPackages.includes(pkgName);
    const updated = isSelected
      ? config.selectedPackages.filter(p => p !== pkgName)
      : [...config.selectedPackages, pkgName];
    onChangeConfig({ ...config, selectedPackages: updated });
  };

  const handleSelectAll = () => {
    const allNames = POPULAR_PACKAGES.map(p => p.name);
    onChangeConfig({ ...config, selectedPackages: allNames });
  };

  const handleClearAll = () => {
    onChangeConfig({ ...config, selectedPackages: [] });
  };

  const handleAddCustomPackage = () => {
    const name = customPackageName.trim().toLowerCase();
    if (!name) return;
    if (!config.selectedPackages.includes(name)) {
      onChangeConfig({ ...config, selectedPackages: [...config.selectedPackages, name] });
    }
    setCustomPackageName('');
    showNotification(`تمت إضافة ${name} إلى قائمة التثبيت و requirements.txt`);
  };

  const showNotification = (text: string) => {
    setStatusMessage({ type: 'success', text });
    setTimeout(() => setStatusMessage(null), 3500);
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(label);
    showNotification(`تم نسخ أمر الطرفية: ${label}`);
    setTimeout(() => setCopiedCommand(null), 2500);
  };

  /**
   * Executes real Termux RunCommand intent / native bridge for installing packages
   */
  const triggerTermuxInstall = async (packageName: string) => {
    const res = await installPackageInTermux(packageName);
    showNotification(res.message);
  };

  const triggerBulkInstall = async () => {
    if (config.selectedPackages.length === 0) return;
    const pkgsStr = config.selectedPackages.join(' ');
    const bulkCommand = `pip install --upgrade ${pkgsStr}`;
    const res = await runCommandInTermux(bulkCommand);
    showNotification(res.message);
  };

  const handleDownloadRequirements = () => {
    const content = generateRequirementsTxt(config.selectedPackages);
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    downloadBlobAsFile(blob, 'requirements.txt');
    showNotification('تم تنزيل ملف requirements.txt بنجاح');
  };

  const filteredPackages = POPULAR_PACKAGES.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          p.descriptionAr.includes(searchTerm) ||
                          p.descriptionEn.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || p.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-950 to-[#030712] border border-cyan-500/30 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
        
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-2 text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 text-xs font-bold font-mono">
              <Package className="w-3.5 h-3.5" />
              <span>مدير مكتبات بايثون لتيرمكس (pip Package Manager)</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
              إدارة وبحث وتثبيت مكتبات بايثون في Termux
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
              ابحث عن أي مكتبة عبر الـ <strong className="text-cyan-300">PyPI JSON API</strong> باللغتين العربية والإنجليزية، وثبّتها عبر أمر الـ <strong className="text-emerald-400">Intent</strong> المباشر لتيرمكس، مع حفظ سجل البحث وتوليد <code className="text-yellow-400 font-mono">requirements.txt</code> تلقائياً.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <button
              onClick={handleDownloadRequirements}
              className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-slate-900 border border-cyan-500/40 text-cyan-300 hover:bg-cyan-500/10 text-xs font-bold transition-all"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل requirements.txt ({config.selectedPackages.length})</span>
            </button>

            <button
              onClick={triggerBulkInstall}
              disabled={config.selectedPackages.length === 0}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-xs sm:text-sm shadow-lg shadow-cyan-500/20 active:scale-95 transition-all disabled:opacity-40"
            >
              <Terminal className="w-4 h-4" />
              <span>تثبيت كل المحدد في Termux ({config.selectedPackages.length})</span>
            </button>
          </div>
        </div>

        {/* Live Notification Bar */}
        {statusMessage && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center justify-between animate-in fade-in">
            <div className="flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="font-semibold">{statusMessage.text}</span>
            </div>
          </div>
        )}
      </div>

      {/* Mode Switcher Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-800 pb-3">
        <button
          onClick={() => setActiveSubTab('smart-search')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'smart-search'
              ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-lg shadow-cyan-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>البحث الذكي في PyPI (Smart Search بالعربي والإنجليزي)</span>
        </button>

        <button
          onClick={() => setActiveSubTab('popular')}
          className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all ${
            activeSubTab === 'popular'
              ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 shadow-lg shadow-emerald-950/40'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
          }`}
        >
          <ListFilter className="w-4 h-4 text-emerald-400" />
          <span>قائمة المكتبات الشائعة والتصنيفات ({POPULAR_PACKAGES.length})</span>
        </button>
      </div>

      {/* SubTab 1: Smart PyPI Search Engine */}
      {activeSubTab === 'smart-search' && (
        <SmartPyPiSearch
          config={config}
          onChangeConfig={onChangeConfig}
        />
      )}

      {/* SubTab 2: Standard Popular Packages Checklist */}
      {activeSubTab === 'popular' && (
        <div className="space-y-6">
          {/* Control Bar: Search, Category Filter, Custom Package */}
          <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-4 sm:p-6 space-y-4">
            <div className="flex flex-col md:flex-row items-center justify-between gap-4">
              
              {/* Filter Search Box */}
              <div className="relative w-full md:w-80">
                <Search className="w-4 h-4 absolute right-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="فلترة القائمة (مثال: requests, rich)..."
                  className="w-full pr-10 pl-4 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 focus:outline-none focus:border-cyan-500 font-mono"
                />
              </div>

              {/* Categories */}
              <div className="flex items-center gap-2 overflow-x-auto w-full md:w-auto scrollbar-none text-xs">
                {[
                  { id: 'all', label: 'الكل' },
                  { id: 'ui', label: 'الواجهات والطرفية (UI)' },
                  { id: 'network', label: 'الشبكات والاتصال' },
                  { id: 'web', label: 'الويب والـ APIs' },
                  { id: 'system', label: 'النظام والموارد' },
                  { id: 'data', label: 'البيانات' }
                ].map(cat => (
                  <button
                    key={cat.id}
                    onClick={() => setSelectedCategory(cat.id)}
                    className={`px-3 py-1.5 rounded-lg whitespace-nowrap transition-all ${
                      selectedCategory === cat.id
                        ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 font-bold'
                        : 'bg-slate-950 border border-slate-800/80 text-slate-400 hover:text-slate-200'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>

              {/* Quick Select Actions */}
              <div className="flex items-center gap-2">
                <button
                  onClick={handleSelectAll}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-300 hover:text-emerald-400 text-xs font-semibold"
                >
                  تحديد الكل
                </button>
                <button
                  onClick={handleClearAll}
                  className="px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-400 hover:text-red-400 text-xs font-semibold"
                >
                  إلغاء التحديد
                </button>
              </div>
            </div>

            {/* Add Custom Package Bar */}
            <div className="pt-2 border-t border-slate-800 flex flex-col sm:flex-row items-center gap-3">
              <span className="text-xs text-slate-400 whitespace-nowrap">إضافة مكتبة بايثون مخصصة:</span>
              <div className="flex items-center gap-2 w-full sm:w-auto flex-1 max-w-md">
                <input
                  type="text"
                  value={customPackageName}
                  onChange={(e) => setCustomPackageName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && handleAddCustomPackage()}
                  placeholder="اسم المكتبة (مثال: fastapi أو numpy)..."
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-slate-100 font-mono focus:outline-none focus:border-cyan-500"
                />
                <button
                  onClick={handleAddCustomPackage}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 hover:bg-cyan-500/30 text-xs font-bold whitespace-nowrap"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>إضافة</span>
                </button>
              </div>
            </div>
          </div>

          {/* Packages Checklist Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredPackages.map((pkg) => {
              const isSelected = config.selectedPackages.includes(pkg.name);
              return (
                <div
                  key={pkg.id}
                  className={`rounded-2xl border p-4.5 transition-all flex flex-col justify-between ${
                    isSelected
                      ? 'bg-slate-900/90 border-cyan-500/60 ring-1 ring-cyan-500/30 shadow-lg shadow-cyan-950/40'
                      : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 hover:bg-slate-900/40'
                  }`}
                >
                  <div className="space-y-3">
                    
                    {/* Header: Checkbox + Name + Category badge */}
                    <div className="flex items-start justify-between gap-2">
                      <div
                        onClick={() => togglePackage(pkg.name)}
                        className="flex items-center gap-2.5 cursor-pointer flex-1"
                      >
                        <div className={`w-5 h-5 rounded-lg flex items-center justify-center transition-all ${
                          isSelected
                            ? 'bg-cyan-500 text-slate-950 font-bold'
                            : 'border border-slate-700 bg-slate-900 text-transparent'
                        }`}>
                          <Check className="w-3.5 h-3.5 stroke-[3]" />
                        </div>
                        <div>
                          <span className="font-mono font-bold text-sm text-slate-100 block">
                            {pkg.name}
                          </span>
                          <span className="text-[10px] text-slate-500 font-mono">
                            {pkg.command}
                          </span>
                        </div>
                      </div>

                      <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                        {pkg.category}
                      </span>
                    </div>

                    {/* Description in Arabic */}
                    <p className="text-xs text-slate-300 leading-relaxed text-right min-h-[36px]">
                      {pkg.descriptionAr}
                    </p>
                    <p className="text-[11px] text-slate-500 font-sans text-left dir-ltr truncate">
                      {pkg.descriptionEn}
                    </p>
                  </div>

                  {/* Action Buttons: 1-Click Termux Intent & Copy Pip Command */}
                  <div className="pt-3 mt-3 border-t border-slate-800/70 flex items-center gap-2">
                    <button
                      onClick={() => triggerTermuxInstall(pkg.name)}
                      className="flex-1 flex items-center justify-center gap-1.5 py-1.5 px-3 rounded-lg bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 hover:bg-emerald-500/30 text-[11px] font-bold transition-all active:scale-95"
                      title="إرسال أمر التثبيت عبر Intent لتيرمكس مباشرة"
                    >
                      <Terminal className="w-3.5 h-3.5 text-emerald-400" />
                      <span>تنزيل في تيرمكس (Intent)</span>
                    </button>

                    <button
                      onClick={() => copyToClipboard(pkg.command, pkg.name)}
                      className="p-1.5 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-cyan-400 hover:border-cyan-500/40 transition-colors"
                      title="نسخ أمر pip"
                    >
                      {copiedCommand === pkg.name ? (
                        <Check className="w-4 h-4 text-emerald-400" />
                      ) : (
                        <Copy className="w-4 h-4" />
                      )}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Selected Requirements Preview */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-200">
            <Package className="w-4 h-4 text-cyan-400" />
            <span>المكتبات المختارة المعتمدة في requirements.txt ({config.selectedPackages.length} مكتبة):</span>
          </div>
          <button
            onClick={() => copyToClipboard(generateRequirementsTxt(config.selectedPackages), 'requirements.txt')}
            className="flex items-center gap-1 text-xs text-cyan-400 hover:underline font-mono"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>نسخ المحتوى</span>
          </button>
        </div>

        <pre className="p-4 rounded-xl bg-slate-950 border border-slate-800 font-mono text-xs text-emerald-400 max-h-36 overflow-y-auto">
          {generateRequirementsTxt(config.selectedPackages)}
        </pre>
      </div>

    </div>
  );
};
