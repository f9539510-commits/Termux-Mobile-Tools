/**
 * KALBASO Termux Studio - Native Termux & Android Bridge
 * Developer: كالبسو مطروح (Calypsu) 🇪🇬
 * Handles real interaction with Termux application on Android devices.
 */

declare global {
  interface Window {
    AndroidTermuxBridge?: {
      installPackage: (packageName: string) => void;
      runCommand: (command: string) => void;
      openTermux: (command: string) => void;
      saveFileToDownloads: (fileName: string, content: string) => boolean;
      shareScript: (title: string, content: string) => void;
      showToast: (message: string) => void;
      isTermuxInstalled: () => boolean;
    };
  }
}

export interface TermuxExecutionResult {
  success: boolean;
  message: string;
  nativeTriggered: boolean;
  copiedToClipboard: boolean;
}

/**
 * Executes a Python pip install command for the specified package
 */
export async function installPackageInTermux(packageName: string): Promise<TermuxExecutionResult> {
  const cleanPkg = packageName.trim();
  const pipCommand = `pip install --upgrade ${cleanPkg}`;

  // 1. Copy command to clipboard automatically
  try {
    await navigator.clipboard.writeText(pipCommand);
  } catch {}

  // 2. If running inside the Android APK with Native Java Bridge
  if (typeof window !== 'undefined' && window.AndroidTermuxBridge) {
    try {
      if (typeof window.AndroidTermuxBridge.installPackage === 'function') {
        window.AndroidTermuxBridge.installPackage(cleanPkg);
        return {
          success: true,
          message: `تم إرسال أمر تثبيت ${cleanPkg} إلى تطبيق Termux ونسخ الأمر للحافظة`,
          nativeTriggered: true,
          copiedToClipboard: true
        };
      }
    } catch (e) {
      console.warn('Native bridge error:', e);
    }
  }

  // 3. Fallback: Android Intent targeting Termux app directly
  const intentUrl = `intent:#Intent;action=com.termux.RUN_COMMAND;component=com.termux/.app.RunCommandService;S.com.termux.RUN_COMMAND_PATH=/data/data/com.termux/files/usr/bin/pip;S.com.termux.RUN_COMMAND_ARGUMENTS=install,${cleanPkg};S.com.termux.RUN_COMMAND_WORKDIR=/data/data/com.termux/files/home;B.com.termux.RUN_COMMAND_BACKGROUND=false;end`;

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    try {
      window.location.href = intentUrl;
    } catch {}
  }

  return {
    success: true,
    message: `تم نسخ الأمر: "${pipCommand}" للحافظة وطلب فتح Termux`,
    nativeTriggered: false,
    copiedToClipboard: true
  };
}

/**
 * Runs any custom bash/python command directly in Termux
 */
export async function runCommandInTermux(command: string): Promise<TermuxExecutionResult> {
  const cleanCmd = command.trim();

  // 1. Copy to clipboard
  try {
    await navigator.clipboard.writeText(cleanCmd);
  } catch {}

  // 2. Native Bridge call
  if (typeof window !== 'undefined' && window.AndroidTermuxBridge) {
    try {
      if (typeof window.AndroidTermuxBridge.runCommand === 'function') {
        window.AndroidTermuxBridge.runCommand(cleanCmd);
        return {
          success: true,
          message: `تم تشغيل الأمر مباشرة في Termux!`,
          nativeTriggered: true,
          copiedToClipboard: true
        };
      }
    } catch (e) {
      console.warn('Native bridge error:', e);
    }
  }

  // 3. Fallback Intent
  const intentUrl = `intent:#Intent;action=com.termux.RUN_COMMAND;component=com.termux/.app.RunCommandService;S.com.termux.RUN_COMMAND_PATH=/data/data/com.termux/files/usr/bin/bash;S.com.termux.RUN_COMMAND_ARGUMENTS=-c,${encodeURIComponent(cleanCmd)};S.com.termux.RUN_COMMAND_WORKDIR=/data/data/com.termux/files/home;B.com.termux.RUN_COMMAND_BACKGROUND=false;end`;

  const isAndroid = typeof navigator !== 'undefined' && /Android/i.test(navigator.userAgent);
  if (isAndroid) {
    try {
      window.location.href = intentUrl;
    } catch {}
  }

  return {
    success: true,
    message: `تم نسخ الأمر للحافظة وفتح تيرمكس. الصق الأمر واضغط Enter!`,
    nativeTriggered: false,
    copiedToClipboard: true
  };
}

/**
 * Opens Termux application directly
 */
export function openTermuxApp(): void {
  if (typeof window !== 'undefined' && window.AndroidTermuxBridge) {
    try {
      if (typeof window.AndroidTermuxBridge.openTermux === 'function') {
        window.AndroidTermuxBridge.openTermux('');
        return;
      }
    } catch {}
  }

  // Intent to launch Termux main activity
  const launchIntent = `intent:#Intent;action=android.intent.action.MAIN;category=android.intent.category.LAUNCHER;component=com.termux/.app.TermuxActivity;end`;
  try {
    window.location.href = launchIntent;
  } catch {}
}

/**
 * Saves a Python script file directly to the device Downloads folder
 */
export function saveScriptToDevice(fileName: string, content: string): boolean {
  if (typeof window !== 'undefined' && window.AndroidTermuxBridge) {
    try {
      if (typeof window.AndroidTermuxBridge.saveFileToDownloads === 'function') {
        return window.AndroidTermuxBridge.saveFileToDownloads(fileName, content);
      }
    } catch {}
  }

  // Browser download fallback
  try {
    const blob = new Blob([content], { type: 'text/x-python;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    return true;
  } catch {
    return false;
  }
}
