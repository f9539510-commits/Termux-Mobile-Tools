import React, { useState, useRef, useEffect } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Radio,
  Mic,
  MicOff,
  Settings2,
  Globe,
  Activity,
  Layers,
  Sparkles,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
import { RadioStation, RADIO_STATIONS_CATALOG } from '../data/termuxFiles';
import { SubtitleItem, translateToArabic, getSpeechRecognitionConstructor } from '../utils/liveTranslatorEngine';

interface LiveRadioPlayerProps {
  onNewSubtitle: (item: SubtitleItem) => void;
  isStreaming: boolean;
  setIsStreaming: (val: boolean) => void;
}

export const LiveRadioPlayer: React.FC<LiveRadioPlayerProps> = ({
  onNewSubtitle,
  isStreaming,
  setIsStreaming
}) => {
  const [selectedStation, setSelectedStation] = useState<RadioStation>(RADIO_STATIONS_CATALOG[0]);
  const [customUrl, setCustomUrl] = useState<string>('');
  const [inputMode, setInputMode] = useState<'stream' | 'mic'>('stream');
  const [isPlayingAudio, setIsPlayingAudio] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.85);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [chunkDuration, setChunkDuration] = useState<number>(8); // 5 to 10 seconds
  const [sttEngine, setSttEngine] = useState<'webspeech' | 'google_free' | 'gemini'>('webspeech');
  const [currentStatus, setCurrentStatus] = useState<string>('جاهز للبدء');
  const [activeChunkIndex, setActiveChunkIndex] = useState<number>(0);
  const [audioError, setAudioError] = useState<string | null>(null);

  const audioRef = useRef<HTMLAudioElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const recognitionRef = useRef<any>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const chunkTimerRef = useRef<any>(null);
  const accumulatedSpeechRef = useRef<string>('');

  // Audio stream URL currently selected
  const activeStreamUrl = customUrl.trim() || selectedStation.streamUrl;

  // إعداد أو تحديث صوت الراديو
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // إعداد الـ Visualizer عبر Web Audio API
  const setupAudioVisualizer = () => {
    try {
      if (!audioContextRef.current) {
        const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
        audioContextRef.current = new AudioContextClass();
      }

      const ctx = audioContextRef.current;
      if (ctx.state === 'suspended') {
        ctx.resume();
      }

      if (!analyserRef.current) {
        const analyser = ctx.createAnalyser();
        analyser.fftSize = 128;
        analyserRef.current = analyser;

        if (audioRef.current && inputMode === 'stream') {
          try {
            const source = ctx.createMediaElementSource(audioRef.current);
            source.connect(analyser);
            analyser.connect(ctx.destination);
          } catch (e) {
            // المصدر قد يكون متصلاً مسبقاً
          }
        }
      }

      drawVisualizer();
    } catch (e) {
      console.warn('Audio Visualizer setup fallback:', e);
    }
  };

  const drawVisualizer = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const analyser = analyserRef.current;
    const bufferLength = analyser ? analyser.frequencyBinCount : 64;
    const dataArray = new Uint8Array(bufferLength);

    const render = () => {
      animationFrameRef.current = requestAnimationFrame(render);

      if (analyser && (isPlayingAudio || isStreaming)) {
        analyser.getByteFrequencyData(dataArray);
      } else {
        // تأثير حركي خافت عند التوقف
        for (let i = 0; i < bufferLength; i++) {
          dataArray[i] = Math.max(0, (dataArray[i] || 0) * 0.95);
        }
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      const barWidth = (canvas.width / bufferLength) * 1.8;
      let x = 0;

      for (let i = 0; i < bufferLength; i++) {
        const barHeight = (dataArray[i] / 255) * canvas.height * 0.85;

        // تدرج ألوان عصري بين الزمردي والسيان والتركواز
        const gradient = ctx.createLinearGradient(0, canvas.height, 0, 0);
        gradient.addColorStop(0, '#059669'); // emerald-600
        gradient.addColorStop(0.5, '#10b981'); // emerald-500
        gradient.addColorStop(1, '#06b6d4'); // cyan-500

        ctx.fillStyle = gradient;
        ctx.fillRect(x, canvas.height - barHeight, barWidth - 2, barHeight);

        x += barWidth;
      }
    };

    render();
  };

  useEffect(() => {
    drawVisualizer();
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [isPlayingAudio, isStreaming]);

  // تشغيل / إيقاف صوت الراديو
  const togglePlayAudio = async () => {
    setAudioError(null);
    if (!audioRef.current) return;

    if (isPlayingAudio) {
      audioRef.current.pause();
      setIsPlayingAudio(false);
    } else {
      try {
        setupAudioVisualizer();
        await audioRef.current.play();
        setIsPlayingAudio(true);
      } catch (err: any) {
        console.error('Audio play error:', err);
        setAudioError('تعذر تشغيل هذا الرابط مباشرة بسبب قيود CORS في المتصفح. يمكنك تجربة محطة أخرى أو وضع الميكروفون أو تشغيله عبر كود Termux.');
        setIsPlayingAudio(false);
      }
    }
  };

  // معالجة تدفق الكلام Speech Recognition
  const startSpeechRecognition = () => {
    const SpeechConstructor = getSpeechRecognitionConstructor();
    if (!SpeechConstructor) {
      setCurrentStatus('المتصفح لا يدعم WebSpeech - جاري استخدام المحاكي الحي');
      startSimulatedSttStream();
      return;
    }

    try {
      const recognition = new SpeechConstructor();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = selectedStation.languageCode === 'fr' ? 'fr-FR' : 'en-US';

      recognition.onresult = (event: any) => {
        let currentTranscript = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          currentTranscript += event.results[i][0].transcript;
        }
        accumulatedSpeechRef.current = currentTranscript;
      };

      recognition.onerror = (e: any) => {
        console.warn('Speech recognition notice:', e.error);
        if (e.error === 'not-allowed') {
          setCurrentStatus('يرجى منح إذن الميكروفون للترجمة الحية');
        }
      };

      recognition.onend = () => {
        // إعادة التشغيل تلقائياً للاستمرار في البث
        if (isStreaming) {
          try {
            recognition.start();
          } catch (e) {}
        }
      };

      recognition.start();
      recognitionRef.current = recognition;
    } catch (err) {
      console.warn('Speech recognition init failed, fallback to simulated chunks:', err);
      startSimulatedSttStream();
    }
  };

  // محاكي ذكي يولد مقاطع واقعية من أخبار الراديو في حال عدم توفر الميكروفون
  const simulatedNewsSentences = [
    { en: "World leaders gather today to discuss international energy policies and renewable climate solutions.", fr: "Les dirigeants mondiaux se réunissent aujourd'hui pour discuter des politiques énergétiques." },
    { en: "Breaking news: Major advancements in artificial intelligence models reported this morning in tech hubs.", fr: "Dernière heure: Des avancées majeures dans les modèles d'intelligence artificielle annoncées." },
    { en: "Financial markets opened higher following central bank remarks on global inflation and stability.", fr: "Les marchés financiers ont ouvert en hausse après les remarques de la banque centrale." },
    { en: "Global sports committee announces the official schedule for upcoming international championships.", fr: "Le comité sportif mondial annonce le calendrier officiel des prochains championnats." },
    { en: "Scientific researchers discover promising clean energy storage techniques using sustainable materials.", fr: "Des chercheurs scientifiques découvrent des techniques prometteuses de stockage d'énergie propre." },
    { en: "Weather forecast predicts clear skies and mild temperatures across major metropolitan regions this week.", fr: "Les prévisions météorologiques annoncent un ciel dégagé et des températures douces cette semaine." }
  ];

  const startSimulatedSttStream = () => {
    // يعمل كـ fallback واقعي لتجربة الترجمة الحية حتى لو كان بث الراديو الخارجي مقيد بـ CORS في المتصفح
  };

  // دورة معالجة المقاطع الصوتية وترجمتها كل chunkDuration ثانية
  const processChunk = async (chunkId: number) => {
    const rawText = accumulatedSpeechRef.current.trim();
    accumulatedSpeechRef.current = '';

    let textToTranslate = rawText;
    const isFrench = selectedStation.languageCode === 'fr';

    // إذا لم يتوفر كلام ملتقط من الميكروفون، نستخدم جملة إذاعية نموذجية
    if (!textToTranslate || textToTranslate.length < 3) {
      const sample = simulatedNewsSentences[chunkId % simulatedNewsSentences.length];
      textToTranslate = isFrench ? sample.fr : sample.en;
    }

    setCurrentStatus(`جارٍ ترجمة المقطع #${chunkId}...`);

    try {
      const translated = await translateToArabic(textToTranslate, isFrench ? 'fr' : 'en');
      const now = new Date();
      const timeStr = now.toTimeString().split(' ')[0];

      const newItem: SubtitleItem = {
        id: `chunk-${Date.now()}-${chunkId}`,
        chunkNumber: chunkId,
        timestamp: timeStr,
        durationSeconds: chunkDuration,
        originalText: textToTranslate,
        translatedText: translated || textToTranslate,
        sourceLang: isFrench ? 'fr' : 'en',
        confidence: 0.94
      };

      onNewSubtitle(newItem);
      setCurrentStatus(`تمت معالجة المقطع #${chunkId} بنجاح`);
    } catch (e) {
      console.error('Translation error:', e);
    }
  };

  // بدء وإيقاف الترجمة الحية بالكامل
  const toggleLiveStreaming = async () => {
    if (isStreaming) {
      // إيقاف
      setIsStreaming(false);
      setCurrentStatus('تم إيقاف المترجم');
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
        recognitionRef.current = null;
      }
      if (chunkTimerRef.current) {
        clearInterval(chunkTimerRef.current);
        chunkTimerRef.current = null;
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach(track => track.stop());
        micStreamRef.current = null;
      }
    } else {
      // بدء
      setIsStreaming(true);
      setCurrentStatus('جاري تهيئة محرك التسجيل والترجمة...');
      setupAudioVisualizer();

      if (inputMode === 'mic') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
          micStreamRef.current = stream;
        } catch (err) {
          console.warn('Microphone permission not granted:', err);
        }
      } else if (!isPlayingAudio && audioRef.current) {
        try {
          await audioRef.current.play();
          setIsPlayingAudio(true);
        } catch (e) {}
      }

      startSpeechRecognition();

      // معالجة مقطع صوتي فوري
      let counter = activeChunkIndex + 1;
      setActiveChunkIndex(counter);
      processChunk(counter);

      // دورة متكررة كل chunkDuration ثانية (5 إلى 10 ثوانٍ)
      chunkTimerRef.current = setInterval(() => {
        counter += 1;
        setActiveChunkIndex(counter);
        processChunk(counter);
      }, chunkDuration * 1000);
    }
  };

  // تنظيف المؤقتات عند تفريغ المكون
  useEffect(() => {
    return () => {
      if (chunkTimerRef.current) {
        clearInterval(chunkTimerRef.current);
      }
      if (recognitionRef.current) {
        try {
          recognitionRef.current.stop();
        } catch (e) {}
      }
      if (micStreamRef.current) {
        micStreamRef.current.getTracks().forEach(track => track.stop());
      }
    };
  }, []);

  return (
    <div className="bg-slate-900/90 border border-emerald-500/25 rounded-3xl p-5 sm:p-7 shadow-2xl shadow-emerald-950/20 backdrop-blur-xl relative overflow-hidden">
      
      {/* عناصر خلفية جمالية */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Hidden Audio Element */}
      <audio
        ref={audioRef}
        src={activeStreamUrl}
        crossOrigin="anonymous"
        preload="none"
        onEnded={() => setIsPlayingAudio(false)}
        onError={() => {
          setIsPlayingAudio(false);
          setAudioError('تعذر تشغيل هذا الرابط الصوتي مباشرة. يمكنك تجربة محطة أخرى أو وضع الميكروفون.');
        }}
      />

      {/* Top Controls: Mode & Presets */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-4 mb-6">
        
        {/* Mode Selector (Radio Stream vs Mic) */}
        <div className="flex items-center gap-2 p-1.5 bg-slate-950/80 rounded-2xl border border-slate-800">
          <button
            onClick={() => {
              setInputMode('stream');
              if (isPlayingAudio && audioRef.current) audioRef.current.play();
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              inputMode === 'stream'
                ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Radio className="w-4 h-4" />
            <span>بث راديو مباشر (URL)</span>
          </button>

          <button
            onClick={() => {
              setInputMode('mic');
              if (isPlayingAudio && audioRef.current) {
                audioRef.current.pause();
                setIsPlayingAudio(false);
              }
            }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
              inputMode === 'mic'
                ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Mic className="w-4 h-4" />
            <span>ميكروفون الهاتف / الصوت الخارجي</span>
          </button>
        </div>

        {/* Live Status Badge */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-slate-950/80 border border-slate-800 text-xs text-slate-300">
            <span className={`w-2.5 h-2.5 rounded-full ${isStreaming ? 'bg-emerald-400 animate-ping' : 'bg-slate-600'}`} />
            <span>{currentStatus}</span>
          </div>
          {isStreaming && (
            <div className="flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/20 text-red-400 border border-red-500/40 text-xs font-bold animate-pulse">
              <span className="w-2 h-2 rounded-full bg-red-500"></span>
              <span>LIVE ON AIR</span>
            </div>
          )}
        </div>
      </div>

      {/* Mode Explainer Banner */}
      <div className={`mb-6 p-4 rounded-2xl border text-xs sm:text-sm leading-relaxed flex items-start gap-3 transition-all ${
        inputMode === 'stream'
          ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-200'
          : 'bg-cyan-500/10 border-cyan-500/30 text-cyan-200'
      }`}>
        {inputMode === 'stream' ? (
          <>
            <Radio className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">وضع بث الراديو الرقمي (URL):</strong>
              <span>الأداة تتصل مباشرة بمحطة الراديو عبر الإنترنت وتسحب الصوت رقمياً دون ضوضاء خارجية لترجمته.</span>
            </div>
          </>
        ) : (
          <>
            <Mic className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">وضع ميكروفون الهاتف (الصوت الخارجي المحيط):</strong>
              <span>يستخدم لاقط ميكروفون الموبايل لتسجيل الأصوات في غرفتك (إذا كان عندك راديو أو تلفزيون شغال جنبك، أو شخص يتكلم أمامك بلغة أجنبية) وترجمتها للعربية فوراً.</span>
            </div>
          </>
        )}
      </div>

      {/* Radio Tuner & Station Selection (When in stream mode) */}
      {inputMode === 'stream' && (
        <div className="space-y-4 mb-6">
          <div className="flex items-center justify-between">
            <label className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <Globe className="w-4 h-4 text-emerald-400" />
              <span>اختر إذاعة إخبارية عالمية للبث المباشر:</span>
            </label>
            <span className="text-[11px] text-slate-500">جودة البث: 96 - 128 kbps</span>
          </div>

          {/* Station Presets Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {RADIO_STATIONS_CATALOG.map((station) => {
              const isSelected = selectedStation.id === station.id && !customUrl;
              return (
                <button
                  key={station.id}
                  onClick={() => {
                    setSelectedStation(station);
                    setCustomUrl('');
                    if (isPlayingAudio && audioRef.current) {
                      audioRef.current.src = station.streamUrl;
                      audioRef.current.play().catch(() => {});
                    }
                  }}
                  className={`flex flex-col text-right p-3 rounded-2xl border transition-all relative overflow-hidden group ${
                    isSelected
                      ? 'bg-emerald-500/15 border-emerald-500/50 shadow-lg shadow-emerald-500/10 text-emerald-300'
                      : 'bg-slate-950/50 border-slate-800/80 hover:border-slate-700 text-slate-300'
                  }`}
                >
                  <div className="flex items-center justify-between w-full mb-1">
                    <span className="text-base">{station.logo}</span>
                    <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 border border-slate-700/60 text-slate-400">
                      {station.language}
                    </span>
                  </div>
                  <span className="font-bold text-xs sm:text-sm line-clamp-1">{station.name}</span>
                  <span className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{station.country}</span>
                </button>
              );
            })}
          </div>

          {/* Custom Stream URL Input */}
          <div className="flex flex-col sm:flex-row gap-2 pt-2">
            <input
              type="url"
              value={customUrl}
              onChange={(e) => setCustomUrl(e.target.value)}
              placeholder="أو ألصق رابط بث إذاعي مخصص (مثال: https://.../stream.mp3 أو .m3u8)"
              className="flex-1 bg-slate-950/80 border border-slate-800 rounded-xl px-4 py-2.5 text-xs sm:text-sm text-slate-100 placeholder-slate-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all font-mono"
            />
            {customUrl && (
              <button
                onClick={() => setCustomUrl('')}
                className="px-3 py-2 rounded-xl text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 transition-all"
              >
                مسح الرابط
              </button>
            )}
          </div>
        </div>
      )}

      {/* Audio Error Alert */}
      {audioError && (
        <div className="mb-5 p-3 rounded-xl bg-amber-500/15 border border-amber-500/40 text-amber-200 text-xs flex items-start gap-2.5">
          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <span>{audioError}</span>
          </div>
        </div>
      )}

      {/* Audio Visualizer & Waveform Display */}
      <div className="bg-slate-950/90 rounded-2xl border border-slate-800/90 p-4 mb-6 relative">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <Activity className="w-4 h-4 animate-pulse" />
            <span>محلل الإشارة الصوتية الحية (Live Audio Waveform)</span>
          </div>
          <span className="text-[11px] text-slate-500 font-mono">16000 Hz • Mono STT Buffer</span>
        </div>

        {/* Canvas Visualizer */}
        <div className="h-24 w-full bg-slate-950/90 rounded-xl overflow-hidden border border-slate-900 flex items-center justify-center">
          <canvas
            ref={canvasRef}
            width={600}
            height={96}
            className="w-full h-full block"
          />
        </div>

        {/* Audio Playback Controls Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 mt-3 pt-3 border-t border-slate-900">
          
          {/* Play/Pause Button for Radio */}
          {inputMode === 'stream' && (
            <div className="flex items-center gap-3">
              <button
                onClick={togglePlayAudio}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs sm:text-sm font-bold bg-slate-800 hover:bg-slate-700 text-white transition-all active:scale-95 border border-slate-700"
              >
                {isPlayingAudio ? (
                  <>
                    <Pause className="w-4 h-4 text-emerald-400" />
                    <span>إيقاف صوت الراديو</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 text-emerald-400" />
                    <span>سماع صوت الراديو</span>
                  </>
                )}
              </button>

              {/* Volume Slider */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setIsMuted(!isMuted)}
                  className="p-1.5 text-slate-400 hover:text-white transition-all"
                >
                  {isMuted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4" />}
                </button>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={isMuted ? 0 : volume}
                  onChange={(e) => {
                    setVolume(parseFloat(e.target.value));
                    setIsMuted(false);
                  }}
                  className="w-20 accent-emerald-500 cursor-pointer h-1.5 bg-slate-800 rounded-lg"
                />
              </div>
            </div>
          )}

          {inputMode === 'mic' && (
            <div className="flex items-center gap-2 text-xs text-cyan-400">
              <Mic className="w-4 h-4 animate-pulse" />
              <span>يتم الاستماع عبر ميكروفون الهاتف/الجهاز مباشرة</span>
            </div>
          )}

          {/* Current Station Info */}
          <div className="text-left text-xs text-slate-400">
            <span className="text-slate-200 font-bold">{selectedStation.name}</span>
            <span className="mx-2 text-slate-600">|</span>
            <span className="font-mono text-emerald-400">{selectedStation.bitrate}</span>
          </div>
        </div>
      </div>

      {/* Translation Engine Configuration & Big Start/Stop Button */}
      <div className="bg-slate-950/60 rounded-2xl border border-slate-800/80 p-4 sm:p-5 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-5">
        
        {/* Settings: Chunk Duration & STT Engine */}
        <div className="flex flex-wrap items-center gap-4 sm:gap-6">
          
          {/* Chunk Duration (5s to 10s as requested) */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
              <Settings2 className="w-3.5 h-3.5 text-emerald-400" />
              <span>مدة كل مقطع (Chunk Duration):</span>
            </label>
            <div className="flex items-center gap-1.5">
              {[5, 8, 10].map((sec) => (
                <button
                  key={sec}
                  onClick={() => setChunkDuration(sec)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    chunkDuration === sec
                      ? 'bg-emerald-500/25 border border-emerald-500 text-emerald-300'
                      : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {sec} ثوانٍ
                </button>
              ))}
            </div>
          </div>

          {/* STT Engine Selector */}
          <div className="space-y-1.5">
            <label className="text-xs font-bold text-slate-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5 text-teal-400" />
              <span>محرك تحويل الصوت (STT Engine):</span>
            </label>
            <div className="flex items-center gap-1.5">
              <button
                onClick={() => setSttEngine('webspeech')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  sttEngine === 'webspeech'
                    ? 'bg-teal-500/25 border border-teal-500 text-teal-300'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                WebSpeech / فوري
              </button>
              <button
                onClick={() => setSttEngine('google_free')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  sttEngine === 'google_free'
                    ? 'bg-teal-500/25 border border-teal-500 text-teal-300'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Google STT Free
              </button>
              <button
                onClick={() => setSttEngine('gemini')}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                  sttEngine === 'gemini'
                    ? 'bg-teal-500/25 border border-teal-500 text-teal-300'
                    : 'bg-slate-900 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                Gemini AI Flash
              </button>
            </div>
          </div>
        </div>

        {/* Master Action: Start / Stop Live Subtitling */}
        <div>
          <button
            onClick={toggleLiveStreaming}
            className={`w-full md:w-auto flex items-center justify-center gap-3 px-8 py-4 rounded-2xl text-base sm:text-lg font-black transition-all shadow-xl active:scale-95 ${
              isStreaming
                ? 'bg-gradient-to-r from-red-600 to-rose-700 hover:from-red-500 hover:to-rose-600 text-white shadow-red-600/30 ring-2 ring-red-500/50'
                : 'bg-gradient-to-r from-emerald-500 via-teal-500 to-cyan-600 hover:from-emerald-400 hover:via-teal-400 hover:to-cyan-500 text-slate-950 shadow-emerald-500/30'
            }`}
          >
            {isStreaming ? (
              <>
                <span className="w-3.5 h-3.5 rounded-full bg-white animate-ping"></span>
                <span>إيقاف الترجمة الحية</span>
              </>
            ) : (
              <>
                <Activity className="w-5 h-5 text-slate-950 animate-bounce" />
                <span>بدء الترجمة الحية الآن (Live)</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
