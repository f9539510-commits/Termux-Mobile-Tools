import React from 'react';
import { EzzoStandaloneApp } from './components/EzzoStandaloneApp';

export const App: React.FC = () => {
  return <EzzoStandaloneApp />;
};
