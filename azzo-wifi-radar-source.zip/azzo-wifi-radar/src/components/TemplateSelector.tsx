import React from 'react';
import { ToolConfig, TemplateType } from '../types/termuxStudio';
import { ASCII_BANNERS } from '../data/codeTemplates';
import { Layers, Terminal, Sparkles, LayoutDashboard, Check, Sliders, Edit3, ArrowRight } from 'lucide-react';

interface TemplateSelectorProps {
  config: ToolConfig;
  onChangeConfig: (newConfig: ToolConfig) => void;
  onProceedToCode: () => void;
}

export const TemplateSelector: React.FC<TemplateSelectorProps> = ({
  config,
  onChangeConfig,
  onProceedToCode
}) => {
  const templates: {
    type: TemplateType;
    titleAr: string;
    titleEn: string;
    tagline: string;
    description: string;
    badge: string;
    badgeColor: string;
    previewLines: string[];
    accentGradient: string;
  }[] = [
    {
      type: 'classic',
      titleAr: 'القالب الكلاسيكي (Classic)',
      titleEn: 'Classic Terminal CLI',
      tagline: 'نصي خفيف وسريع وبدون أي مكتبات خارجية إجبارية',
      description: 'واجهة نصية نقية بخلفية سوداء وألوان ANSI قياسية، تدعم القوائم التفاعلية، أرقام الاختيارات، وفحص النظام الأساسي بسرعة قصوى.',
      badge: 'Zero-Dependencies • 100% Native',
      badgeColor: 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300',
      accentGradient: 'from-emerald-500/20 to-transparent border-emerald-500/30',
      previewLines: [
        '[*] Tool: ' + config.toolName + ' | v' + config.version,
        '==============================================',
        '[+] MAIN MENU:',
        ' [1] Run Primary Routine',
        ' [2] System Diagnostics',
        ' [0] Exit',
        '----------------------------------------------',
        config.toolSlug + ' > _'
      ]
    },
    {
      type: 'cyberpunk',
      titleAr: 'قالب السايبربنك (Cyberpunk)',
      titleEn: 'Cyberpunk Neon Matrix',
      tagline: 'واجهة نيون متوهجة، إطارات Glitch وشرايط وأشرطة تحميل',
      description: 'تصميم نيون مستقبلي جذاب بالسيان والوردي الفاقع، إطارات مزدوجة ╔═╗، شريط تقدم تحميل ديناميكي، وفحص عُقد متزامن يحاكي أدوات السايبر الاحترافية.',
      badge: 'Neon Effects • Glitch Frames • Animated Loader',
      badgeColor: 'border-cyan-500/40 bg-cyan-500/10 text-cyan-300',
      accentGradient: 'from-cyan-500/20 via-pink-500/10 to-transparent border-cyan-500/30',
      previewLines: [
        '╔════════════════════════════════════════════╗',
        '║ KALBASO DECK :: ' + config.toolName.toUpperCase() + ' ║',
        '╠════════════════════════════════════════════╣',
        '[*] BOOTING NEURAL MATRIX: [########--] 80%',
        '┌──[ COMMAND DECK ]',
        '│  [1] Cyber Breach Scan  :: فحص الشبكة',
        '│  [2] Telemetry Pulse    :: نبض الموارد',
        'kalbaso@' + config.toolSlug + '~$ _'
      ]
    },
    {
      type: 'dashboard',
      titleAr: 'لوحة التحكم والمنظمات (Dashboard)',
      titleEn: 'Data Grid & Dashboard IDE',
      tagline: 'جداول منظمة، بانلز، وعرض بيانات وإحصائيات النظام',
      description: 'واجهة احترافية متقدمة بجداول منظمة لعرض القياسات (CPU, RAM, Uptime) ومسارات التيرمكس، تدعم مكتبة rich المتقدمة مع fallback تلقائي.',
      badge: 'Rich Tables • Metrics Panels • Data Stream',
      badgeColor: 'border-purple-500/40 bg-purple-500/10 text-purple-300',
      accentGradient: 'from-purple-500/20 to-transparent border-purple-500/30',
      previewLines: [
        '+============================================+',
        '| ' + config.toolName + ' Dashboard | ' + config.author + ' |',
        '+============================================+',
        '| PARAMETER      | VALUE       | STATUS      |',
        '| OS Kernel      | Linux/Termux| [ONLINE]    |',
        '| Python Core    | 3.12.4      | [PASS]      |',
        '| Active Tasks   | 4 Threads   | [ACTIVE]    |',
        '+============================================+'
      ]
    }
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      
      {/* Intro Hero Section */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-950 to-[#030712] border border-slate-800 p-6 sm:p-8 shadow-xl">
        <div className="absolute top-0 right-0 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl -z-10 pointer-events-none"></div>
        <div className="flex flex-col md:flex-row items-center gap-6 justify-between">
          <div className="space-y-2 text-right">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold font-mono">
              <Sparkles className="w-3.5 h-3.5" />
              <span>الخطوة 1: اختيار القالب البرمجي وتخصيص الهوية</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-100">
              اختر قالب واجهة أداة تيرمكس (Termux UI Templates)
            </h1>
            <p className="text-sm text-slate-400 max-w-2xl leading-relaxed">
              وفّر وقتك في كتابة تنسيقات الطرفية وأكواد الـ ANSI اليدوية. اختر أحد القوالب الجاهزة الثلاثة، وحدد اسم الأداة وشعارها النصي، وسيقوم المحرك بتوليد الكود البرمجي فورياً.
            </p>
          </div>

          <button
            onClick={onProceedToCode}
            className="flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 hover:from-emerald-400 hover:to-cyan-400 text-slate-950 font-bold text-sm shadow-lg shadow-emerald-500/20 active:scale-95 transition-all whitespace-nowrap"
          >
            <span>معاينة الكود والتشغيل المباشر</span>
            <ArrowRight className="w-4 h-4 rtl:rotate-180" />
          </button>
        </div>
      </div>

      {/* 3 Templates Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {templates.map((tpl) => {
          const isSelected = config.template === tpl.type;
          return (
            <div
              key={tpl.type}
              onClick={() => onChangeConfig({ ...config, template: tpl.type })}
              className={`relative cursor-pointer rounded-2xl border transition-all duration-200 overflow-hidden flex flex-col justify-between ${
                isSelected
                  ? `bg-slate-900/90 border-emerald-400 ring-2 ring-emerald-500/40 shadow-2xl shadow-emerald-950/60`
                  : `bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-900/40`
              }`}
            >
              <div className="p-6 space-y-4">
                
                {/* Header & Status */}
                <div className="flex items-start justify-between gap-3">
                  <div className={`p-2.5 rounded-xl border ${isSelected ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300' : 'bg-slate-900 border-slate-800 text-slate-400'}`}>
                    {tpl.type === 'classic' && <Terminal className="w-6 h-6" />}
                    {tpl.type === 'cyberpunk' && <Sparkles className="w-6 h-6" />}
                    {tpl.type === 'dashboard' && <LayoutDashboard className="w-6 h-6" />}
                  </div>

                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full border ${tpl.badgeColor}`}>
                    {tpl.badge}
                  </span>
                </div>

                <div>
                  <h3 className="text-lg font-bold text-slate-100 flex items-center justify-between">
                    <span>{tpl.titleAr}</span>
                    {isSelected && (
                      <span className="w-5 h-5 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center">
                        <Check className="w-3.5 h-3.5 stroke-[3]" />
                      </span>
                    )}
                  </h3>
                  <p className="text-xs text-emerald-400 font-mono mt-0.5">{tpl.titleEn}</p>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed min-h-[48px]">
                  {tpl.description}
                </p>

                {/* Micro Terminal Preview Window */}
                <div className="rounded-xl bg-[#030712] border border-slate-800/80 p-3.5 font-mono text-[11px] text-slate-300 space-y-1 shadow-inner overflow-hidden select-none">
                  <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-900 text-[10px] text-slate-500">
                    <span>preview@termux</span>
                    <div className="flex gap-1">
                      <span className="w-2 h-2 rounded-full bg-red-500/70 inline-block"></span>
                      <span className="w-2 h-2 rounded-full bg-yellow-500/70 inline-block"></span>
                      <span className="w-2 h-2 rounded-full bg-emerald-500/70 inline-block"></span>
                    </div>
                  </div>
                  {tpl.previewLines.map((line, idx) => (
                    <div key={idx} className="truncate text-slate-400 hover:text-emerald-300 transition-colors">
                      {line}
                    </div>
                  ))}
                </div>
              </div>

              {/* Bottom selection button */}
              <div className="p-4 bg-slate-900/40 border-t border-slate-800/80">
                <button
                  type="button"
                  className={`w-full py-2 px-4 rounded-xl font-bold text-xs transition-all ${
                    isSelected
                      ? 'bg-emerald-500 text-slate-950 shadow-md shadow-emerald-500/20'
                      : 'bg-slate-800/80 text-slate-300 hover:bg-slate-700 hover:text-white'
                  }`}
                >
                  {isSelected ? '✓ القالب المعتمد حالياً' : 'تحديد هذا القالب'}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tool Identity & Configuration Drawer */}
      <div className="rounded-2xl bg-slate-900/60 border border-slate-800 p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-slate-100">
                تخصيص هوية الأداة وشعار الـ ASCII (Tool Customizer)
              </h2>
              <p className="text-xs text-slate-400">
                تعديل الاسم واللوجو المدمج تلقائياً في الكود النهائي
              </p>
            </div>
          </div>
          <span className="text-xs font-mono text-cyan-400 px-2.5 py-1 rounded-lg bg-cyan-500/10 border border-cyan-500/20">
            تحديث فوري للكود
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Tool Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">اسم الأداة (Tool Name)</label>
            <input
              type="text"
              value={config.toolName}
              onChange={(e) => {
                const name = e.target.value;
                const slug = name.trim().toLowerCase().replace(/[^a-z0-9_-]/g, '_') || 'tool';
                onChangeConfig({ ...config, toolName: name, toolSlug: slug });
              }}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-sm text-slate-100 focus:outline-none focus:border-emerald-500 font-mono"
              placeholder="مثال: Kalbaso Scanner"
            />
          </div>

          {/* Tool Slug */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-300">اسم الملف في تيرمكس (.py)</label>
            <div className="flex items-center rounded-xl bg-slate-950 border border-slate-800 px-3 py-2.5 text-sm font-mono text-slate-300">
              <span className="text-emerald-400 font-bold">~/</span>
              <input
                type="text"
                value={config.toolSlug}
                onChange={(e) => onChangeConfig({ ...config, toolSlug: e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, '') })}
                className="w-full bg-transparent border-none text-slate-100 focus:outline-none px-1 text-sm font-mono"
              />
              <span className="text-slate-500">.py</span>
            </div>
          </div>
        </div>

        {/* ASCII Logo Selector */}
        <div className="space-y-3 pt-2">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>شعار الأداة النصي (ASCII Art Banner) المدمج في واجهة الطرفية:</span>
            <span className="text-[11px] text-slate-500 font-normal">اختر من القوالب أو اكتب شعارك</span>
          </label>
          <div className="flex flex-wrap gap-2">
            {[
              { id: 'cyber', label: 'Cyber Block' },
              { id: 'hacker', label: 'Hacker Slant' },
              { id: 'matrix', label: 'Matrix Box' },
              { id: 'shield', label: 'Shield Emblem' },
              { id: 'fire', label: 'Fire Gothic' },
              { id: 'custom', label: 'شعار مخصص (Custom)' }
            ].map(b => (
              <button
                key={b.id}
                onClick={() => onChangeConfig({ ...config, bannerType: b.id as any })}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono transition-all ${
                  config.bannerType === b.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'bg-slate-950 border border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                {b.label}
              </button>
            ))}
          </div>

          {/* Banner Preview or Custom Input */}
          {config.bannerType === 'custom' ? (
            <textarea
              rows={4}
              value={config.customBannerText || ''}
              onChange={(e) => onChangeConfig({ ...config, customBannerText: e.target.value })}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500"
              placeholder="ألصق شعار الـ ASCII الفني هنا..."
            />
          ) : (
            <pre className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 font-mono text-[10px] text-cyan-400 overflow-x-auto whitespace-pre max-h-28 scrollbar-thin">
              {ASCII_BANNERS[config.bannerType]}
            </pre>
          )}
        </div>

      </div>
    </div>
  );
};
