import JSZip from 'jszip';
import { TERMUX_PROJECT_FILES } from '../data/termuxFiles';

export async function generateTermuxProjectZip(): Promise<Blob> {
  const zip = new JSZip();

  // إنشاء مجلد رئيسي داخل الـ zip
  const folder = zip.folder('live-audio-translator');

  // إضافة جميع الملفات البرمجية
  TERMUX_PROJECT_FILES.forEach(file => {
    folder?.file(file.path, file.content);
  });

  // إضافة ملف README.md مفصل داخل الـ ZIP
  const readmeContent = `# Live Audio Translator for Termux
====================================
أداة ذكية للاستماع إلى بث الراديو المباشر وتسجيل مقاطع صوتية قصيرة (5-10 ثوانٍ)
وتحويلها لنصوص وترجمتها لحظياً إلى اللغة العربية وعرضها سطر بسطر على الشاشة.

## 🚀 طريقة التثبيت والتشغيل في Termux:

1. افتح تطبيق Termux واكتب:
   \`\`\`bash
   pkg update -y && pkg install -y python ffmpeg git curl
   \`\`\`

2. فك ضغط هذا المجلد وانتقل إليه:
   \`\`\`bash
   cd live-audio-translator
   \`\`\`

3. ثبّت المكتبات المطلوبة:
   \`\`\`bash
   pip install -r requirements.txt
   \`\`\`

4. شغّل الأداة:
   \`\`\`bash
   # التشغيل المباشر مع قناة BBC World Service الافتراضية:
   python main.py

   # التشغيل مع رابط راديو مخصص وتسجيل كل 8 ثوانٍ:
   python main.py --url "https://stream.live.vc.bbcmedia.co.uk/bbc_world_service" --chunk 8

   # التشغيل عبر ميكروفون الهاتف:
   python main.py --mic
   \`\`\`

## 📁 هيكلية الملفات:
- \`main.py\`: الملف الرئيسي وواجهة الشاشة الحية (Rich Console)
- \`stream_recorder.py\`: تسجيل الصوت من البث المباشر عبر ffmpeg
- \`stt_engine.py\`: تحويل الصوت إلى نص عبر Google STT / Whisper
- \`translator.py\`: ترجمة النصوص إلى العربية الفصحى
- \`display.py\`: تشكيل الحروف العربية وتنسيق الشاشة سطر بسطر
- \`config.py\`: القنوات المسبقة والإعدادات العامة
- \`requirements.txt\`: مكتبات بايثون المطلوبة
- \`install_termux.sh\`: سكربت التثبيت التلقائي بنقرة واحدة
`;

  folder?.file('README.md', readmeContent);

  return await zip.generateAsync({ type: 'blob' });
}

export function downloadBlobAsFile(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
